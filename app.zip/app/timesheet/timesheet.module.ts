import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '@shared/shared.module';

import { TimesheetRoutingModule } from './timesheet-routing.module';
import { UploadFileComponent } from './upload-file/upload-file.component';
import { TimesheetDetailsComponent } from './timesheet-details/timesheet-details.component';
import { FormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    UploadFileComponent,
    TimesheetDetailsComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    TimesheetRoutingModule,
    FormsModule,
  ]
})
export class TimesheetModule { }
