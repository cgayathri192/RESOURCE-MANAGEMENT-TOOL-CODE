import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UploadFileComponent } from './upload-file/upload-file.component';
import { TimesheetDetailsComponent } from './timesheet-details/timesheet-details.component';

const routes: Routes = [
  {
    path:'',
    component:UploadFileComponent
  },
  {
    path:'uploadfile',
    component:UploadFileComponent
  },
  {
    path:'timesheetdetails',
    component:TimesheetDetailsComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TimesheetRoutingModule { }
