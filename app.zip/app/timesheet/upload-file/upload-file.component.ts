import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-upload-file',
  templateUrl: './upload-file.component.html',
  styleUrls: ['./upload-file.component.scss']
})
export class UploadFileComponent implements OnInit {
  saviomFile: File | null = null;
  timesheetsFile: File | null = null;
  isUploadButtonEnabled: boolean = false;

       constructor(private route:Router){ }


       ngOnInit(): void {
        
       }
       checkUploadButton() {
        this.isUploadButtonEnabled = this.saviomFile !== null && this.timesheetsFile !== null;
      }
    
       uploadFiles(){
        if (this.isUploadButtonEnabled) {
          this.route.navigate(['/timesheet/timesheetdetails']);
        }
       }
}

  

