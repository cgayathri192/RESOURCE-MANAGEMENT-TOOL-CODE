import { Injectable } from "@angular/core";
import { NativeDateAdapter, MatDateFormats } from "@angular/material/core";

@Injectable()
export class AppDateAdapter extends NativeDateAdapter {
    override format(date: Date, displayFormat: Object): string {
      if (displayFormat === 'input') {
        let day: string = date.getDate().toString().padStart(2, '0');
        let month: string = (date.getMonth() + 1).toString().padStart(2, '0');
        const year: number = date.getFullYear();
        return `${day} ${this.getMonthName(date)} ${year}`;
      }
      return date.toDateString();
    }
    private getMonthName(date: Date): string {
      return new Intl.DateTimeFormat(this.locale, { month: 'short' }).format(date);
    }
  }
  
  export const APP_DATE_FORMATS: MatDateFormats = {
    parse: {
      dateInput: { day: 'numeric', month: 'short', year: 'numeric' },
    },
    display: {
      dateInput: 'input',
      monthYearLabel: { year: 'numeric', month: 'numeric' },
      dateA11yLabel: { year: 'numeric', month: 'long', day: 'numeric' },
      monthYearA11yLabel: { year: 'numeric', month: 'long' }
    }
  };