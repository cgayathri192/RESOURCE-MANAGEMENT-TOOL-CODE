export interface EmployeeLocationRes {
    code: number
    status: string
    message: string
    LocationData: EmployeeLocation[]
  }
  export interface AllEmployeeRes {
    code: number
    status: string
    message: string
    data: AllEmployee[]
  }
  export interface TenurityLocationRes {
    code: number
    status: string
    message: string
    locations: TenurityLocation[]
  }
  export interface TenurityLocation {
    city: string
    employees: TenurityEmployee[]
  }
  
  export interface TenurityEmployee {
    MouriTechTenurityGroup: string
    count: number
  }
  export interface EmployeebillingRes {
    code: number
    status: string
    message: string
    data: Employeebilling[]
  }
  
  export interface Employeebilling {
    Location: string
    TotalEmployeesCount: number
    Billable: number
    NonBillable: number
  }
  export interface EmployeeLocation {
    location?: string
    EmployeeCount: number
    Location?: string
  }
  export interface AllEmployee {
    TotalEmployes: number
    TotalClients: number
    BenchCount: number
    BillableStatus: BillableStatus[]
  }
  
  export interface EmployeeSkillsRes {
    code: number
    status: string
    message: string
    locations: LocationSkills[]
  }
  
  export interface LocationSkills {
    city: string
    employees: Employee[]
  }
  
  export interface Employee {
    skill: string
    count: number
  }
  export interface BillableStatus {
    BillingStatusNames: string
    count: number
  }

  
  