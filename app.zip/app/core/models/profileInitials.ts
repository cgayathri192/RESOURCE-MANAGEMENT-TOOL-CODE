export interface ProfileInitials{
    initial: string,
    color: string
  }