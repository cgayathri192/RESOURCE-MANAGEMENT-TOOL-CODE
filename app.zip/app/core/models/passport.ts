export interface PassportRes {
  code: number
  status: string
  message: string
  data: PassportModel[]
}
export interface PassportReq {
  code: number
  status: string
  message: string
  data: PassportModel
}
export interface PassportModel {
  Id: number
  Employee?: Employee
  EmployeeId:number
  PassportNumber: string
  PassportStatus: boolean
  PassportExpiry: string
  VisaType?: VisaType
  VisaTypeId:number
  VisaStatus: boolean
  VisaValidity: string | null 
  ModifiedBy?: ModifiedBy
  ModifiedAt?: string
  CreatedAt?: string
}

export interface Employee {
  Id: number
  ResourceName: string
  IsActive: boolean
}

export interface VisaType {
  Id: number
  VisaTypeName: string
}

export interface ModifiedBy {
  Id: number
  ResourceName: string
}