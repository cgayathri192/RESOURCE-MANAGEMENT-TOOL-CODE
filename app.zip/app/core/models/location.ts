export interface LocationRes {
    code: number
    status: string
    message: string
    data: LocationModel[]
  }
  export interface LocationReq {
    code: number
    status: string
    message: string
    data: LocationModel
  }
  export interface LocationModel {
    Id: number
    ModifiedBy: ModifiedBy
    ModifiedAt: string
    CreatedAt: string
    LocationName: string
  }
  
  export interface ModifiedBy {
    Id: number
    ResourceName: string
  }

  export interface Location {
    LocationName: string
  }