export interface VisatypeRes {
  code: number
  status: string
  message: string
  data: VisatypeModel[]
}

export interface VisatypeReq {
  code: number
  status: string
  message: string
  data: VisatypeModel
}

export interface VisatypeModel {
  Id: number
  ModifiedBy: ModifiedBy
  ModifiedAt: string
  CreatedAt: string
  VisaTypeName: string
  IsActive: boolean
}

export interface ModifiedBy {
  Id: number
  ResourceName: string
}

export interface Visatype {
  VisaTypeName: string
}