export interface TitleRes {
  code: number
  status: string
  message: string
  data: TitleModel[]
}

export interface TitleReq {
  code: number
  status: string
  message: string
  data: TitleModel
}

export interface TitleModel {
  Id: number
  ModifiedBy: ModifiedBy
  ModifiedAt: string
  CreatedAt: string
  TitleName: string
  Grade: Grade
  Department: Department
}

export interface Grade {
  Id: number
  GradeName: string
}

export interface Department {
  Id: number
  DepartmentName: string
}

export interface ModifiedBy {
  Id: number
  ResourceName: string
}

export interface Title {
  TitleName: string
}