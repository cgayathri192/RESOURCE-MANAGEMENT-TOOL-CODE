export interface BillingStatusRes{
    code: number
    status: string
    message: string
    data: BillingStatusModel[]
  }
  export interface BillingStatusReq {
    code: number
    status: string
    message: string
    data: BillingStatusModel
  }
  
  export interface BillingStatusModel {
    Id: number
    ModifiedBy: ModifiedBy
    ModifiedAt: string
    CreatedAt: string
    BillingStatusName: string
  }
  
  export interface ModifiedBy {
    Id: number
    ResourceName: string
  }
  