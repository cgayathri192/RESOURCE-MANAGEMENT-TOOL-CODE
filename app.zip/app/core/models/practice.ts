export interface PracticeRes {
  code: number
  status: string
  message: string
  data: PracticeModel[]
}

export interface PracticeReq {
  code: number
  status: string
  message: string
  data: PracticeModel
}

export interface PracticeModel {
  Id: number
  ModifiedBy: ModifiedBy
  ModifiedAt: string
  CreatedAt: string
  PracticeName: string
  IsActive: boolean
}

export interface ModifiedBy {
  Id: number
  ResourceName: string
}

export interface Practice {
  PracticeName: string
}