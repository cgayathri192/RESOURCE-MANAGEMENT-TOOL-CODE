export interface ClientRes{
    code: number
    status: string
    message: string
    data: ClientModel[]
}
export interface ClientReq {
    code: number
    status: string
    message: string
    data: ClientModel
}
export interface ClientModel {
    Id: number
    ClientName: string
    Status: string
    ClientType: ClientType
    Address: string
    Suburb: string
    PostCode: string
    Country: string
    MobileNumber: string
    Fax: string
    Email: string
    PhoneNumber: string
    Website: string
    Reference: string
    ClientCode: string
    ClientDescription: string
    EndDate: string
    IsActive: boolean
    ModifiedBy: ModifiedBy
    ModifiedAt: string
    CreatedAt: string
}
export interface ClientType {
    Id: number
    ClientTypeName: string
}
  
export interface ModifiedBy {
    Id: number
    ResourceName: string
}
export interface Client {
    ClientName: string
    ClientTypeId: number
    EndDate:string
    Status: string
    ClientType: ClientType
    Address: string
    Suburb: string
    PostCode: string
    Country: string
    MobileNumber: string
    Fax: string
    Email: string
    PhoneNumber: string
    Website: string
    Reference: string
    ClientCode: string
    ClientDescription: string
    IsActive: boolean
}