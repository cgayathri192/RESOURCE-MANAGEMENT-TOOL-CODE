export interface ProjectMappingRes {
    code: number
    status: string
    message: string
    data: ProjectMappingModel[]
  }
  export interface ProjectMappingReq{
    code: number
    status: string
    message: string
    data: ProjectMappingModel
  }
  
  export interface ProjectMappingModel {
    Id: number
    Employee: Employee
    Project: Project
    StartDate: string
    EndDate: string
    BillingStatus: BillingStatus
    ShadowToEmployee: ShadowToEmployee
    EffortPercentage: number
    Status: string
    ModifiedBy: ModifiedBy
    ModifiedAt: string
    CreatedAt: string
  }
  
  export interface Employee {
    Id: number
    ResourceName: string
    IsActive: boolean
  }
  
  export interface Project {
    Id: number
    ProjectName: string
  }
  
  export interface BillingStatus {
    Id: number
    BillingStatusName: string
  }
  
  export interface ShadowToEmployee {
    Id: number
    ResourceName: string
    IsActive: boolean
  }
  
  export interface ModifiedBy {
    Id: number
    ResourceName: string
  }
  export interface ProjectMapping {
    BillingStatusId:string
    BillingStatus: string
    EndDate:string
    StartDate:string
    EmployeeId:number
    ShadowToEmployeeId:string
    EffortPercentage: number
    Status: string
    ModifiedBy: string
    ModifiedAt: string
    CreatedAt: string
}
  