export interface ProjectTypeRes {
    code: number
    status: string
    message: string
    data: ProjectTypeModel[]
  }

  export interface ProjectTypeReq {
    code: number
    status: string
    message: string
    data: ProjectTypeModel
  }
  
  export interface ProjectTypeModel {
    Id: number
    ModifiedBy: ModifiedBy
    ModifiedAt: string
    CreatedAt: string
    ProjectTypeName: string
  }
  
  export interface ModifiedBy {
    Id: number
    ResourceName: string
  }
  
