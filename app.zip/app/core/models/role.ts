export interface RoleRes {
  code: number
  status: string
  message: string
  data: RolesModel[]
}
export interface RoleReq {
  code: number
  status: string
  message: string
  data: RolesModel
}
export interface RolesModel {
  Id: number
  ModifiedBy: ModifiedBy
  ModifiedAt: string
  CreatedAt: string
  RoleName: string
  IsLeader: boolean
  HierarchyId: number
  Hierarchy: Hierarchy
}

export interface ModifiedBy {
  Id: number
  ResourceName: string
}
export interface Roles {
  RoleName: string
  IsLeader: boolean
  HierarchyId: number
}

export interface Hierarchy {
  Id: number
  RoleName: string
}