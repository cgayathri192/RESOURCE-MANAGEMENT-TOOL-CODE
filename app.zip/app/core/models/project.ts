export interface ProjectRes {
    code: number;
    status: string;
    message: string;
    data: ProjectModel[];
  }
  export interface ProjectReq {
    code: number;
    status: string;
    message: string;
    data: ProjectModel;
  }
  export interface ProjectModel {
    Id: number;
    ProjectName: string;
    Status: string;
    ProjectType: ProjectType;
    Program: string;
    Client: Client;
    StartDate: string;
    FinishDate: string;
    KEKA_ProjectCode: string;
    Duration: number;
    BudgetedHours: number;
    BudgetedAmount: number;
    ProjectStatus: string;
    ERP_ProjectCode: string;
    SowNumber: number;
    PurchasedOrderNumber: number;
    IsActive: boolean;
    ModifiedBy: ModifiedBy;
    ModifiedAt: string;
    CreatedAt: string;
  }
  export interface ProjectType {
    Id: number;
    ProjectTypeName: string;
  }
  
  export interface Client {
    Id: number;
    ClientName: string;
  }
  
  export interface ModifiedBy {
    Id: number;
    ResourceName: string;
  }
  export interface Project{
    ProjectName: string;
    Status: string;
    ProjectTypeId: ProjectType;
    Program: string;
    ClientId: Client;
    StartDate: string;
    FinishDate: string;
    KEKA_ProjectCode: string;
    Duration: number;
    BudgetedHours: number;
    BudgetedAmount: number;
    ProjectStatus: string;
    ERP_ProjectCode: string;
    SowNumber: number;
    PurchasedOrderNumber: number;
    IsActive: boolean;
  }


  export interface EmployeeRes {
    code: number
    status: string
    message: string
    data: EmployeeModel[]
  }
  
  export interface EmployeeModel {
    Id: number
    ResourceName: string
    IsActive: boolean
    EffortPercentage: number
    RemainingEffortPercentage: number
  }