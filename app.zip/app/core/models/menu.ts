export interface Menu {
    label:     string;
    link?:     string;
    icon:      string;
    order : number
    isAdmin? :boolean
    children?: Menu[];
}
