export interface EmployeeExcelModel {
  Id: number
  EmployeeId: number
  ResourceName: string
  Email: string
  Password: string
  DateOfBirth: string
  Gender: string
  ReportingManager: ReportingManager
  Location: Location
  Title: Title
  Grade: Grade2
  Role: Role
  LeaderShipTeam: LeaderShipTeam
  Practice: Practice
  Department: Department2
  MouriTechTenurity: MouriTechTenurity
  DateOfJoing: string
}

export interface ReportingManager {
  Id: number
  ResourceName: string
}

export interface Location {
  Id: number
  LocationName: string
}

export interface Title {
  Id: number
  TitleName: string
  Grade: Grade
  Department: Department
}

export interface Grade {
  Id: number
  GradeName: string
}

export interface Department {
  Id: number
  DepartmentName: string
}

export interface Grade2 {
  Id: number
  GradeName: string
}

export interface Role {
  Id: number
  RoleName: string
  Hierarchy: Hierarchy
}

export interface Hierarchy {
  Id: number
  RoleName: string
}

export interface LeaderShipTeam {
  Id: number
  ResourceName: string
}

export interface Practice {
  Id: number
  PracticeName: string
}

export interface Department2 {
  Id: number
  DepartmentName: string
}

export interface MouriTechTenurity {
  Id: number
  MouriTechTenurityGroup: string
}
