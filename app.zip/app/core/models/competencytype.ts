export interface CompetencyTypeRes {
    code: number
    status: string
    message: string
    data: CompetencyTypeModel[]
  }
  export interface CompetencyTypeReq {
    code: number
    status: string
    message: string
    data: CompetencyTypeModel
  }
  export interface CompetencyTypeModel {
  Id: number
  CompetencyTypeName: string
  Practice: Practice
  ModifiedBy: ModifiedBy
  ModifiedAt: string
  CreatedAt: string
  }

  export interface Practice {
    Id: number
    PracticeName: string
  }
  
  export interface ModifiedBy {
    Id: number
    ResourceName: string
  }
  
  export interface competencytype {
    CompetencyTypeName: string
    PracticeId: number
}