export interface Tokens {
  refresh: string;
  access: string;
}

export interface JwtToken {
  token_type: string
  exp: number
  iat: number
  jti: string
  user_id: number
  RoleId: number
  Email: string
  ResourceName: string
  RoleIdIsLeader: boolean
}