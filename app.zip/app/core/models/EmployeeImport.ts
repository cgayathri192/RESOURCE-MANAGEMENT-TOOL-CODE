export interface EmployeeImportModel {
  Id: number
  "Employee Id": number
  "Resource Name": string
  Email: string
  "Date Of Birth": string
  Gender: string
  "Reporting Manager": Employee | null
  Location?: Location | null
  Title?: Title | null
  Grade?: Grade | null
  Role: Role | null
  "LeaderShip Team": Employee | null
  Practice: Practice | null
  Department: Department | null
  "MOURITECH Tenurity": MouritechTenurity | null
  "Date Of Joining": string
}
export interface EmployeeImportReq {
  EmployeeCompanyId: number
  ResourceName: string
  Email: string
  DateOfBirth: string
  Gender: string
  RoleId: string | undefined
  TitleId: string | undefined
  DateOfJoining: string
  LocationId: string| undefined
  PracticeId: string| undefined
  DepartmentId: string| undefined
  ReportingManagerId: number| undefined
  LeadershipTeamId: number| undefined
  MouriTechTenurityId: string| undefined
  GradeId: string| undefined
}
export interface Department {
  Id: number
  DepartmentName: string
}
export interface Location {
  Id: number
  LocationName: string
}

export interface Title {
  Id: number
  TitleName: string
  Grade: Grade
  Department: Department
}

export interface Grade {
  Id: number
  GradeName: string
}

export interface Department {
  Id: number
  DepartmentName: string
}

export interface Role {
  Id: number
  RoleName: string
  Hierarchy: Hierarchy
}

export interface Hierarchy {
  Id: number
  RoleName: string
}

export interface Practice {
  Id: number
  PracticeName: string
}

export interface Employee {
  Id: number
  ResourceName: string
}

export interface MouritechTenurity {
  Id: number
  MouriTechTenurityGroup: string
}