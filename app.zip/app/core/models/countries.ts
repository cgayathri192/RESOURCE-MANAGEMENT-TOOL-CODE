export interface CountryListRes {
    code: number
    status: string
    message: string
    country_list: CountryListModel[]
  }
  
  export interface CountryListModel {
    CountryCode: string
    CountryName: string
  }