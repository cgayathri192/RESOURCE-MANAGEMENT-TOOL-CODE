export interface   BlankAllocationRes{
    
    code: number
    status: string
    message: string
    data: BlankAllocationModel[]
  }
  export interface BlankAllocationReq {
    code: number
    status: string
    message: string
    data: BlankAllocationModel
}
  export interface BlankAllocationModel {
    Id: number
  EmployeeCompanyId: number
  ResourceName: string
  Email: string
  DateOfBirth: string
  DateOfJoining: string
  Gender: string
  Location: Location
  Role: Role
  Practice: Practice
  Department: Department
  LeadershipTeam: LeadershipTeam
  Grade: Grade
  Title: Title
  ReportingManager: ReportingManager
  MouriTechTenurity: MouriTechTenurity
  IsActive: boolean
  CreatedAt: string
  ModifiedBy: ModifiedBy
  ModifiedAt: string
  }
  export interface Location {
    Id: number
    LocationName: string
  }
  
  export interface Role {
    Id: number
    RoleName: string
    Hierarchy: Hierarchy
    IsLeader: boolean
  }
  
  export interface Hierarchy {
    Id: number
    RoleName: string
  }
  
  export interface Practice {
    Id: number
    PracticeName: string
  }
  
  export interface Department {
    Id: number
    DepartmentName: string
  }
  
  export interface LeadershipTeam {
    Id: number
    ResourceName: string
    IsActive: boolean
  }
  
  export interface Grade {
    Id: number
    GradeName: string
  }
  
  export interface Title {
    Id: number
    TitleName: string
    Grade: Grade2
    Department: Department2
  }
  
  export interface Grade2 {
    Id: number
    GradeName: string
  }
  
  export interface Department2 {
    Id: number
    DepartmentName: string
  }
  
  export interface ReportingManager {
    Id: number
    ResourceName: string
    IsActive: boolean
  }
  
  export interface MouriTechTenurity {
    Id: number
    MouriTechTenurityGroup: string
  }
  export interface ModifiedBy {
    Id: number
    ResourceName: string
  }
  
  export interface BlankAllocation {
    EmployeeCompanyId: number
    ResourceName: string
    Email: string
    DateOfBirth: string
    Gender: string
    RoleId: string
    TitleId: string
    DateOfJoining: string
    LocationId: string
    PracticeId: string
    DepartmentId: string
    ReportingManagerId: number
    LeadershipTeamId: number
    MouriTechTenurityId: string
    GradeId: string
  }