  
  export interface SkillImportModel{
  row: { CompetencyName: string; CompetencyTypeId: number }[]
  EmployeeCompanyId: number
  Id: number
  "Employee Id": number
  "Primary Skill": string
  "Skill Version": number
  Competency?: Competency
  "Competency Level": CompetencyLevel
  "Competency Type": CompetencyType
}
export interface SkillImportReq{
  EmployeeId: number
  Primary: string
  SkillVersion: number
  CompetencyId:  string| undefined
  CompetencyLevelId:  string| undefined
  CompetencyTypeId:  string| undefined
}
export interface Competency {
  Id: number
  CompetencyName: string
  CompetencyType: CompetencyType|undefined
}
export interface CompetencyTypeModel {
  Id: number
  CompetencyType: string
}
export interface CompetencyLevel {
  Id: number
  CompetencyLevelName: string
}
export interface Practice {
  Id: number
  PracticeName: string
}
export interface CompetencyType {
  Id: number
  CompetencyTypeName: string
}
