export interface CompetencylevelRes {
  code: number
  status: string
  message: string
  data: CompetencylevelModel[]
}
export interface CompetencylevelReq {
    code: number
    status: string
    message: string
    data: CompetencylevelModel
}

export interface CompetencylevelModel {
  Id: number
  ModifiedBy: ModifiedBy
  ModifiedAt: string
  CreatedAt: string
  CompetencyLevelName: string
}

export interface ModifiedBy {
  Id: number
  ResourceName: string
}
export interface Competencylevel {
    CompetencyLevelName: string
}