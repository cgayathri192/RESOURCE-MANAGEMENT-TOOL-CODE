export interface SkillRes {
  code: number
  status: string
  message: string
  data: SkillModel[]
}
export interface SkillReq {
  code: number
  status: string
  message: string
  data: SkillModel
}

export interface SkillModel {
  Id: number
  Employee: Employee
  Primary: boolean
  SkillVersion: number | null
  Competency: Competency
  CompetencyLevel: CompetencyLevel
  ModifiedBy: ModifiedBy
  ModifiedAt: string
  CreatedAt: string
}

export interface SkillUpdateModel {
  Skills: SkillModel,
  SkillsRemoved: number[]
}

export interface Employee {
  Id: number
  ResourceName: string
  IsActive: boolean
}

export interface Competency {
  Id: number
  CompetencyName: string
  CompetencyType: CompetencyType
}

export interface CompetencyType {
  Id: number
  CompetencyTypeName: string
}

export interface CompetencyLevel {
  Id: number
  CompetencyLevelName: string
}
export interface Practice {
  Id: number
  PracticeName: string
}

export interface ModifiedBy {
  Id: number
  ResourceName: string
}
