export interface CompetencyRes {
  code: number
  status: string
  message: string
  data: CompetencyModel[]
}
export interface CompetencyReq {
  code: number
  status: string
  message: string
  data: CompetencyModel
}
export interface CompetencyModel {
  Id: number
  CompetencyName: string
  CompetencyType: CompetencyType
  ModifiedBy: ModifiedBy
  ModifiedAt: string
  CreatedAt: string
}

export interface CompetencyType {
  Id: number
  CompetencyTypeName: string
}

export interface ModifiedBy {
  Id: number
  ResourceName: string
}

export interface Competency {
  CompetencyName: string
  CompetencyTypeId: number
}