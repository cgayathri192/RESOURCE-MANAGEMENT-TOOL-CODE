export interface EmployeeStatusRes {
    code: number
    status: string
    message: string
    data: EmployeeStatusModel[]
  }
  export interface EmployeeStatusReq {
    code: number
    status: string
    message: string
    data: EmployeeStatusModel
  }
  
  export interface EmployeeStatusModel{
    Id: number
    Employee: Employee
    Project: Project
    StartDate: string
    EndDate: string
    BillingStatus: BillingStatus
    ShadowToEmployee: ShadowToEmployee
    EffortPercentage: number
    Status: string
    ModifiedBy: ModifiedBy
    ModifiedAt: string
    CreatedAt: string
  }
  
  export interface Employee {
    Id: number
    ResourceName: string
    IsActive: boolean
  }
  
  export interface Project {
    Id: number
    ProjectName: string
  }
  
  export interface BillingStatus {
    Id: number
    BillingStatusName: string
  }
  
  export interface ShadowToEmployee {
    Id: number
    ResourceName: string
    IsActive: boolean
  }
  
  export interface ModifiedBy {
    Id: number
    ResourceName: string
  }
  