export interface DepartmentRes {
    code: number
    status: string
    message: string
    data: DepartmentModel[]
}
export interface DepartmentReq {
    code: number
    status: string
    message: string
    data: DepartmentModel
}

export interface DepartmentModel {
    Id: number
    DepartmentName: string
    Practice: Practice
    ModifiedBy: ModifiedBy
    ModifiedAt: string
    CreatedAt: string
    IsActive: boolean
}

export interface Practice {
    Id: number
    PracticeName: string
}

export interface ModifiedBy {
    Id: number
    ResourceName: string
}
export interface Department {
    DepartmentName: string
    PracticeId: number
}