export interface GradeRes {
    code: number
    status: string
    message: string
    data: GradeModel[]
  }
  export interface GradeReq{
    code: number
    status: string
    message: string
    data: GradeModel
  }
  
  export interface GradeModel {
    Id: number
    GradeName: string
    ModifiedBy: ModifiedBy
    ModifiedAt: string
    CreatedAt: string
  }
  
  export interface ModifiedBy {
    Id: number
    ResourceName: string
  }