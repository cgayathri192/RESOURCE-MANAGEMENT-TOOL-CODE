export interface StatusRes {
  code: number
  status: string
  message: string
  data: StatusModel[]
}
export interface StatusReq {
  code: number
  status: string
  message: string
  data: StatusModel
}

export interface StatusModel {
  Id: number
  Employee: Employee
  Projectstatus: string
  ModifiedBy: ModifiedBy
  ModifiedAt: string
  CreatedAt: string
}

export interface Employee {
  Id: number
  ResourceName: string
  IsActive: boolean
}


export interface ModifiedBy {
  Id: number
  ResourceName: string
}










