export interface EmployeeRes {
  code: number
  status: string
  message: string
  data: EmployeeModel[]
}

export interface EmployeeReq {
  code: number
  status: string
  message: string
  data: EmployeeModel
}
export interface EmployeeModel {
  Id: number
  EmployeeCompanyId: number
  ResourceName: string
  Email: string
  DateOfBirth: string
  Gender: string
  DateOfJoining: string
  ReportingManagerId: number
  ReportingManager: ReportingManager
  MouriTechExperience: string
  IsActive: boolean
  ModifiedBy: ModifiedBy
  ModifiedAt: string
  Role: Role
  Title: Title
  Location: Location
  Department: Department
  LeadershipTeamId: number
  LeadershipTeam: LeadershipTeam
  MouriTechTenurity: MouriTechTenurity
  Grade: Grade
  Practice: Practice
  Skills: SkillRes[]
  Passport: PassportRes
}

export interface ModifiedBy {
  Id: number
  ResourceName: string
}

export interface Role {
  Id: number
  RoleName: string
  Hierarchy: Hierarchy
  IsLeader : boolean
}

export interface Hierarchy {
  Id: number
  RoleName: string
}

export interface Title {
  Id: number
  TitleName: string
  Grade: Grade
  Department: Department
}

export interface Location {
  Id: number
  LocationName: string
}

export interface Department {
  Id: number
  DepartmentName: string
}

export interface EmployeeLeader {
  Id: number
  ResourceName: string
  IsActive: boolean
}


export interface MouriTechTenurity {
  Id: number
  MouriTechTenurityGroup: string
}

export interface Grade {
  Id: number
  GradeName: string
}


export interface Practice {
  Id: number
  PracticeName: string
}

export interface SkillRes {
  Id: number
  EmployeeId: number
  Primary: boolean
  SkillVersion: number
  Competency: Competency
  CompetencyLevel: CompetencyLevel
  // Employee: EmployeeLeader
  // ModifiedBy: ModifiedBy
  // ModifiedAt: string
  // CreatedAt: string
}

export interface Competency {
  Id: number
  CompetencyName: string
  CompetencyType: CompetencyType
}

export interface CompetencyType {
  Id: number
  CompetencyTypeName: string
  Practice: Practice
}

export interface CompetencyLevel {
  Id: number
  CompetencyLevelName: string
}

export interface PassportRes {
  Id: number
  EmployeeId: number
  PassportNumber: string
  PassportStatus: boolean
  PassportExpiry: string
  VisaType: VisaType
  VisaStatus: boolean
  VisaValidity: string
}

export interface VisaType {
  Id: number
  VisaTypeName: string
}


export interface Employee {
  EmployeeCompanyId: number
  ResourceName: string
  Email: string
  DateOfBirth: string
  Gender: string
  RoleId: string
  TitleId: string
  DateOfJoining: string
  LocationId: string
  PracticeId: string
  DepartmentId: string
  ReportingManagerId: number
  LeadershipTeamId: number
  MouriTechTenurityId: string
  GradeId: string
  password: string
  Skills : Skill[]
  SkillsRemoved: number[]
  Passport : Passport | null
}

export interface Skill {
  Id: number
  EmployeeId: number
  SkillVersion: number
  CompetencyTypeId: number
  CompetencyId: number
  CompetencyLevelId: number
  Primary: boolean,
}

export interface Passport {
  Id: number
  EmployeeId: number
  PassportNumber: string
  PassportStatus: boolean
  PassportExpiry: string
  VisaStatus: boolean | null
  VisaValidity: string | null
  VisaTypeId: number | null
}

export interface ReportingManager {
 Id: number
 ResourceName: string
 IsActive: boolean
}
export interface LeadershipTeam {
  Id: number
  ResourceName: string
  IsActive: boolean
}