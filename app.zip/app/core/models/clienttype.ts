export interface ClientTypeRes {
    code: number
    status: string
    message: string
    data: ClientTypeModel[]
  }
  export interface ClientTypeReq {
    code: number
    status: string
    message: string
    data: ClientTypeModel
  }
 
  export interface ClientTypeModel {
    Id: number
    ModifiedBy: ModifiedBy
    ModifiedAt: string
    CreatedAt: string
    ClientTypeName: string
  }
 
  export interface ModifiedBy {
    Id: number
    ResourceName: string
  }