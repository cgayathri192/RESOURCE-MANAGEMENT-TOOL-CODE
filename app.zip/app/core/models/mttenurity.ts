export interface MttenurityRes {
  code: number
  status: string
  message: string
  data: MttenurityModel[]
}
export interface MttenurityReq {
  code: number
  status: string
  message: string
  data: MttenurityModel
}
export interface MttenurityModel {
  Id: number
  ModifiedBy: ModifiedBy
  ModifiedAt: string
  CreatedAt: string
  MouriTechTenurityGroup: string
}

export interface ModifiedBy {
  Id: number
  ResourceName: string
}

export interface Mttenurity {
  Id:number
  MouriTechTenurityGroup: string
}