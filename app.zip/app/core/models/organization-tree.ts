import { TreeNode } from "./tree-node"

export interface OrganizationTreeRes {
    code: string
    status: string
    message: string
    data: OrganizationTree
  }
  
  export interface OrganizationTree extends TreeNode{
    Id: number
    ResourceName: string
    Title: string
    Role: string
    Location: string
    Practice: string
    Department: string
    children: OrganizationTree[]
  }
  

  