export interface RelieveRes {
    code: number
    status: string
    message: string
    data: RelieveModel[]
  }
  export interface RelieveReq {
    code: number
    status: string
    message: string
    data: RelieveModel
  }
export interface RelieveModel {
    RelievedAt: string
    RelievingReason: string
    EmployeeId: number
  
  }