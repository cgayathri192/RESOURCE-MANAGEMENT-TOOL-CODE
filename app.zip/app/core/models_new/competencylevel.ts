export interface CompetencylevelRes {
    code: number
    status: string
    message: string
    data: CompetencylevelModel[]
  }
  
  export interface CompetencylevelReq {
    code: number
    status: string
    message: string
    data: CompetencylevelModel[]
  }

  export interface CompetencylevelModel {
    Id: number
    CompetencyLevel: string
    // CreatedBy: CreatedBy
    CreatedDateTime: string
    ModifiedBy: ModifiedBy
    ModifiedDateTime: string
  }
  
  export interface CreatedBy {
    Id: number
    AssociateName: string
  }
  
  export interface ModifiedBy {
    Id: number
    AssociateName: string
  }

  export interface Competencylevel {
    CompetencyLevel: string
}
  