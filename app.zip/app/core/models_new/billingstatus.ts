export interface BillingStatusRes {
  code: number
  status: string
  message: string
  data: BillingStatusModel[]
}
export interface BillingStatusReq {
  code: number
  status: string
  message: string
  data: BillingStatusModel
}
export interface BillingStatusModel {
  Id: number
  BillingStatus: string
  CreatedBy: CreatedBy
  CreatedDateTime: string
  ModifiedBy: ModifiedBy
  ModifiedDateTime: string
}

export interface CreatedBy {
  Id: number
  AssociateName: string
}

export interface ModifiedBy {
  Id: number
  AssociateName: string
}
