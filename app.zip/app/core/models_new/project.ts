export interface ProjectRes {
    code: number
    status: string
    message: string
    data: ProjectModel[];
  }
  export interface ProjectReq {
    code: number
    status: string
    message: string
    data: ProjectModel;
  }
  
  export interface ProjectModel {
    Id: number
    Project: string
    ClientId: number
    ProjectTypeId: number
    Program: string
    KEKA_ProjectCode: string
    StartDate: string
    EndDate: string
    Status: string
    Duration: number
    BudgetedHours: number
    BudgetedAmount: number
    ProjectStatus: string
    ERP_ProjectCode: string
    SowNumber: number
    PurchasedOrderNumber: number
    IsActive: boolean
  }
  export interface Project{
    Project: string;
    Status: string;
    ProjectTypeId: number;
    Program: string;
    StartDate: string;
    EndDate: string;
    KEKA_ProjectCode: string;
    Duration: number;
    BudgetedHours: number;
    BudgetedAmount: number;
    ProjectStatus: string;
    ERP_ProjectCode: string;
    SowNumber: number;
    PurchasedOrderNumber: number;
    IsActive: boolean;
  }
 
 