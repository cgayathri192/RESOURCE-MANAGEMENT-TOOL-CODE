export interface LocationRes {
    code: number
    status: string
    message: string
    data: locationModel[]
  }
  export interface LocationReq {
    code: number
    status: string
    message: string
    data: locationModel
  }
  export interface locationModel {
    Id: number
    ModifiedBy: ModifiedBy
    ModifiedDateTime: string
    CreatedDateTime : string
    CreatedBy: string
    Location: string
    LocationCode:string
  }
  
  export interface ModifiedBy {
    Id: number
    AssociateName: string
  }
  
  export interface CreatedBy {
     Id:number
     AssociateName: string
  }

  export interface Location {
    Location: string
  }