export interface SkillRes {
  code: number
  status: string
  message: string
  data: SkillModel[]
}
export interface SkillReq {
  code: number
  status: string
  message: string
  data: SkillModel
}

export interface SkillModel {
  Id: number
  Associate: Associate
  CompetencyType: CompetencyType
  Competency: Competency
  CompetencyLevel: CompetencyLevel
  Primary: boolean
  CompetencyVersion: number
  CreatedBy: CreatedBy
  CreatedDateTime: string
  ModifiedBy: ModifiedBy
  ModifiedDateTime: string
}

export interface skillUpdate {
  Competenciesdata: SkillUpdateModel[]
  CompetenciesRemoved: number[]
}

export interface SkillUpdateModel {
  Id: number
  AuthUserId: number
  CompetencyVersion: any
  CompetencyTypeId: any
  CompetencyId: number
  CompetencyLevelId: string
  Primary: boolean
}
export interface Associate {
  Id: number
  AssociateName: string
  CompanyId: number
  Practice: Practice
  Department: Department
  IsActive: boolean
}

export interface Practice {
  Id: number
  Practice: string
}

export interface Department {
  Id: number
  Department: string
}

export interface CompetencyType {
  Id: number
  CompetencyType: string
  Practice: Practice
}

export interface Competency {
  Id: number
  Competency: string
  CompetencyType: CompetencyType
}

export interface CompetencyLevel {
  Id: number
  CompetencyLevel: string
}

export interface CreatedBy {
  Id: number
  AssociateName: string
}

export interface ModifiedBy {
  Id: number
  AssociateName: string
}
