export interface CompetencyRes {
  code: number
  status: string
  message: string
  data: CompetencyModel[]
}

export interface CompetencyReq {
  code: number
  status: string
  message: string
  data: CompetencyModel
}

export interface CompetencyModel {
  Id: number
  Competency: string
  CompetencyType: CompetencyType
  CreatedBy: CreatedBy
  CreatedDateTime: string
  ModifiedBy: ModifiedBy
  ModifiedDateTime: string
}

export interface CompetencyType {
  Id: number
  CompetencyType: string
  Practice: Practice
}

export interface Practice {
  Id: number
  Practice: string
}

export interface CreatedBy {
  Id: number
  AssociateName: string
}

export interface ModifiedBy {
  Id: number
  AssociateName: string
}
