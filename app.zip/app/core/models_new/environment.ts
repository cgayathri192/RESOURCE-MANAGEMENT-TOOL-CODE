export interface Environment {
    production: boolean,
    environmentName: string,
    baseApi: string
    endpoints: {
        AssociateCompetencies:string;
        employeeCountbilling:string;
        employeeCountByMTTenurity:string;
        AllEmployee: string;
        employeeExcelInsert: string;
        employeeExcelTemplateResponse: string;
        employeeExcelTemplate: string;
        skillExcelInsert:string;
        skillExcelTemplate:string;
        skillExcelTemplateResponse:string;
        employeeSkillsLocationCount: string;
        employeeLocationCount: string;
        employeeEffort: string;
        organizationTree: string;
        changepassword: string;
        projectstatus: string;
        competencylevel: string;
        employee: string;
        associate:string;
        employeeRegistration: string;
        skill: string;
        skill_update:string;
        role: string;
        location: string;
        practice: string;
        competency: string;
        competencytype: string;
        department: string;
        title: string;
        mttenurity:string;
        visatype:string;
        passport:string;
        login: string;
        grade:string;
        relieve:string;
        client:string;
        projecttype:string;
        refreshToken: string;
        clienttype:string;
        project:string;
        BillingStatus:string;
        EmployeeProjectMapping:string
        empstatus:string;
        blankallocation:string;
        countries:string;
        clientdomain: string;
    }
}
