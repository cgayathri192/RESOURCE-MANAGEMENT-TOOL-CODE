export interface Mttenurity {
  MouriTechTenurityGroup: string
}