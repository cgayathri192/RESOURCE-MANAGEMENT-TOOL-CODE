export interface ProjectTypeRes {
  code: number
  status: string
  message: string
  data: ProjectTypeModel[]
}

export interface ProjectTypeReq {
  code: number
  status: string
  message: string
  data: ProjectTypeModel
}

export interface ProjectTypeModel {
  Id: number
  ProjectType: string
  CreatedBy: CreatedBy
  CreatedDateTime: string
  ModifiedBy: ModifiedBy
  ModifiedDateTime: string
}

export interface CreatedBy {
  Id: number
  AssociateName: string
}

export interface ModifiedBy {
  Id: number
  AssociateName: string
}
