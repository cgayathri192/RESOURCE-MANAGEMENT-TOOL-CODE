export interface visaTypeRes {
    code: number
    status: string
    message: string
    data: VisatypeModel[]
}

export interface visaTypeReq {
    code: number
    status: string
    message: string
    data: VisatypeModel
}

export interface VisatypeModel {
    Id: number
    ModifiedBy: ModifiedBy
    ModifiedDateTime: string
    CreatedBy: string
    VisaType: string
    IsActive: boolean
}

export interface ModifiedBy {
    Id: number
    AssociateName: string
}

export interface Visatype {
    VisaType: string
}