

export interface ProjectMappingRes {
    code: number
    status: string
    message: string
    data: ProjectMappingModel[]
  }
  export interface ProjectMappingReq {
    code: number
    status: string
    message: string
    data: ProjectMappingModel
  }
  
  export interface ProjectMappingModel {
    Id: number
    AuthUserId: number
    ProjectId: number
    StartDate: string
    EndDate: string
    BillingStatusId: number
    BillingStatus:BillingStatus
    ShadowToAssociate: AssociateModel
    EffortPercentage: number
    Status: string
    Associate:AssociateModel
    IsActive: boolean
    Project:ProjectModel
  }

  export interface AssociateModel{
      Id: number;
      AssociateName: string;
      CompanyId: number; 
      Department: {Id: number, Department: string};
      IsActive: boolean
      Practice: {Id: number, Practice: string}
  }

  export interface ProjectModel{
    Id:number
    Project:string
  }
  export interface BillingStatus {
    Id: number
    BillingStatus: string
  }

  export interface ProjectMapping {
    BillingStatusId:string
    BillingStatus: string
    EndDate:string
    StartDate:string
    ProjectId:number
    AuthUserId:number
    IsActive:boolean
    ShadowToAssociateId:number
    EffortPercentage: number
    Status: string
    ModifiedBy?: string
    ModifiedDateTime?: string
    CreatedDateTime?: string
}