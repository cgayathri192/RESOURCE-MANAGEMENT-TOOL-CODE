export interface TitleRes {
    code: number
    status: string
    message: string
    data: TitleModel[]
  }
  
  export interface TitleReq {
    code: number
    status: string
    message: string
    data: TitleModel
  }
  
  export interface TitleModel {
    Id: number
    ModifiedBy: ModifiedBy
    ModifiedDateTime: string
    CreatedDateTime: string
    CreatedBy:string
    Title: string
    Grade: Grade
    Department: Department
  }
  
  export interface Grade {
    Id: number
    GradeName: string
  }
  
  export interface Department {
    Id: number
    DepartmentName: string
  }
  
  export interface ModifiedBy {
    Id: number
    AssociateName: string
  }
  
  export interface Title {
    Title: string
  }