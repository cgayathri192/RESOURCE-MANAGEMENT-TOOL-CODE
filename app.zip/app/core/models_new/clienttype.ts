export interface ClientTypeRes {
    code: number
    status: string
    message: string
    data: ClientTypeModel[]
  }
  export interface ClientTypeReq {
    code: number
    status: string
    message: string
    data: ClientTypeModel
  }
 
  export interface ClientTypeModel {
    Id: number
    ModifiedBy: ModifiedBy
    ModifiedDateTime: string
    CreatedDateTime: string 
    ClientDomain: string //clientTypeName -> ClientDomain
  }
 
  export interface ModifiedBy {
    Id: number
    AssociateName: string
  }