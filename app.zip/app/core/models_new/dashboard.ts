 export interface Associate {
    competency: string
    count: number
  }

  export interface LocationSkills {
    city: string
    Associate: Associate[]
  }
  
  export interface AssociateLocationRes {
    code: number
    status: string
    message: string
    LocationData: Location[]
  }
  
  export interface Location {
    Location: string
    AssocaiateCount: number
  }
  
  /////
  // export interface AllEmployeeRes {
  //   code: number
  //   status: string
  //   message: string
  //   data: AllEmployee[]
  // }
  // export interface AllEmployee {
  //   TotalEmployes: number
  //   TotalClients: number
  //   BenchCount: number
  //   BillableStatus: BillableStatus[]
  // }
  // export interface BillableStatus {
  //   BillingStatusNames: string
  //   count: number
  // }

  export interface AllEmployeeRes {
    code: number
    status: string
    message: string
    data: AllEmployee
  }
  
  export interface AllEmployee {
    TotalClientsCount: number
    TotalProjectsCount: number
    LocationData: BillableStatus[]
  }
  
  export interface BillableStatus {
    Location: string
    TotalAssociatesCount: number
    Billable: number
    NonBillable: number
  }
  
  
////
  // export interface TenurityLocationRes {
  //   code: number
  //   status: string
  //   message: string
  //   locations: TenurityLocation[]
  // }
  // export interface TenurityLocation {
  //   city: string
  //   employees: TenurityEmployee[]
  // }
  
  // export interface TenurityEmployee {
  //   MouriTechTenurityGroup: string
  //   count: number
  // }

  /////


  export interface TenurityLocationRes {
    code: number
    status: string
    message: string
    locations: TenurityLocation[]
  }
  
  export interface TenurityLocation {
    city: string
    associates: TenurityEmployee[]
  }
  
  export interface TenurityEmployee {
    MouriTechTenurityGroup: string
    count: number
  }
  

  export interface EmployeebillingRes {
    code: number
    status: string
    message: string
    data: Employeebilling
  }
  
  export interface Employeebilling {
    TotalClientsCount: number
    TotalProjectsCount: number
    LocationData: LocationData[]
  }
  
  export interface LocationData {
    Location: string
    TotalAssociatesCount: number
    Billable: number
    NonBillable: number
  }

  
  export interface EmployeeSkillsRes {
    code: number
    status: string
    message: string
    locations: LocationSkills[]
  }
  

  
  
