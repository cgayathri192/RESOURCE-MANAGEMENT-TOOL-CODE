export interface PracticeRes {
  code: number
  status: string
  message: string
  data: PracticeModel[]
}

export interface PracticeReq {
  code: number
  status: string
  message: string
  data: PracticeModel
}

export interface PracticeModel {
  Id: number
  Practice: string
  IsActive: boolean
  CreatedBy: CreatedBy
  CreatedDateTime: string
  ModifiedBy: ModifiedBy
  ModifiedDateTime: string
}

export interface CreatedBy {
  Id: number
  AssociateName: string
}

export interface ModifiedBy {
  Id: number
  AssociateName: string
}

export interface Practice {
  Practice: string
}
