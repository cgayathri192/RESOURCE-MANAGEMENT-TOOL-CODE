export interface PassportRes {
    code: number
    status: string
    message: string
    data: PassportModel[]
  }
  
  export interface PassportModel {
    Id: number
    Associate: Associate
    PassportStatus: boolean
    PassportExpiry: string
    CreatedBy: CreatedBy
    CreatedDateTime: string
    ModifiedBy: ModifiedBy
    ModifiedDateTime: string
  }

  export interface Passport {
    Id: number;
    AuthUserId: number;
    PassportStatus: boolean;
    PassportExpiry: string;
}

export interface Visa {
    Id: number;
    AuthUserId: number;
    VisaTypeId: number;
    VisaValidity: string;
    VisaStatus: boolean;
}

export interface PassportModelUpdate {
    Passport: Passport;
    Visa: Visa[];
    VisaRemoved: number[];
}

  export interface Associate {
    Id: number
    AssociateName: string
    CompanyId: number
    Practice: Practice
    Department: Department
    IsActive: boolean
  }
  
  export interface Practice {
    Id: number
    Practice: string
  }
  
  export interface Department {
    Id: number
    Department: string
  }
  
  export interface CreatedBy {
    Id: number
    AssociateName: string
  }
  
  export interface ModifiedBy {
    Id: number
    AssociateName: string
  }
  