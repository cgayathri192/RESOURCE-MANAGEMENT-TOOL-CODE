export interface ClientRes {
    code: number
    status: string
    message: string
    data: ClientModel[]
  }
  export interface ClientReq{
    code: number
    status: string
    message: string
    data: ClientModel
  }
  
  export interface ClientModel {
    Id: number
    Client: string
    Email: string
    ClientCode: string
    ClientDomain: ClientDomain
    BusinessNumber: string
    Website: string
    City: string
    Country: Country
    ZipCode: string
    EndDate: string
    Status: string
    IsActive: boolean
    CreatedBy: CreatedBy
    CreatedDateTime: string
    ModifiedBy: ModifiedBy
    ModifiedDateTime: string
  }
  
  export interface ClientDomain {
    Id: number
    ClientDomain: string
  }
  
  export interface Country {
    CountryCode: string
    CountryName: string
  }
  
  export interface CreatedBy {
    Id: number
    AssociateName: string
  }
  
  export interface ModifiedBy {
    Id: number
    AssociateName: string
  }
  
  export interface Client {
    Id: number
    Client: string
    Email: string
    ClientCode: string
    ClientDomain: ClientDomain
    ClientIndustry: string
    BusinessNumber: string
    Website: string
    City: string
    Country: Country
    ZipCode: string
    EndDate: string
    Status: string
    IsActive: boolean
    CreatedBy: CreatedBy
    CreatedDateTime: string
    ModifiedBy: ModifiedBy
    ModifiedDateTime: string
  }