export interface RoleRes {
    code: number
    status: string
    message: string
    data: RolesModel[]
}
export interface RoleReq {
    code: number
    status: string
    message: string
    data: RolesModel
}
export interface RolesModel {
    Id: number
    ModifiedBy: ModifiedBy
    ModifiedDateTime: string
    CreatedDateTime: string
    CreatedBy: CreatedBy
    UserRole: string
    IsLeader: boolean
    HierarchyId: number
    Hierarchy: Hierarchy
}

export interface ModifiedBy {
    Id: number
    AssociateName: string
}
export interface CreatedBy {
    Id: number
    AssociateName: string
}
export interface Roles {
    UserRole: string
    IsLeader: boolean
    HierarchyId: number
}

export interface Hierarchy {
    Id: number
    UserRole: string
}