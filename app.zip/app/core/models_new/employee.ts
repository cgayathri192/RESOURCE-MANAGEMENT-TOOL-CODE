export interface EmployeeRes {
  code: number
  status: string
  message: string
  data: EmployeeModel[]
}

export interface EmployeeReq {
  code: number
  status: string
  message: string
  data: EmployeeModel
}

export interface EmployeeModel {
  Id: number
  AssociateName: string
  Email: string
  Gender: string
  DateOfBirth: string
  DateOfJoining: string
  Contact: string
  IsActive: boolean
  CompanyId: number
  UserRole: UserRole
  Practice: Practice
  Department: Department
  LeadershipTeam: LeadershipTeam
  ReportingManager: ReportingManager
  Grade: Grade
  Title: Title
  Location: Location
  Competencies: Competency[]
  Passport: Passport
  Visa: Visa[]
  ClientBillable: boolean;//new property
  CreatedBy: CreatedBy
  CreatedDateTime: string
  ModifiedBy: ModifiedBy
  ModifiedDateTime: string
  MouriTechTenurity:string
  MouriTechExperience: string
}


export interface UserRole {
  Id: number
  UserRole: string
}

export interface Practice {
  Id: number
  Practice: string
}

export interface Department {
  Id: number
  Department: string
  Practice: Practice
  IsActive: boolean
}

export interface LeadershipTeam {
  Id: number
  AssociateName: string
  CompanyId: number
  Practice: Practice
  Department: Department2
  IsActive: boolean
}

export interface Department2 {
  Id: number
  Department: string
}

export interface ReportingManager {
  Id: number
  AssociateName: string
  CompanyId: number
  Practice: Practice
  Department: Department2
  IsActive: boolean
}

export interface Grade {
  Id: number
  Grade: string
}

export interface Title {
  Id: number
  Title: string
  Grade: Grade
  Department: Department
}

export interface MouriTechTenurity {
  Id: number
  MouriTechTenurityGroup: string
}

export interface Location {
  Id: number
  Location: string
  LocationCode: string
}

export interface Competency {
  Id: number
  AuthUserId: AuthUserId
  CompetencyType: CompetencyType
  Competency: Competency2
  CompetencyLevel: CompetencyLevel
  Primary: boolean
  CompetencyVersion: number
}

export interface AuthUserId {
  Id: number
  AssociateName: string
}

export interface CompetencyType {
  Id: number
  CompetencyType: string
}

export interface Competency2 {
  Id: number
  Competency: string
}

export interface CompetencyLevel {
  Id: number
  CompetencyLevel: string
}

export interface Passport {
  Id: number
  AuthUserId: AuthUserId
  PassportStatus: boolean
  PassportExpiry: string
}

export interface Visa {
  Id: number
  AuthUserId: AuthUserId
  VisaTypeId: VisaTypeId
  VisaValidity: string
  VisaStatus: boolean
}

export interface VisaTypeId {
  Id: number
  VisaType: string
}

export interface CreatedBy {
  Id: number
  AssociateName: string
}

export interface ModifiedBy {
  Id: number
  AssociateName: string
}
