export interface DepartmentRes {
    code: number
    status: string
    message: string
    data: DepartmentModel[]
  }

  export interface DepartmentReq {
    code: number
    status: string
    message: string
    data: DepartmentModel
  }
  
  export interface DepartmentModel {
    Id: number
    Department: string
    Practice: Practice
    CreatedBy: CreatedBy
    CreatedDateTime: string
    ModifiedBy: ModifiedBy
    ModifiedDateTime: string
    IsActive: boolean
  }
  
  export interface Practice {
    Id: number
    Practice: string
  }
  
  export interface CreatedBy {
    Id: number
    AssociateName: string
  }
  
  export interface ModifiedBy {
    Id: number
    AssociateName: string
  }

  export interface Department {
    Department: string
    PracticeId: number
}
  