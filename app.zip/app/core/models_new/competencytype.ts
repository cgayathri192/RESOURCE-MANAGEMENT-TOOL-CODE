export interface CompetencyTypeRes {
  code: number
  status: string
  message: string
  data: CompetencyTypeModel[]
}
export interface CompetencyReq {
  code: number
  status: string
  message: string
  data: CompetencyTypeModel
}

export interface CompetencyTypeModel {
  Id: number
  CompetencyType: string
  Practice: Practice
  CreatedBy: CreatedBy
  CreatedDateTime: string
  ModifiedBy: ModifiedBy
  ModifiedDateTime: string
}

export interface Practice {
  Id: number
  Practice: string
}

export interface CreatedBy {
  Id: number
  AssociateName: string
}

export interface ModifiedBy {
  Id: number
  AssociateName: string
}
