export interface GradeRes {
    code: number
    status: string
    message: string
    data: GradeModel[]
  }

  export interface GradeReq{
    code: number
    status: string
    message: string
    data: GradeModel
  }
  
  export interface GradeModel {
    Id: number
    Grade: string
    CreatedDateTime:string
    ModifiedDateTime:string
    ModifiedBy: ModifiedBy
    CreatedBy: CreatedBy
    ModifiedAt: string
  }
  
  export interface ModifiedBy {
    Id: number
    AssociateName: string
  }

  export interface CreatedBy {
    Id: number
    AssociateName: string 
  }



  
