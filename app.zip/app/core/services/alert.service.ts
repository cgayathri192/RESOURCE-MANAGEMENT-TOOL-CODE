import { Injectable } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { AlertComponent } from '@shared/alert/alert.component';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AlertService {

  constructor(private dialog: MatDialog) { }

    public show(title: string, message: string): Observable<boolean> {
        let dialogRef: MatDialogRef<AlertComponent>;
        dialogRef = this.dialog.open(AlertComponent, { panelClass: 'alert-wrapper'});
        dialogRef.componentInstance.title = title;
        dialogRef.componentInstance.message = message;
        return dialogRef.afterClosed();
    }
}
