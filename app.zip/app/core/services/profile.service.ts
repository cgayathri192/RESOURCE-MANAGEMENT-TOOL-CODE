import { Injectable } from '@angular/core';
import { ProfileInitials } from '@core/models/profileInitials';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProfileService {
  public showInitials = false;
  public name: string = '';
  public circleColor: string = '';
  public $initials: BehaviorSubject<string> = new BehaviorSubject<string>('');
  constructor() {
    this.showInitials = true;
  }
  set setInitials(value: string) {
    if (this.$initials.value != value) {
      this.$initials.next(value);
    }
  }
  public createInititals(profileName : string): void {
    const names = profileName?.split(' ');
    let initials = '';

    if (names && names.length >= 2) {
      initials += names[0][0].toUpperCase();
      initials += names[names.length - 1][0].toUpperCase();
    } else if (names && names.length === 1) {
      initials = names[0].substring(0, 2).toUpperCase();
    }
    this.circleColor=this.generateColor(initials)
    this.setInitials= initials;
  }
  generateColor(initials: string): string {
    // Convert initials to a numeric hash value
    let hash = 0;
    for (let i = 0; i < initials.length; i++) {
      hash = initials.charCodeAt(i) + ((hash << 5) - hash);
    }

    // Generate color based on the hash value
    const hue = Math.abs(hash % 360);
    const saturation = 70; // Adjust as desired
    const lightness = 60; // Adjust as desired

    return `hsl(${hue}, ${saturation}%, ${lightness}%)`;
  }
  public generateProfileInititals(profileName : string): ProfileInitials {
    const names = profileName.split(' ');
    let initials = '';

    if (names.length >= 2) {
      initials += names[0][0].toUpperCase();
      initials += names[names.length - 1][0].toUpperCase();
    } else if (names.length === 1) {
      initials = names[0].substring(0, 2).toUpperCase();
    }
    let profileInitials: ProfileInitials={
      initial:initials,
      color: this.generateColor(initials)
    }
    return profileInitials
  }
}
