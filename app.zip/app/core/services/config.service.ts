import { Injectable } from '@angular/core';
import { Environment } from '@core/models_new/environment';
import { environment } from '../../../../src/environments/environment';
@Injectable({
  providedIn: 'root'
})
export class ConfigService {
  environment: Environment= environment;
  constructor() { }
}
