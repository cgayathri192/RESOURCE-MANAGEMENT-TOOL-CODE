import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ConfigService } from './config.service';

@Injectable({
  providedIn: 'root'
})
export class ExcelService {
  baseurl: string;

  constructor(private http:HttpClient, private config : ConfigService) {
    this.baseurl= config.environment.baseApi;
   }
  downloadExcelTemplate(endpoint: string): Observable<any> {
    return this.http.get(`${this.baseurl}/${endpoint}`, { responseType: 'blob' });
  }
  UploadExcelTemplate(endpoint: string, formData: FormData): Observable<any> {
    return this.http.post(`${this.baseurl}/${endpoint}`, formData);
  }
  
}
