import { Injectable } from '@angular/core';
import { Menu } from '@core/models/menu';

@Injectable({
  providedIn: 'root'
})
export class NavigationService {
  menu: Menu[] = [
    {
      label: 'Dashboard', link: '/home', icon: 'home', order: 1, isAdmin: false
    },
    {
      label: 'Resources', link: '/home/employee', icon: 'home', order: 2, isAdmin: false,
      children: [
        { label: 'Associates', link: '/home/employee', icon: 'person', order: 1 , isAdmin: false},
        { label: 'Skills', link: '/home/skill', icon: 'assignment', order: 2, isAdmin: true},
        { label: 'Roles', link: '/home/role', icon: 'person_pin', order: 11 , isAdmin: true},
        { label: 'Location', link: '/home/location', icon: 'my_location', order: 6, isAdmin: true},
        { label: 'Practice',link:'/home/practice',icon:'category',order: 7, isAdmin: true},
        { label: 'Competency', link: '/home/competency', icon: 'category', order: 4 , isAdmin: true},
        { label: 'Competency Type', link: '/home/competencytype', icon: 'category', order: 3 , isAdmin: true},
        { label: 'Competency Level',link:'/home/competencylevel',icon:'category',order:5, isAdmin: true},
        { label: 'Department', link: '/home/department', icon: 'domain', order: 8 , isAdmin: true},
        { label: 'Title', link: '/home/title', icon: 'title', order: 10, isAdmin: true },
        { label: 'Visa Type', link: '/home/visatype', icon: 'category', order: 14 , isAdmin: true},
        { label: 'Passport', link: '/home/passport', icon: 'category', order: 13, isAdmin: true },
        { label: 'Grade', link: '/home/grade', icon: 'category', order: 9 , isAdmin: true},
        { label: 'Associate Excel Import', link: '/home/employeeexcel', icon: 'category', order: 15 , isAdmin: true},
        { label: 'Organization Tree', link: '/home/tree', icon: 'category', order: 17 , isAdmin: false},
        { label: 'Skill Excel Import', link: '/home/skillexcel', icon: 'category', order: 16 , isAdmin: true}
      ]
    },
    {
      label: 'Project', link: '/project/project', icon: 'work', order: 19, isAdmin: true,
      children: [
        { label: 'Client', link: '/project/client', icon: 'work', order: 20,isAdmin: true },
        { label: 'Client Type', link: '/project/client-type', icon:'work', order:21, isAdmin:true},
        { label: 'Project Type', link: '/project/projecttype', icon: 'work', order: 21,isAdmin: true },
        { label: 'Project', link: '/project/project-details', icon: 'work', order: 21,isAdmin: true },
        { label: 'Billing Status', link: '/project/billingstatus', icon: 'work', order: 22,isAdmin: true },
        { label: 'Project Mapping', link: '/project/projectmapping', icon: 'work', order: 23,isAdmin: true },
        { label: 'Employee Status', link: '/project/employeestatus', icon: 'work', order: 21,isAdmin: true },
        { label: 'Blank Allocation', link: '/project/blankallocation', icon: 'work', order: 21,isAdmin: true },
      ]
    },
    {
      label:'Timesheet' , link:'/timesheet/uploadfile' ,icon:'assignment' ,order:25,isAdmin:true,
      children:[
        {label:'Upload',link:'/timesheet/uploadfile',icon:'upload',order:26,isAdmin:true},
      ]
    }
  ];

  constructor() { 
  }
  getMenus(roleIdIsLeader: boolean): Menu[] {
    if (roleIdIsLeader == false) {
      let menulist: Menu[]=this.menu.filter(item => !item.isAdmin).map(item => {
        if (item.children) {
          const filteredChildren = item.children.filter(child => !child.isAdmin);
          return { ...item, children: filteredChildren };
        }
        return item;
      });
      return menulist;
    }
    else {
      return this.menu;
    }
  }
}
