import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { catchError, map, Observable, throwError } from 'rxjs';
import { Response } from '@core/models/response';
import { JwtToken, Tokens } from '@core/models/tokens';
import { Router } from '@angular/router';
import { ConfigService } from './config.service';
import jwt_decode from 'jwt-decode';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  baseurl: string;
  tokenDetails!: JwtToken;
  constructor(private http: HttpClient, private router: Router, private config: ConfigService) {
    this.baseurl = config.environment.baseApi;
  }

  resetPassword(oldpassword: string, newpassword: string): Observable<any> {
    const payload = {
      oldpassword: oldpassword,
      newpassword: newpassword
    };
    return this.http.put<any>(`${this.baseurl}/${this.config.environment.endpoints.changepassword}`, payload);
  }

  login(email: string, password: string): Observable<Response<Tokens>> {
    const body = { Email: email, password: password };
    return this.http.post<Response<Tokens>>(`${this.baseurl}/${this.config.environment.endpoints.login}`, body)
      .pipe(
        map((response: Response<Tokens>) => {
          this.storeTokens(response.data)
          return response;
        }),
        catchError((error) => throwError(() => error))
      );
  }

  private storeTokens(tokens: Tokens) {
    if (tokens) {
      this.setTokenDetails(tokens.access);
      localStorage.setItem('access_token', tokens.access);
      localStorage.setItem('refresh_token', tokens.refresh);
    }
  }

  getAccessToken(): string | null {
    return localStorage.getItem('access_token');
  }

  private getRefreshToken(): string | null {
    return localStorage.getItem('refresh_token');
  }

  refreshAccessToken(): Observable<Tokens> {
    const refreshToken = this.getRefreshToken();
    if (!refreshToken) {
      return throwError(() => 'Refresh token not found');
    }
    return this.http.post<any>(`${this.baseurl}/${this.config.environment.endpoints.refreshToken}`, { refresh: refreshToken })
      .pipe(
        map(response => {
          let tokens: Tokens = {
            refresh: refreshToken,
            access: response.access
          }
          this.storeTokens(tokens);
          return tokens;
        }),
        catchError(error => throwError(() => error))
      );
  }
  isLoggedIn(): boolean {
    const accessToken = this.getAccessToken();
    if (!!accessToken) {
      return true;
    } else {
      this.router.navigate(['/login']);
      return false;
    }
  }
  setTokenDetails(token: string): void {
    this.tokenDetails = jwt_decode(token);
  }
  getTokenDetails(): JwtToken {
    if (!this.tokenDetails) {
      let accessToken: string = this.getAccessToken() ?? '';
      this.setTokenDetails(accessToken);
    }
    return this.tokenDetails;
  }
  isAdmin() {
    if (this.tokenDetails) {
      return this.tokenDetails.RoleIdIsLeader;
    }
    else {
      this.router.navigate(['/']);
      return false;
    }
  }
  logout() {
    localStorage.removeItem('access_token');
    localStorage.removeItem('refresh_token');
    this.router.navigate(['/login']);
  }
}
