import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ConfigService } from './config.service';

@Injectable({
  providedIn: 'root'
})
export class GenericRepositoryService<T> {

  baseurl: string;
  constructor(private http: HttpClient, private config : ConfigService) {
    this.baseurl= config.environment.baseApi;
  }
  get(endpoint: string): Observable<T> {
    return this.http.get<T>(`${this.baseurl}/${endpoint}`);
  }
  getById(endpoint: string, id: number | string): Observable<T> {
    return this.http.get<T>(`${this.baseurl}/${endpoint}/${id}`);
  }
  create(endpoint: string, item: T): Observable<T> {
    return this.http.post<T>(`${this.baseurl}/${endpoint}`, item);
  }
  update(endpoint: string, id: number | string | null, item: T): Observable<T> {
    let url: string='';
    if(id){
      url=`${this.baseurl}/${endpoint}/${id}`;
    }
    else{
      url=`${this.baseurl}/${endpoint}`;
    }
    return this.http.put<T>(url, item);
  }
  delete(endpoint: string, id: number | string): Observable<T> {
    return this.http.delete<T>(`${this.baseurl}/${endpoint}/${id}`);
  }
}
export interface CrudService<T> {
  get(endpoint: string): Observable<T>;
  getById(endpoint: string, id: number | string): Observable<T>;
  create(endpoint: string, item: T): Observable<T>;
  update(endpoint: string, id: number | string, item: T): Observable<T>;
  delete(endpoint: string, id: number | string): Observable<T>;
}
