import { Component, inject, Inject } from '@angular/core';
import {FormGroup,FormBuilder,FormControl,Validators, ValidatorFn,} from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ClientModel, ClientRes } from '@core/models_new/client';
import { ProjectModel, ProjectReq } from '@core/models_new/project';
import { ProjectTypeModel, ProjectTypeRes } from '@core/models_new/projecttype';
import { ConfigService } from '@core/services/config.service';
import { GenericRepositoryService } from '@core/services/generic-repository.service';
import { DatePipe } from '@angular/common';
import { DateAdapter, MAT_DATE_FORMATS } from '@angular/material/core';
import { AppDateAdapter, APP_DATE_FORMATS } from '@core/common/dateAdapter';
import { AlertService } from '@core/services/alert.service';
import { Observable } from 'rxjs';


@Component({
  selector: 'app-project-edit',
  templateUrl: './project-edit.component.html',
  styleUrls: ['./project-edit.component.scss'],
  providers: [
    { provide: DateAdapter, useClass: AppDateAdapter },
    { provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS },
  ],
})
export class ProjectEditComponent {
  projectForm: FormGroup;
  clientFilterControl = new FormControl();
  ClientListOptions!:ClientModel[];
  filteredClientList!: Observable<any[]>;
  ClientList!: ClientModel[];
  projectTypeService = inject(GenericRepositoryService<ProjectTypeRes>);
  clientServices = inject(GenericRepositoryService<ClientRes>);
  ProjectTypeList!: ProjectTypeModel[];
  isSubmitted: boolean = false;
  status = [
    { value: 'Active', viewValue: 'Active' },
    { value: 'Close', viewValue: 'Close'},
  ];
  isActives = [
    { values: true, isActiveValue: 'Yes' },
    { values: false, isActiveValue: 'No' },
  ];
  projectStatus = [
    { values: 'InProgress', isActiveValue: 'InProgress' },
    { values: 'BeginningStage', isActiveValue: 'BeginningStage' },
    { values: 'FinalStage', isActiveValue: 'FinalStage' },
  ];

  constructor(
    private datepipe: DatePipe,
    private _fb: FormBuilder,
    private gs: GenericRepositoryService<ProjectReq>,
    private config: ConfigService,
    private _dialogRef: MatDialogRef<ProjectEditComponent>,
    private alertService: AlertService,
    @Inject(MAT_DIALOG_DATA) public data: { projectId: number }
  ) {
    this.loadDropdowns();
    this.projectForm = this._fb.group({
      clientFilterControl: new FormControl(),
      Project: new FormControl('', [Validators.required]),
      ProjectTypeId: new FormControl('', [Validators.required]),
      ClientId: new FormControl('', [Validators.required]),
      Program: new FormControl('', [Validators.required]),
      Status: new FormControl('Active', [Validators.required]),
      IsActive: new FormControl(true, [Validators.required]),
      StartDate: new FormControl('', [Validators.required]),
      EndDate: new FormControl('', [Validators.required,this.EndDateValidator]),
      KEKA_ProjectCode: new FormControl('', [Validators.required]),
      Duration: new FormControl('', [Validators.required]),
      BudgetedHours: new FormControl('', [Validators.required]),
      BudgetedAmount: new FormControl(''),
      ProjectStatus: new FormControl('', [Validators.required]),
      ERP_ProjectCode: new FormControl('', [Validators.required]),
      SowNumber: new FormControl('', [Validators.required]),
      PurchasedOrderNumber: new FormControl('', [Validators.required]),
    });
    
  }
  EndDateValidator: ValidatorFn = (): { [key: string]: boolean } | null => {
    const startDate = this.projectForm?.get('StartDate')?.value;
    const EndDate = this.projectForm?.get('EndDate')?.value;
    if ( new Date(startDate) > new Date(EndDate)) {
      return { 'invalidEndDate': true };
    }
    return null;
  }; 
  changedStartDate(){
    if(this.projectForm?.get('EndDate')?.value){
      this.projectForm?.get('EndDate')?.setValue(this.projectForm?.get('EndDate')?.value)
    }
  }
  get Project() {
    return this.projectForm.get('Project');
  }
  get ProjectTypeId() {
    return this.projectForm.get('ProjectTypeId');
  }
  get ClientId(){
    return this.projectForm.get('ClientId');
  }
  get Program() {
    return this.projectForm.get('Program');
  }
  get Status() {
    return this.projectForm.get('Status');
  }
  get IsActive() {
    return this.projectForm.get('IsActive');
  }
  get StartDate() {
     return this.projectForm.get('StartDate');
  }
  get EndDate() {
    return this.projectForm.get('EndDate');
  }
  get KEKA_ProjectCode() {
    return this.projectForm.get('KEKA_ProjectCode');
  }
  get Duration() {
    return this.projectForm.get('Duration');
  }
  get BudgetedHours() {
    return this.projectForm.get('BudgetedHours');
  }
  get BudgetedAmount() {
    return this.projectForm.get('BudgetedAmount');
  }
  get ProjectStatus() {
    return this.projectForm.get('ProjectStatus');
  }
  get ERP_ProjectCode() {
    return this.projectForm.get('ERP_ProjectCode');
  }
  get SowNumber() {
    return this.projectForm.get('SowNumber');
  }
  get PurchasedOrderNumber() {
    return this.projectForm.get('PurchasedOrderNumber');
  }
 
  ngOnInit(): void {
    if (this.data) {
      this.gs
        .getById(this.config.environment.endpoints.project, this.data.projectId)
        .subscribe({
          next: (res: ProjectReq) => {
            if (res && res.data) {
              this.projectForm.patchValue(res.data);
              this.projectForm.get('Id')?.setValue(this.data.projectId);
              this.projectForm.get('Project')?.setValue(res.data.Project);
              this.projectForm.get('Status')?.setValue(res.data.Status);
              this.projectForm.get('ProjectTypeId')?.setValue(res.data.ProjectTypeId);
              this.projectForm.get('ClientId')?.setValue(res.data.ClientId);
              this.projectForm.get('Program')?.setValue(res.data.Program);
              this.projectForm.get('StartDate')?.setValue(res.data.StartDate);
              this.projectForm.get('StartDate')?.markAsTouched();
              this.projectForm.get('EndDate')?.markAsTouched();
              this.projectForm.get('EndDate')?.setValue(res.data.EndDate);
              this.projectForm.get('KEKA_ProjectCode')?.setValue(res.data.KEKA_ProjectCode);
              this.projectForm.get('Duration')?.setValue(res.data.Duration);
              this.projectForm.get('BudgetedHours')?.setValue(res.data.BudgetedHours);
              this.projectForm.get('BudgetedAmount')?.setValue(res.data.BudgetedAmount);
               this.projectForm.get('ProjectStatus')?.setValue(res.data.ProjectStatus);
              this.projectForm.get('ERP_ProjectCode')?.setValue(res.data.ERP_ProjectCode);
              this.projectForm.get('SowNumber')?.setValue(res.data.SowNumber);
              this.projectForm.get('PurchasedOrderNumber')?.setValue(res.data.PurchasedOrderNumber);
            }
          },
        });
     
    }
    this.ClientId?.valueChanges.subscribe((searchValue: string) => {
      if (searchValue && searchValue.length > 0) {
        this.ClientListOptions = this.ClientList?.filter((client: ClientModel) =>
        client.Client.toLowerCase().includes(searchValue.toLowerCase())
        );
      }
      else{
        this.ClientListOptions = this.ClientList;
      }
    });
  }
  displayFn = (client: number): string => {
    if(this.ClientList?.length){
      const Client = this.ClientList?.filter(clientName=>clientName.Id === client)
      return Client[0].Client; 
    }else{
      return '';
    }
  };
  loadDropdowns(){
    this.loadProjectType();
    this.loadClient();
  }
  loadProjectType() {
    this.projectTypeService
      .get(this.config.environment.endpoints.projecttype)
      .subscribe({
        next: (res: ProjectTypeRes) => {
          if (res && res.data) {
            this.ProjectTypeList = res.data;
          } else {
            this.ProjectTypeList = [];
          }
        },
      });
  }
  loadClient() {
    this.clientServices
      .get(this.config.environment.endpoints.client)
      .subscribe({
        next: (res: ClientRes) => {
          if (res && res.data) {
            this.ClientList = res.data
            this.ClientListOptions = res.data;
          } else {
            this.ClientList = [];
            this.ClientListOptions =[];
          }
        },
      });
  }

  onFormSubmit() {
    this.isSubmitted = true;
    if (this.projectForm.valid) {
      let projectObj: ProjectModel= this.projectForm.value;
      projectObj.StartDate =this.datepipe.transform(this.projectForm.value.StartDate, 'yyyy-MM-dd')?.toString() ?? '';
      projectObj.EndDate =this.datepipe.transform(this.projectForm.value.EndDate, 'yyyy-MM-dd')?.toString() ?? '';
      if (this.data) {
        this.gs.update(
            this.config.environment.endpoints.project,
            this.data.projectId,
            this.projectForm.value
          )
          .subscribe({
            next: (res: any) => {
              if (res && res.code === 200) {
                this.alertService.show('Success','Project detail updated!');
                this._dialogRef.close(true);
              }else{
                this.alertService.show( 'Error','Project not updated successfully!');
              }
            },
            error: (err: any) => {
              this.alertService.show(
                'Error',' Project not updated successfully!'
               
              );
            },
          });
      } else {
        this.gs
          .create(
            this.config.environment.endpoints.project,
            this.projectForm.value
          )
          .subscribe({
            next: (res: any) => {
              if (res && res.code === 201) {
                this.alertService.show( 'Success','Project  added successfully!');
                this._dialogRef.close(true);
              }else{
                this.alertService.show( 'Error','Project not added !');
              }
              
            },
            error: (err: any) => {
              this.alertService.show('Error','Project not added !');
            },
          });
      }
    }
  }
  closeDialog() {
    this._dialogRef.close();
  }
}
