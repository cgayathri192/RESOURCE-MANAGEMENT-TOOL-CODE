import { DatePipe } from '@angular/common';
import { Component, inject, ViewChild } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ProjectModel, ProjectRes,Project } from '@core/models_new/project';
import { ConfigService } from '@core/services/config.service';
import { GenericRepositoryService } from '@core/services/generic-repository.service';
import { Column } from '@home-module/skills_table/skills/skills.component';
import { ProjectEditComponent } from '../project-edit/project-edit.component';
import { DateAdapter, MAT_DATE_FORMATS } from '@angular/material/core';
import { AppDateAdapter, APP_DATE_FORMATS } from '@core/common/dateAdapter';
import {  ClientModel, ClientRes } from '@core/models/client';
import { ProjectTypeRes } from '@core/models/projecttype';
import { AlertService } from '@core/services/alert.service';
@Component({
  selector: 'app-project-details',
  templateUrl: './project-details.component.html',
  styleUrls: ['./project-details.component.scss'],
  providers: [
    { provide: DateAdapter, useClass: AppDateAdapter },
    { provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS },
  ],
})
export class ProjectDetailsComponent {
  fixedColumns: Column[] = [
    { ColumnName: 'SNo', DisplayName: 'Sno', DefaultLoad: true },
    { ColumnName: 'ProjectName',DisplayName: 'Project name',DefaultLoad: true,},
    { ColumnName: 'Status', DisplayName: 'Status', DefaultLoad: true },
    
  ];
  allColumns: Column[] = [
    { ColumnName: 'ProjectType', DisplayName: 'Project Type',DefaultLoad: true},
    { ColumnName: 'Client', DisplayName: 'Client', DefaultLoad: false },
    { ColumnName: 'Program', DisplayName: 'Program', DefaultLoad: false },
    { ColumnName: 'StartDate', DisplayName: 'Start Date', DefaultLoad: true },
    { ColumnName: 'FinishDate', DisplayName: 'Finish Date', DefaultLoad: true },
    {ColumnName: 'KEKA_ProjectCode', DisplayName: 'KEKA Project Code',DefaultLoad: false},
    { ColumnName: 'Duration', DisplayName: 'Duration', DefaultLoad: false },
    { ColumnName: 'BudgetedHours', DisplayName: 'Budgeted Hours', DefaultLoad: false},
    { ColumnName: 'BudgetedAmount', DisplayName: 'Budgeted Amount', DefaultLoad: false, },
    { ColumnName: 'ProjectStatus', DisplayName: 'Project Status', DefaultLoad: false, },
    { ColumnName: 'ERP_ProjectCode', DisplayName: 'ERP Project Code', DefaultLoad: false, },
    { ColumnName: 'SowNumber', DisplayName: 'Sow Number', DefaultLoad: false },
    { ColumnName: 'PurchasedOrderNumber', DisplayName: 'Purchased Order Number', DefaultLoad: false, },
    { ColumnName: 'Active', DisplayName: 'Active', DefaultLoad: false },
    { ColumnName: 'ModifiedBy', DisplayName: 'Modified By', DefaultLoad: false },
    { ColumnName: 'ModifiedDate', DisplayName: 'Modified Date', DefaultLoad: false,},
    { ColumnName: 'CreatedAt', DisplayName: 'Created At', DefaultLoad: false },
  ];
  actionColumn: Column = { ColumnName: 'action', DisplayName: 'Action', DefaultLoad: true, };
  displayedColumns: string[] = [
    ...this.fixedColumns
      .filter((col: Column) => col.DefaultLoad)
      .map((column: Column) => column.ColumnName),
    ...this.allColumns
      .filter((col: Column) => col.DefaultLoad)
      .map((column: Column) => column.ColumnName),
  ].concat(this.actionColumn.ColumnName);
  dataSource!: MatTableDataSource<ProjectModel>;

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  activeService=inject(GenericRepositoryService<ProjectRes>);
  statusService = inject(GenericRepositoryService<ProjectRes>);
  clientService=inject(GenericRepositoryService<ProjectRes>);
  projectTypeService=inject(GenericRepositoryService<ProjectRes>)
  IsActiveList: any;
  projectlist: ProjectModel[] = [];
  StatusList:any;
  ActiveList: any;
  ProjectTypeList:any;
  ClientList:any;

  allActivesSelected: boolean = true;
  allStatusSelected:boolean=true;
  allProjectTypeSelected:boolean=true;
  allClientSelected:boolean=true;

  Active = new FormControl('');
  ProjectType=new FormControl('');
  Client=new FormControl('');
  Status = new FormControl('');
  ModifiedDateRange = new FormGroup({
    start: new FormControl(null),
    end: new FormControl(null),
  });
  StartDateRange = new FormGroup({
    start: new FormControl(null),
    end: new FormControl(null),
  });
  EndDateRange = new FormGroup({
    start: new FormControl(null),
    end: new FormControl(null),
  });
  FinishDateRange = new FormGroup({
    start: new FormControl(null),
    end: new FormControl(null),
  });
  CreatedAtDateRange = new FormGroup({
    start: new FormControl(null),
    end: new FormControl(null),
  });

  constructor(
    private _dialog: MatDialog,
    private gs: GenericRepositoryService<ProjectRes>,
    private alertService: AlertService,
    private config: ConfigService,
    private datepipe: DatePipe
  ) {
    this.dataSource = new MatTableDataSource<ProjectModel>();
  }
  ngOnInit(): void {

    let controlFilters: any[] = [
      { control: this.Status, value: 'Status' },
      { control: this.ProjectType, value: 'ProjectType.ProjectTypeName' },
      { control: this.Client, value: 'Client.ClientName' },
    ]
    for (var controlfilter = 0; controlfilter < controlFilters.length; controlfilter++) {
      // this.applyDynamicFilter(controlFilters[controlfilter].control, controlFilters[controlfilter].value);
      this.applyDynamicFilter(this.Active, 'IsActive');
    }
    this.ModifiedDateRange.valueChanges.subscribe((formValues: any) => {
      if (formValues.start && formValues.end) {
        this.dataSource = new MatTableDataSource(
          this.projectlist.filter((emp: any) => {
            let projectMDate = new Date(emp.ModifiedAt);
            let startDate = new Date(formValues.start);
            let endDate = new Date(formValues.end);
            endDate.setDate(endDate.getDate() + 1);
            return projectMDate >= startDate && projectMDate < endDate;
          })
        );
      } else {
        this.dataSource = new MatTableDataSource(this.projectlist);
        this.dataSource.paginator = this.paginator;
      }
    });
    this.StartDateRange.valueChanges.subscribe((formValues: any) => {
      if (formValues.start && formValues.end) {
        this.dataSource = new MatTableDataSource(
          this.projectlist.filter((prosd: any) => {
            let projectStartDate = new Date(prosd.StartDate);
            let startDate = new Date(formValues.start);
            let endDate = new Date(formValues.end);
            endDate.setDate(endDate.getDate() + 1);
            return projectStartDate >= startDate && projectStartDate < endDate;
          })
        );
      } else {
        this.dataSource = new MatTableDataSource(this.projectlist);
        this.dataSource.paginator = this.paginator;
      }
    });
    this.FinishDateRange.valueChanges.subscribe((formValues: any) => {
      if (formValues.start && formValues.end) {
        this.dataSource = new MatTableDataSource(
          this.projectlist.filter((profd: any) => {
            let projectFinishDate = new Date(profd.FinishDate);
            let startDate = new Date(formValues.start);
            let endDate = new Date(formValues.end);
            endDate.setDate(endDate.getDate() + 1);
            return projectFinishDate >= startDate && projectFinishDate < endDate;
          })
        );
      } else {
        this.dataSource = new MatTableDataSource(this.projectlist);
        this.dataSource.paginator = this.paginator;
      }
    });
    this.CreatedAtDateRange.valueChanges.subscribe((formValues: any) => {
      if (formValues.start && formValues.end) {
        this.dataSource = new MatTableDataSource(
          this.projectlist.filter((emp: any) => {
            let projectCreateAt = new Date(emp.CreatedAt);
            let startDate = new Date(formValues.start);
            let endDate = new Date(formValues.end);
            endDate.setDate(endDate.getDate() + 1);
            return projectCreateAt >= startDate && projectCreateAt < endDate;
          })
        );
      } else {
        this.dataSource = new MatTableDataSource(this.projectlist);
        this.dataSource.paginator = this.paginator;
      }
    });
    this.filterProjects();
    this.getProjectList();
    this.loadDropdowns();
  }
  applyDynamicFilter(control: FormControl, searchproperty: any) {
    if (control) {
      control.valueChanges.subscribe((res: any) => {
        if (res && res.length > 0) {
          this.dataSource = new MatTableDataSource(this.projectlist.filter((project: any) => {
              const propertyValue = this.getNestedPropertyValue(project, searchproperty);
              if (searchproperty === 'Active') {
                return res.includes(propertyValue ? 'Yes' : 'No');
              }
              return res.findIndex((r: any) => r === propertyValue) >= 0;
            })
          );
        } else {
          this.dataSource = new MatTableDataSource(this.projectlist);
        }
      });
    }
  }
  
  getNestedPropertyValue(object: any, propertyPath: string): any {
    return propertyPath.split('.').reduce((obj, prop) => obj && obj[prop], object);
  }
  clearCreatedAtDateRange(): void {
    this.CreatedAtDateRange.reset();
  }
  clearModifiedDateRange(): void {
    this.ModifiedDateRange.reset();
  }
  clearStartDateRange(): void {
    this.StartDateRange.reset();
  }
  clearFinishDateRange(): void {
    this.FinishDateRange.reset();
  }

  loadDropdowns(): void {
   // this.loadActive();
    this.loadProjectType();
    this.loadClient();
  }
  loadClient(){
    this.clientService.get(this.config.environment.endpoints.client).subscribe({
      next: (client: ClientRes) => {
        if (client && client.data.length > 0) {
          this.ClientList = client.data.map((clients: ClientModel) => clients.ClientName);
         } else {
          this.ClientList = [];
        }
      },
    });
  }
  loadProjectType(){
    this.projectTypeService.get(this.config.environment.endpoints.projecttype).subscribe({
      next: (project: ProjectTypeRes) => {
        if (project && project.data.length > 0) {
          console.log(project.data,'project')
          // this.ProjectTypeList = project.data.map((project: Project) => project.ProjectTypeId);
         } else {
          this.ClientList = [];
        }
      },
    });
  }
  
  getProjectList() {
    this.gs.get(this.config.environment.endpoints.project).subscribe({
      next: (res: ProjectRes) => {
        if (res && res.code == 200) {
          // res.data.sort((a, b) => {
          //   return (
          //     new Date(b.CreatedAt).getTime() - new Date(a.CreatedAt).getTime()
          //   );
          // });
          this.projectlist = res.data;
          this.dataSource = new MatTableDataSource(res.data);
          const sort = new MatSort();
          sort.active = 'CreatedAt';
          sort.direction = 'desc';
          this.dataSource.sort = this.sort;
          this.dataSource.paginator = this.paginator;
          this.filterProjects();
        }
      },
    });
  }

  addProjectForm() {
    const dialogRef = this._dialog.open(ProjectEditComponent,{
      width:'45%',
    });
    dialogRef.afterClosed().subscribe({
      next: (val) => {
        if (val) {
          this.getProjectList();
        }
      },
    });
  }

  openEditForm(projectId: ProjectModel) {
    const dialogRef = this._dialog.open(ProjectEditComponent, {
      width:'45%',
      data: { projectId: projectId },
    });
    dialogRef.afterClosed().subscribe({
      next: (val) => {
        if (val) {
          this.getProjectList();
        }
      },
    });
  }

  deleteProjectForm(id: number) {
    this.gs.delete(this.config.environment.endpoints.project, id).subscribe({
      next: (res: ProjectRes) => {
        console.log(res)
        if (res && res.code == 200) {
          this.alertService.show('Success','Deleted successfully!');
          this.getProjectList();
        } else {
          this.alertService.show('Error','Not deleted!');
        }
      },
      error: (err: any) => {
        this.alertService.show('Error','Not deleted!' );
      },
    });
  }

  toggleDisplayColumns(): void {
    if (
      this.displayedColumns.length - (this.fixedColumns.length + 1) ===
      this.allColumns.length
    ) {
      // On Select
      this.displayedColumns = [
        ...this.fixedColumns.map((column) => column.ColumnName),
      ].concat(this.actionColumn.ColumnName);
    } else {
      // On Deselect
      this.displayedColumns = [
        ...this.fixedColumns.map((column) => column.ColumnName),
        ...this.allColumns.map((column) => column.ColumnName),
      ].concat(this.actionColumn.ColumnName);
    }
  }
  onColumnSelect(selectedColumns: string[]) {
    this.displayedColumns = [...this.fixedColumns.map((column) => column.ColumnName), ...selectedColumns].concat(this.actionColumn.ColumnName);
    if (selectedColumns.length !== this.allColumns.length) {
      this.displayedColumns = [...this.fixedColumns.map((column) => column.ColumnName), ...selectedColumns].concat(this.actionColumn.ColumnName);
    }
  }
  filterProjects(){
    this.ActiveList = [...new Set(this.projectlist.map((res: any) => res.Active?"Yes":"No")),];
    this.StatusList = [...new Set(this.projectlist.map((res:any)=>res.Status)),];
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value.trim().toLowerCase();
    this.dataSource.filter = filterValue;
    this.dataSource.filterPredicate = (data: ProjectModel, filter: string) => {
      return this.filterData(data, filter);
    };
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  filterData(data: any, filter: string): boolean {
    for (const key in data) {
      if (data.hasOwnProperty(key)) {
        let value = data[key] ?? null;
        if (key == 'ModifiedAt' || key == 'CreatedAt') {
          value = this.datepipe.transform(data[key], 'dd MMM, yyyy') ?? null;
        }
        if (typeof value === 'object' && value !== null) {
          if (this.filterData(value, filter)) {
            return true;
          }
        } else {
          if (
            value !== null &&
            value.toString().toLowerCase().includes(filter)
          ) {
            return true;
          }
        }
      }
    }
    return false;
  }
  selectAllForProjectType(e:any){
    this.allProjectTypeSelected = !this.allProjectTypeSelected;
    if(e.checked){
     this.ProjectType.setValue(this.ProjectTypeList.slice(0));
    } else{
     this.ProjectType.setValue('');
    }
    this.dataSource.paginator = this.paginator;
   }
   selectAllForClient(e:any){
    this.allClientSelected = !this.allClientSelected;
    if(e.checked){
     this.Client.setValue(this.ClientList.slice(0));
    } else{
     this.Client.setValue('');
    }
    this.dataSource.paginator = this.paginator;
   }
   selectAllForActive(e: any) {
    this.allActivesSelected = !this.allActivesSelected;
    if (e.checked) {
      this.Active.setValue(this.ActiveList.slice(0));
    } else {
      this.Active.setValue('');
    }
    this.dataSource.paginator = this.paginator;
  }
  selectAllForStatus(e: any) {
    this.allStatusSelected = !this.allStatusSelected;
    if (e.checked) {
      this.Status.setValue(this.StatusList.slice(0));
    } else {
      this.Status.setValue('');
    }
    this.dataSource.paginator = this.paginator;
  }
  checkIfAllSelected(formControl: FormControl, arrayList: []): boolean {
    if (formControl.value?.length) {
      return formControl.value.length === arrayList.length;
    } else {
      return false;
    }
  }
}
