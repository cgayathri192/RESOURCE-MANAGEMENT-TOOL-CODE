import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProjectRoutingModule } from './project-routing.module';
import { ProjectComponent } from './project/project.component';
import { ClientComponent } from './client_table/client/client.component';
import { SharedModule } from '@shared/shared.module';
import { ProjectDetailsComponent } from './project_table/project-details/project-details.component';
import { SidenavComponent } from './layout/sidenav/sidenav.component';
import { HeaderComponent } from './layout/header/header.component';
import { MatSelectModule } from '@angular/material/select';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatDialogModule } from '@angular/material/dialog';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatInputModule } from '@angular/material/input';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatTableModule } from '@angular/material/table';
import { MatTabsModule } from '@angular/material/tabs';
import { ClientEditComponent } from './client_table/client-edit/client-edit.component';
import { ClientTypeComponent } from './client_table/client-type/client-type.component';
import { ClientTypeEditComponent } from './client_table/client-type-edit/client-type-edit.component';
import { ProjectTypeComponent } from './projecttype_table/project-type/project-type.component';
import { ProjecttypeEditComponent } from './projecttype_table/projecttype-edit/projecttype-edit.component';
import { ProjectEditComponent } from './project_table/project-edit/project-edit.component';
import { ProjectMappingComponent } from './project_mapping_table/project-mapping/project-mapping.component';
import { ProjectMappingEditComponent } from './project_mapping_table/project-mapping-edit/project-mapping-edit.component';
import { BillingStatusComponent } from './project_mapping_table/billing-status/billing-status.component';
import { BillingStatusEditComponent } from './project_mapping_table/billing-status-edit/billing-status-edit.component';
import { EmployeeStatusComponent } from './employee-status/employee-status.component';
import { BlankAllocationComponent } from './blank-allocation/blank-allocation.component';




@NgModule({
  declarations: [
    ProjectComponent,
    ClientComponent,
    ProjectDetailsComponent,
    SidenavComponent,
    HeaderComponent,
    ClientEditComponent,
    ClientTypeComponent,
    ClientTypeEditComponent,
    ProjectTypeComponent,
    ProjecttypeEditComponent,
    ProjectEditComponent,
    ProjectMappingComponent,
    ProjectMappingEditComponent,
    BillingStatusComponent,
    BillingStatusEditComponent,
    EmployeeStatusComponent,
    BlankAllocationComponent
  ],
  imports: [
    CommonModule,
    ProjectRoutingModule,
    SharedModule,
    MatSelectModule,
    FormsModule,
    ReactiveFormsModule,
    MatTableModule,
    MatDialogModule,
    MatGridListModule,
    MatTabsModule,
    MatInputModule,
    MatSlideToggleModule
  ],
  
})
export class ProjectModule { }
