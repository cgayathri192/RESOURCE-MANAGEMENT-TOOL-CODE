import { DatePipe } from '@angular/common';
import { Component, Inject, inject } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl,ValidatorFn,AbstractControl } from '@angular/forms';
import { DateAdapter, MAT_DATE_FORMATS } from '@angular/material/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { AppDateAdapter, APP_DATE_FORMATS } from '@core/common/dateAdapter';
import { Client, ClientModel, ClientReq, ClientRes } from '@core/models_new/client';
import { ClientTypeModel, ClientTypeRes } from '@core/models_new/clienttype';
import { CountryListModel, CountryListRes } from '@core/models/countries';
import { AlertService } from '@core/services/alert.service';
import { ConfigService } from '@core/services/config.service';
import { GenericRepositoryService } from '@core/services/generic-repository.service';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';

@Component({
  selector: 'app-client-edit',
  templateUrl: './client-edit.component.html',
  styleUrls: ['./client-edit.component.scss'],
  providers: [
    { provide: DateAdapter, useClass: AppDateAdapter },
    { provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS },
  ],
})
export class ClientEditComponent {
  CountryOptions!:CountryListModel[];
  form!: FormGroup;
  CountryList!:CountryListModel[];
  // countriesList: any;
  filteredClientList!: Observable<any[]>;
  clientFilterControl = new FormControl();
  dataSource!: MatTableDataSource<ClientModel>;
  clientForm: FormGroup;
  ClientTypeOptions!: ClientTypeModel[];
  ClientList!:ClientTypeModel[];
  maxDate: Date;
  clientTypeService = inject(GenericRepositoryService<ClientRes>);
  countryService = inject(GenericRepositoryService<CountryListRes>)
  isSubmitted: boolean=false;
  status = [
    { value: 'Active', viewValue: 'Active' },
    { value: 'Inactive', viewValue: 'Inactive' },
  ];
  isActives = [
    { values: true, isActiveValue: 'Yes' },
    { values: false, isActiveValue: 'No' },
  ];
  constructor(
    private _fb: FormBuilder,
    private formBuilder: FormBuilder,
    private gs:GenericRepositoryService<ClientReq>,
    private config:ConfigService,
    private _dialogRef: MatDialogRef<ClientEditComponent>,
    private alertService: AlertService,
    private datepipe: DatePipe,
    @Inject(MAT_DIALOG_DATA) public data: { clientId:  number},
  ) {
    this.maxDate = new Date();
    this.clientForm = this._fb.group({
      Client: new FormControl('', [Validators.required]),
      ClientDomainId:new FormControl('', [Validators.required]),
      ClientCode:new FormControl('', [Validators.required]),
      Status:new FormControl('Active', [Validators.required]),
      IsActive:new FormControl(true, [Validators.required]),
      Country:new FormControl('',{ validators: [autocompleteObjectValidator(), Validators.required] }),
      BusinessNumber: new FormControl('', [Validators.required]),
      Email:new FormControl('', [Validators.required]),
      City:new FormControl('',[Validators.required]),
      Website:new FormControl('', [Validators.required]),
      ZipCode:new FormControl('', [Validators.required]),
      EndDate:new FormControl('', [Validators.required]),
    });
  }
  
  get Client() {
    return this.clientForm.get('Client');
  }
  get ClientDomain() {
    return this.clientForm.get('ClientDomain');
  }
  get ClientCode() {
    return this.clientForm.get('ClientCode');
  }
  get ClientDomainId() {
    return this.clientForm.get('ClientDomainId');
  }
  get Status() {
    return this.clientForm.get('Status');
  }
  get Country() {
    return this.clientForm.get('Country');
  }
  get IsActive() {
    return this.clientForm.get('IsActive');
  }
  get BusinessNumber() {
    return this.clientForm.get('BusinessNumber');
  }
  get Email() {
    return this.clientForm.get('Email');
  }
  get City(){
    return this.clientForm.get('City')
  }
  get Website() {
    return this.clientForm.get('Website');
  }
  get ZipCode() {
    return this.clientForm.get('ZipCode');
  }
  get EndDate() {
    return this.clientForm.get('EndDate');
  }
  
  ngOnInit(): void {
    this.Country?.valueChanges.subscribe((employee : CountryListModel)=> {
      if (employee && this.CountryOptions) {
        const selectedEmployee = this.CountryOptions?.find(e => e.CountryCode === employee.CountryCode);
      }
    });
    this.Country?.valueChanges.subscribe((searchValue: string) => {
      if (searchValue && searchValue.length > 0 ) {
        this.CountryOptions = this.CountryList?.filter((employee: CountryListModel) =>
        employee.CountryCode.toLowerCase().includes(searchValue.toLowerCase()) 
        );
      } else if(this.Country?.touched == false&& searchValue.length == 0) {
        this.CountryOptions = this.CountryList
      }
    });
    if(this.data){
      this.loadClientType();
      this.gs.getById(this.config.environment.endpoints.client,this.data.clientId).subscribe({
        next:(res:ClientReq)=>{
          if(res && res.data){
            this.clientForm.patchValue(res.data)
            this.clientForm.get('Id')?.setValue(this.data.clientId);
            this.clientForm.get('ClientName')?.setValue(res.data.Client);
            this.clientForm.get('ClientDomainId')?.setValue(res.data.ClientDomain.Id);
            this.clientForm.get('Status')?.setValue(res.data.Status);
            this.clientForm.get('PostCode')?.setValue(res.data.ZipCode);
            this.clientForm.get('Country')?.setValue(res.data.Country);
            this.clientForm.get('BusinessNumber')?.setValue(res.data.BusinessNumber);
            this.clientForm.get('Email')?.setValue(res.data.Email);
            this.clientForm.get('Website')?.setValue(res.data.Website);
            this.clientForm.get('ClientCode')?.setValue(res.data.ClientCode);
            this.clientForm.get('Email')?.setValue(res.data.Email);
            this.clientForm.get('City')?.setValue(res.data.City);
          }
        }
      })
    }
    this.loadDropdowns()
    this.ClientDomainId?.valueChanges.subscribe((searchValue: string) => {
      if (searchValue && searchValue.length > 0) {
        this.ClientTypeOptions = this.ClientList?.filter((client: ClientTypeModel) =>
        client.ClientDomain.toLowerCase().includes(searchValue.toLowerCase())
        );
      }
      else{
        this.ClientTypeOptions = this.ClientList;
      }
    });
  }
  displayFn(emp: CountryListModel): string {
    return emp && emp.CountryName ? emp.CountryName : '';
  }
  displayFnClient = (client: number): string => {
    if(this.ClientList?.length){
      const Client = this.ClientList?.filter(clientType=>
        clientType.Id === client)
      return Client[0].ClientDomain; 
    }else{
      return '';
    }
  };
  
  
  loadCountries(){
    this.countryService
      .get(this.config.environment.endpoints.countries)
      .subscribe({
        next: (res: CountryListRes) => {
          if (res && res.country_list) {
            this.CountryList = res.country_list;
            this.CountryOptions = res.country_list;
          } else {
            this.CountryList = [];
            this.CountryOptions=[];
          }
        },
      });
  }
  onFormSubmit() {
    this.isSubmitted= true;
    if (this.clientForm.valid) {
      let clientObj: Client= this.clientForm.value;
      clientObj.EndDate =
        this.datepipe
          .transform(this.clientForm.value.EndDate, 'yyyy-MM-dd')
          ?.toString() ?? '';
        clientObj.Country= this.clientForm.value.Country?.CountryCode;
      if (this.data) {
        this.gs.update(this.config.environment.endpoints.client,this.data.clientId, this.clientForm.value)
          .subscribe({
            next: (res: any) => {
              if (res && res.code === 200) {
                this.alertService.show('Success','Client  detail updated!');
                this._dialogRef.close(true);
              }else{
                this.alertService.show('Error','Client not updated successfully!');
              }
             
            },
            error: (err: any) => {
              this.alertService.show('Error',' Client Not updated!');
            },
          });
      } else {
        this.gs.create(this.config.environment.endpoints.client,this.clientForm.value).subscribe({
          next: (res: any) => {
            if (res && res.code === 201) {
              this.alertService.show( 'Success','Client added successfully!');
              this._dialogRef.close(true);
            }else{
              this.alertService.show('Error','Client not added!');
            }
            
          },
          error: (err: any) => {
            this.alertService.show('Error','Client not added!');
          },
        });
      }
    }
  }
  loadDropdowns(){
    this.loadClientType()
    this.loadCountries()
  }
  loadClientType(){
    this.clientTypeService
      .get(this.config.environment.endpoints.clientdomain)
      .subscribe({
        next: (res: ClientTypeRes) => {
          if (res && res.data) {
            this.ClientList = res.data
            this.ClientTypeOptions = res.data;
          } else {
            this.ClientList = [];
            this.ClientTypeOptions =[];
          }
        },
      });
  }
  applyDateFilter(selectedDate: Date) {
    const year = selectedDate.getFullYear();
    const month = String(selectedDate.getMonth() + 1).padStart(2, '0');
    const day = String(selectedDate.getDate()).padStart(2, '0');
    const formattedDate = `${year}-${month}-${day}`;
    
    this.dataSource.filter = formattedDate;
    this.dataSource.filterPredicate = (data, filter) => {
      const dataDate = new Date(data.EndDate);
      const filterDate = new Date(filter);
      return (
        dataDate.getFullYear() === filterDate.getFullYear() &&
        dataDate.getMonth() === filterDate.getMonth() &&
        dataDate.getDate() === filterDate.getDate()
      );
    };
  }
  closeDialog() {
    this._dialogRef.close();
  }
}

function autocompleteObjectValidator(): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } | null => {
    if (typeof control.value === 'string') {
      return { 'invalidAutocompleteObject': { value: control.value } }
    }
    return null
  }
}
