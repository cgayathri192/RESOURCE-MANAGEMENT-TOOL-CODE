import { Component, Inject } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ClientTypeReq } from '@core/models_new/clienttype';
import { AlertService } from '@core/services/alert.service';
import { ConfigService } from '@core/services/config.service';
import { GenericRepositoryService } from '@core/services/generic-repository.service';

@Component({
  selector: 'app-client-type-edit',
  templateUrl: './client-type-edit.component.html',
  styleUrls: ['./client-type-edit.component.scss']
})
export class ClientTypeEditComponent {
    clienttypeForm!: FormGroup;
    isSubmitted: boolean=false;
    constructor(
      private _fb: FormBuilder,
      private gs:GenericRepositoryService<ClientTypeReq>,
      private config:ConfigService,
      private alertService: AlertService,
      private _dialogRef: MatDialogRef<ClientTypeEditComponent>,
      @Inject(MAT_DIALOG_DATA) public data: {clientId:number},
    ) {
      this.clienttypeForm = this._fb.group({
        Id:new FormControl(''),
        ClientDomain: new FormControl('', [Validators.required])
      });
    }
    get ClientDomain(){
      return this.clienttypeForm.get('ClientDomain');
    }
    ngOnInit(): void {
      if(this.data){
        this.gs.getById(this.config.environment.endpoints.clienttype,this.data.clientId).subscribe({
          next:(res: ClientTypeReq)=>{
            if(res.data){
              this.clienttypeForm.patchValue(res.data);
            }
          }
        })
      }
     }
    onFormSubmit() {
      this.isSubmitted= true;
      if (this.clienttypeForm.valid) {
        if (this.data) {
          this.gs
            .update(this.config.environment.endpoints.clientdomain,this.data.clientId, this.clienttypeForm.value)
            .subscribe({
              next: (res: any) => {
                if (res && res.code === 200) {
                  this.alertService.show('Success','ClientType updated successfully');
                  this._dialogRef.close(true);
                }else{
                  this.alertService.show('Error','ClientType not updated');
                }
             
              },
              error: (err: any) => {
                this.alertService.show('Error','ClientType not updated');
              },
            });
        } else {
          this.gs.create(this.config.environment.endpoints.clientdomain,this.clienttypeForm.value).subscribe({
            next: (res: any) => {
              if (res && res.code === 201) {
                this.alertService.show( 'Success','ClientType  added successfully');
                this._dialogRef.close(true);
              }else{
                this.alertService.show('Error','ClientType  not added');
              }
             
            },
            error: (err: any) => {
              this.alertService.show('Error','ClientType  not added');
            },
          });
        }
      }
    }
}
