import { DatePipe } from '@angular/common';
import { Component, ViewChild, inject } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ClientModel, ClientRes, Client,ClientDomain} from '@core/models_new/client';
import { ConfigService } from '@core/services/config.service';
import { GenericRepositoryService } from '@core/services/generic-repository.service';
import { Column } from '@home-module/skills_table/skills/skills.component';
import { ClientEditComponent } from '../client-edit/client-edit.component';
import { FormControl, FormGroup } from '@angular/forms';
// import { ClientTypeRes } from '@core/models/clienttype';
import { ClientTypeRes ,ClientTypeModel} from '@core/models_new/clienttype';
import { DateAdapter, MAT_DATE_FORMATS } from '@angular/material/core';
import { AppDateAdapter, APP_DATE_FORMATS } from '@core/common/dateAdapter';
import { AlertService } from '@core/services/alert.service';
// import { ClientDomain} from '@core/models_new/client';

@Component({
  selector: 'app-client',
  templateUrl: './client.component.html',
  styleUrls: ['./client.component.scss'],
  providers: [
    { provide: DateAdapter, useClass: AppDateAdapter },
    { provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS },
  ],
})
export class ClientComponent {
  fixedColumns: Column[] = [
    { ColumnName: 'SNo', DisplayName: 'Sno', DefaultLoad: true },
    { ColumnName: 'ClientName', DisplayName: 'Client name', DefaultLoad: true},
    { ColumnName: 'ClientType', DisplayName: 'ClientType', DefaultLoad: true },
  ];
  allColumns: Column[] = [
    { ColumnName: 'Country',DisplayName: 'Country',DefaultLoad: false},
    { ColumnName: 'Status', DisplayName: 'Status', DefaultLoad: false },
    { ColumnName: 'Address', DisplayName: 'Address', DefaultLoad: false },
    { ColumnName: 'Suburb', DisplayName: 'Suburb', DefaultLoad: false},
    { ColumnName: 'PostCode', DisplayName: 'Post Code', DefaultLoad: false },
    { ColumnName: 'MobileNumber', DisplayName: 'Mobile Number',DefaultLoad: false},
    { ColumnName: 'Fax',DisplayName: 'Fax',DefaultLoad: false},
    { ColumnName: 'Email', DisplayName: 'Email', DefaultLoad: true },
    { ColumnName: 'Website', DisplayName: 'Website', DefaultLoad: false },
    { ColumnName: 'Reference',DisplayName: 'Reference', DefaultLoad: false},
    { ColumnName: 'ClientCode', DisplayName: 'Client Code', DefaultLoad: false },
    { ColumnName: 'ClientDescription', DisplayName: 'Client Description', DefaultLoad: false },
    { ColumnName: 'EndDate',DisplayName: 'End date',DefaultLoad: true},
    { ColumnName: 'IsActive', DisplayName: 'Active',DefaultLoad: false},
    { ColumnName: 'ModifiedBy',DisplayName: 'Modified By',DefaultLoad: false},
    { ColumnName: 'ModifiedAt',DisplayName: 'Modified At',DefaultLoad: false},
    { ColumnName: 'CreatedAt',DisplayName: 'Created At',DefaultLoad: false},
  ];
  actionColumn: Column = { ColumnName: 'action',DisplayName: 'Action',DefaultLoad: true };
  displayedColumns: string[] = [...this.fixedColumns.filter((col: Column) => col.DefaultLoad).map((column: Column) => column.ColumnName),...this.allColumns.filter((col: Column) => col.DefaultLoad).map((column: Column) => column.ColumnName),].concat(this.actionColumn.ColumnName);
  dataSource!: MatTableDataSource<ClientModel>;
  sortOrder: 'asc' | 'desc' = 'asc';
  clientlist: ClientModel[] = [];
  IsActiveList: any;
  StatusList:any;
  ActiveList:any;
  ClientTypeList:any;
  IsActive = new FormControl('');
  Status = new FormControl('');
  ClientType = new FormControl('');
  activeService = inject(GenericRepositoryService<ClientRes>);
  statusService = inject(GenericRepositoryService<ClientRes>);
  clientTypeService = inject(GenericRepositoryService<ClientRes>);

  allActivesSelected: boolean = true;
  allSatusSelected: boolean = true;
  allClientTypeSelected: boolean = true;
  ModifiedDateRange = new FormGroup({
    start: new FormControl(null),
    end: new FormControl(null),
  });
  EndDate = new FormGroup({
    start: new FormControl(null),
    end: new FormControl(null),
  });
  CreatedAtDateRange = new FormGroup({
    start: new FormControl(null),
    end: new FormControl(null),
  });
  ModifiedBy = new FormControl('')

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  constructor(private _dialog: MatDialog,
    private  gs: GenericRepositoryService<ClientRes>,
    private alertService: AlertService,
    private config: ConfigService,
    private datepipe:DatePipe) {
      this.dataSource = new MatTableDataSource<ClientModel>();
     }
  ngOnInit(): void {
    this.getClientList();
    this.filterClient();
    this.loadDropdowns(); 
    let controlFilters: any[] = [
      { control: this.ClientType, value: 'ClientType.ClientTypeName' },
      { control: this.ModifiedBy,value: 'ModifiedBy.AssociateName'}
    ];
    for (var controlfilter = 0; controlfilter < controlFilters.length; controlfilter++) {
      //this.applyDynamicFilter(controlFilters[controlfilter].control, controlFilters[controlfilter].value);
      this.applyDynamicFilter(this.IsActive, 'IsActive');
    }
    this.ModifiedDateRange.valueChanges.subscribe((formValues: any) => {
      if (formValues.start && formValues.end) {
        this.dataSource = new MatTableDataSource(this.clientlist.filter((client: any) => {
            let clientDate = new Date(client.ModifiedAt);
            let startDate = new Date(formValues.start);
            let endDate = new Date(formValues.end);
            endDate.setDate(endDate.getDate() + 1);
            return clientDate >= startDate && clientDate < endDate;
          })
        );
      } else {
        this.dataSource = new MatTableDataSource(this.clientlist);
      }
    });
    this.EndDate.valueChanges.subscribe((formValues: any) => {
      if (formValues.start && formValues.end) {
        this.dataSource = new MatTableDataSource(this.clientlist.filter((client: any) => {
            let clientDate = new Date(client.EndDate);
            let startDate = new Date(formValues.start);
            let endDate = new Date(formValues.end);
            endDate.setDate(endDate.getDate() + 1);
            return clientDate >= startDate && clientDate < endDate;
          })
        );
      } else {
        this.dataSource = new MatTableDataSource(this.clientlist);
      }
    });
    this.CreatedAtDateRange.valueChanges.subscribe((formValues: any) => {
      if (formValues.start && formValues.end) {
        this.dataSource = new MatTableDataSource(
          this.clientlist.filter((emp: any) => {
            let projectCreateAt = new Date(emp.CreatedAt);
            let startDate = new Date(formValues.start);
            let endDate = new Date(formValues.end);
            endDate.setDate(endDate.getDate() + 1);
            return projectCreateAt >= startDate && projectCreateAt < endDate;
          })
        );
      } else {
        this.dataSource = new MatTableDataSource(this.clientlist);
        this.dataSource.paginator = this.paginator;
      }
    });
  }
  getClientList(){
    this.gs.get(this.config.environment.endpoints.client).subscribe({
      next: (res : ClientRes) => {
      if (res && res.code == 200) {
        res.data.sort((a, b) => {
          return new Date(b.CreatedDateTime).getTime() - new Date(a.CreatedDateTime).getTime();
        });
        this.clientlist = res.data;
        this.dataSource = new MatTableDataSource(this.clientlist);
        const sort = new MatSort();
        sort.active = 'CreatedDateTime';
        sort.direction = 'desc';
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
        this.filterClient()
      }
      },
    });
  }
  toggleDisplayColumns(): void {
    if (this.displayedColumns.length - (this.fixedColumns.length + 1) === this.allColumns.length) {
      // On Select
      this.displayedColumns = [...this.fixedColumns.map((column) => column.ColumnName)].concat(this.actionColumn.ColumnName);
    } else {
      // On Deselect
      this.displayedColumns = [...this.fixedColumns.map((column) => column.ColumnName), ...this.allColumns.map((column) => column.ColumnName)].concat(this.actionColumn.ColumnName);
    }
  }
  onColumnSelect(selectedColumns: string[]) {
    this.displayedColumns = [...this.fixedColumns.map((column) => column.ColumnName), ...selectedColumns].concat(this.actionColumn.ColumnName);
    if (selectedColumns.length !== this.allColumns.length) {
      this.displayedColumns = [...this.fixedColumns.map((column) => column.ColumnName), ...selectedColumns].concat(this.actionColumn.ColumnName);
    }
  }
  addClientForm() {
    const dialogRef = this._dialog.open(ClientEditComponent,{
      width:'45%',
    });
    dialogRef.afterClosed().subscribe({
      next: (val) => {
        if (val) {
          this.getClientList();
        }
      },
    });
  }
  openEditForm(clientId: ClientModel) {
    const dialogRef = this._dialog.open(ClientEditComponent, {
      width:'45%',
      data:{clientId:clientId},
    });
    dialogRef.afterClosed().subscribe({
      next: (val) => {
        if (val) {
          this.getClientList();
        }
      },
    });
  }
  deleteClientForm(id: number) {
    this.gs.delete(this.config.environment.endpoints.client, id).subscribe({
      next: (res: ClientRes) => {
        if (res && res.code == 200) {
          this.alertService.show('Success','Deleted successfully!');
          this.getClientList();
        }
        else {
          this.alertService.show( 'Error','Not deleted successfully!');
        }
      },
      error: (err: any)=>{
         this.alertService.show('Error','Not deleted successfully!');
        },
    });
  }
  filterClient() {
    this.IsActiveList = [...new Set(this.clientlist.map((res: any) => res.IsActive?"Yes":"No")),];
    this.StatusList = [...new Set(this.clientlist.map((res:any)=>res.Status)),];
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
    this.dataSource.filterPredicate = (data:ClientModel, filter:string)=> {
      return this.filterData(data,filter);
    };
    if (this.dataSource.paginator) {


      
      this.dataSource.paginator.firstPage();
    }
  }
  filterData(data: any, filter: string): boolean {
    for (const key in data) {
      if (data.hasOwnProperty(key)) {
        let value = data[key]  ?? null;
        if(key == "ModifiedDateTime" || key == "CreatedDateTime"){
          value = this.datepipe.transform(data[key], 'dd MMM, yyyy') ?? null;
        }
        if (typeof value === 'object' && value !== null) {
          if (this.filterData(value, filter)) {
            return true;
          }
        } else {
          if (value !== null && value.toString().toLowerCase().includes(filter)) {
            return true;
          }
        }
      }
    }
    return false;
  }
  applySort(type: any) {
    this.sortOrder = this.sortOrder === 'asc' ? 'desc' : 'asc';
    let valueA: any;
    let valueB: any;
    this.clientlist.sort((a, b) => {
      if (type === 'ClientType') {
        valueA = a?.ClientDomain?.ClientDomain
        ;
        valueB = b?.ClientDomain?.ClientDomain;
      } 
      else if ( type === 'ModifiedBy'){
        valueA = a?.ModifiedBy?.AssociateName
        valueB = b?.ModifiedBy?.AssociateName
      }

      if (this.sortOrder === 'asc') {
        return valueA < valueB ? -1 : 1;
      } else {
        return valueA > valueB ? -1 : 1;
      }
    });
  }
  // applyDynamicFilter(control: FormControl, searchproperty: any) {
  //   if (control) {
  //     control.valueChanges.subscribe((res: any) => {
  //       if (res && res.length > 0) {
  //         this.dataSource = new MatTableDataSource(this.clientlist.filter((client: any) => {
  //             const propertyValue = this.getNestedPropertyValue(client, searchproperty);
  //             // return res.findIndex((r: any) => r === propertyValue) >= 0;
  //             if (searchproperty === 'IsActive') {
  //               return res.includes(propertyValue ? 'Yes' : 'No');
  //             }
  //             return res.findIndex((r: any) => r === propertyValue) >= 0;
  //           })
  //         );
  //       } else {
  //         this.dataSource = new MatTableDataSource(this.clientlist);
  //       }
  //     });
  //   }
  // }
  applyDynamicFilter(control: FormControl, searchProperty: any) {
    if (control) {
      control.valueChanges.subscribe((res: any) => {
        if (res && res.length > 0) {
          this.dataSource = new MatTableDataSource(
            this.clientlist.filter((client: any) => {
              const propertyValue = this.getNestedPropertyValue(client, searchProperty);
              if (searchProperty === 'IsActive') {
                return res.includes(propertyValue ? 'Yes' : 'No');
              }
              return res.includes(propertyValue);
            })
          );
        } else {
          this.dataSource = new MatTableDataSource(this.clientlist);
        }
        this.dataSource.paginator = this.paginator;
      });
    }
  }
  
  getNestedPropertyValue(object: any, propertyPath: string): any {
    return propertyPath.split('.').reduce((obj, prop) => obj && obj[prop], object);
  }
  checkIfAllSelected(formControl: FormControl, arrayList: []): boolean {
    if (formControl.value?.length) {
      return formControl.value.length === arrayList.length;
    } else {
      return false;
    }
  }
  selectAllForActive(e: any) {
    this.allActivesSelected = !this.allActivesSelected;
    if (e.checked) {
      this.IsActive.setValue(this.IsActiveList.slice(0));
    } else {
      this.IsActive.setValue('');
    }
    this.dataSource.paginator = this.paginator;
  }
  selectAllForStatus(e: any) {
    this.allSatusSelected = !this.allSatusSelected;
    if (e.checked) {
      this.Status.setValue(this.StatusList.slice(0));
    } else {
      this.Status.setValue('');
    }
    this.dataSource.paginator = this.paginator;
  }
  selectAllForClientType(e:any){
   this.allClientTypeSelected = !this.allClientTypeSelected;
   if(e.checked){
    this.ClientType.setValue(this.ClientTypeList.slice(0));
   } else{
    this.ClientType.setValue('');
   }
   this.dataSource.paginator = this.paginator;
  }
  loadDropdowns(){
    this.loadActive();
    this.loadClientType();
  }
  loadActive(): void {
    this.activeService.get(this.config.environment.endpoints.client).subscribe({
        next: (actives: ClientRes) => {
          if (actives) {
            this.ActiveList = [...new Set(actives.data.map((client: ClientModel) => client.IsActive)),];
          } else {
            this.ActiveList = [];
          }
        },
      });
  }
  loadClientType(){
    this.clientTypeService.get(this.config.environment.endpoints.clientdomain).subscribe({
      next: (clienttype: ClientTypeRes) => {
        if (clienttype && clienttype.data.length > 0) {
          this.ClientTypeList = clienttype.data.map((clientType: ClientDomain) => clientType.ClientDomain); 
         } else {
          this.ClientTypeList = [];
        }
      },
    });
  }
  clearEndDate(): void {
    this.EndDate.reset();
  }
  clearModifiedDateRange():void{
    this.ModifiedDateRange.reset();
  }
  clearCreatedAtDateRange(): void {
    this.CreatedAtDateRange.reset();
  }
}
