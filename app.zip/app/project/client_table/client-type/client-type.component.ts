import { Component, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ConfigService } from '@core/services/config.service';
import { GenericRepositoryService } from '@core/services/generic-repository.service';
import { ClientTypeEditComponent } from '../client-type-edit/client-type-edit.component';
// import { ClientTypeModel, ClientTypeRes } from '@core/models/clienttype';
import { ClientTypeModel, ClientTypeRes } from '@core/models_new/clienttype';
import { AlertService } from '@core/services/alert.service';

@Component({
  selector: 'app-client-type',
  templateUrl: './client-type.component.html',
  styleUrls: ['./client-type.component.scss']
})
export class ClientTypeComponent {
    displayedColumns: string[] = ['SNo','ClientDomain','CreatedDateTime','ModifiedBy','ModifiedDateTime','action']
    dataSource: MatTableDataSource<ClientTypeModel>;
    constructor(private gs: GenericRepositoryService<ClientTypeRes>,private config : ConfigService ,private _dialog: MatDialog,private alertService: AlertService) {
      this.dataSource = new MatTableDataSource<ClientTypeModel>();
    }
    @ViewChild(MatSort) sort!: MatSort;
    @ViewChild(MatPaginator) paginator!: MatPaginator;
      ngOnInit(): void {
        this.getClienttypeList();
      }
      openAddEditForm() {
        const dialogRef = this._dialog.open(ClientTypeEditComponent);
        dialogRef.afterClosed().subscribe({
          next: (val) => {
            if (val) {
              this.getClienttypeList();
            }
          },
        });
      }
      getClienttypeList() {
      this.gs.get(this.config.environment.endpoints.clientdomain).subscribe((res: ClientTypeRes) => {
        if (res && res.code == 200) {
          res.data.sort((a, b) => {
            return new Date(b.CreatedDateTime).getTime() - new Date(a.CreatedDateTime).getTime();
          });
          this.dataSource = new MatTableDataSource(res.data);
          const sort = new MatSort();
          sort.active = 'CreatedDateTime';
          sort.direction = 'desc';
          this.dataSource.sort = this.sort;
          this.dataSource.paginator = this.paginator;
        }
      });
    }
    applyFilter(event: Event) {
      const filterValue = (event.target as HTMLInputElement).value;
      this.dataSource.filter = filterValue.trim().toLowerCase();
      if (this.dataSource.paginator) {
        this.dataSource.paginator.firstPage();
      }
    }
    deleteClientTypeName(id: number) {
      this.gs.delete(this.config.environment.endpoints.clientdomain,id).subscribe({
        next: (res: ClientTypeRes) => {
          if (res && res.code == 200) {
            this.alertService.show('Success','Deleted successfully!');
            this.getClienttypeList();
          }
          else {
            this.alertService.show( 'Error','Not deleted !');
          }
        },
        error: (err: any) => {
          this.alertService.show('Error','Not deleted !');
        },
      });
    }
    openEditForm(clientId: string) {
      const dialogRef = this._dialog.open(ClientTypeEditComponent, {
        data:{clientId:clientId},
      });
      dialogRef.afterClosed().subscribe({
        next: (val) => {
          if (val) {
            this.getClienttypeList();
          }
        },
      });
    }
    deleteClienttype(id: number) {
      this.gs.delete(this.config.environment.endpoints.clientdomain,id).subscribe({
        next: (res: ClientTypeRes) => {
          if (res && res.code == 200) {
            this.alertService.show('Success','Deleted successfully!');
            this.getClienttypeList();
          }
          else {
            this.alertService.show('Error','Not deleted!');
          }
        },
        error: (err: any) => {
          this.alertService.show('Error','Not deleted!');
        },
      });
    }
  
  }