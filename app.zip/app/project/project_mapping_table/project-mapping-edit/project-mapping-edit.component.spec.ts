import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProjectMappingEditComponent } from './project-mapping-edit.component';

describe('ProjectMappingEditComponent', () => {
  let component: ProjectMappingEditComponent;
  let fixture: ComponentFixture<ProjectMappingEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProjectMappingEditComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ProjectMappingEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
