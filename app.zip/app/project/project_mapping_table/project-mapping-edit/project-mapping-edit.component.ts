import { DatePipe } from '@angular/common';
import { Component, Inject, inject, OnInit, AfterViewInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, ValidatorFn, Validators } from '@angular/forms';
import { DateAdapter, MAT_DATE_FORMATS } from '@angular/material/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AppDateAdapter, APP_DATE_FORMATS } from '@core/common/dateAdapter';
import { BillingStatusModel, BillingStatusRes } from '@core/models_new/billingstatus';
import { ProjectModel, ProjectRes} from '@core/models_new/project';
import {EmployeeModel, EmployeeRes} from '@core/models_new/employee'
import { ProjectMapping, ProjectMappingModel, ProjectMappingReq, ProjectMappingRes } from '@core/models_new/project-mapping';
import { AlertService } from '@core/services/alert.service';
import { ConfigService } from '@core/services/config.service';
import { GenericRepositoryService } from '@core/services/generic-repository.service';

@Component({
  selector: 'app-project-mapping-edit',
  templateUrl: './project-mapping-edit.component.html',
  styleUrls: ['./project-mapping-edit.component.scss'],
  providers: [
    { provide: DateAdapter, useClass: AppDateAdapter },
    { provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS },
  ],
})
export class ProjectMappingEditComponent implements OnInit, AfterViewInit {
  projectmappingForm!: FormGroup;
  BillingStatusList!:BillingStatusModel[];
  ProjectList!:ProjectModel[];
  EmployeeList!:EmployeeModel[];
  ShadowToEmployeeList!:EmployeeModel[];
  EmployeesMappedToProjectsList!:ProjectMappingModel[];
  projectTypeService = inject(GenericRepositoryService<ProjectMappingRes>)
  billingStatusService = inject(GenericRepositoryService<BillingStatusRes>)
  employeeService = inject(GenericRepositoryService<EmployeeRes>)
  shadowtoemployeeService = inject(GenericRepositoryService<EmployeeRes>)

  ProjectMappingTypeList!:ProjectMappingModel[];
  ShadowToEmployeeOptions!: EmployeeModel[];
  EmployeeOptions!:EmployeeModel[];
  isSubmitted: boolean=false;
  isShadowToEmployee: boolean= false;
  Statuses = [
    { value: 'Active', viewValue: 'Active' },
    { value: 'Released', viewValue: 'Released' }
  ];
  constructor(
    private _fb: FormBuilder,
    private gs:GenericRepositoryService<ProjectMappingReq>,
    private gsForPost:GenericRepositoryService<ProjectMapping>,
    private config:ConfigService,
    private _dialogRef: MatDialogRef<ProjectMappingEditComponent>,
    private alertService: AlertService,
    private datepipe: DatePipe,
    @Inject(MAT_DIALOG_DATA) public data: { projectmappingId:  number},

  ) {
    this.loadDropdowns();
    this.projectmappingForm = this._fb.group({
      ProjectId: new FormControl('',[Validators.required]),
      StartDate: new FormControl('',[Validators.required]),
      EndDate : new FormControl('',[Validators.required,this.endDateValidator]),
      BillingStatusId: new FormControl('',[Validators.required]),
      Employee: new FormControl('',{ validators: [autocompleteObjectValidator(), Validators.required] }),
      ShadowToEmployeeId: new FormControl(null,{ validators: [autocompleteObjectValidator(), Validators.required] }),
      EffortPercentage: new FormControl('',[Validators.required]),
      UtilizedPercentage: 0,
      RemainingPercentage: 0,
      Status: new FormControl('',[Validators.required]),
    });
  }
  onProjectChange() {
  const selectedProjectId = this.ProjectId?.value;
  console.log(this.EmployeeList,'employee')
  this.ShadowToEmployeeOptions = this.EmployeeList?.filter((employee: EmployeeModel) =>
    employee.ClientBillable &&
    employee.Id !== this.Employee?.value?.Id &&
    this.EmployeesMappedToProjectsList?.some(
      (empMapped) =>
        empMapped.Project.Id === selectedProjectId && empMapped.Associate.Id === employee.Id 
    )
  );
  this.projectmappingForm.get('Employee')?.setValue(this.Employee?.value);
  }
 onbillingChange(){
   const selectedProjectId = this.ProjectId?.value;
   const selectedBillingStatusId = this.BillingStatusId?.value;
   const billingStatusName = this.BillingStatusList?.find((m: BillingStatusModel) => m.Id == selectedBillingStatusId)?.BillingStatus || '';
 
   this.projectmappingForm.get('ShadowToEmployeeId')?.setValue(null);

   if (billingStatusName && billingStatusName.toLowerCase().includes('shadow')) {
     this.ShadowToEmployeeOptions = this.EmployeeList?.filter(
       (employee: EmployeeModel) =>
         employee.Id !== this.Employee?.value?.Id &&
         this.EmployeesMappedToProjectsList?.some(
           (empMapped) =>
             empMapped.Project.Id === selectedProjectId && empMapped.Associate.Id === employee.Id && empMapped.BillingStatus.Id === 1
         )
     );
     this.projectmappingForm.get('ShadowToEmployeeId')?.setValidators([Validators.required]);
     this.projectmappingForm.get('ShadowToEmployeeId')?.updateValueAndValidity();
     this.isShadowToEmployee = true;
   } else {
     this.projectmappingForm.get('ShadowToEmployeeId')?.clearValidators();
     this.projectmappingForm.get('ShadowToEmployeeId')?.updateValueAndValidity();
     this.isShadowToEmployee = false;
   }

  }
  endDateValidator: ValidatorFn = (): { [key: string]: boolean } | null => {
    const startDate = this.projectmappingForm?.get('StartDate')?.value;
    const endDate = this.projectmappingForm?.get('EndDate')?.value;
    if ( new Date(startDate) > new Date(endDate)) {
      return { 'invalidEndDate': true };
    }
    return null;
  };
  changedStartDate(){
    if(this.projectmappingForm?.get('EndDate')?.value){
      this.projectmappingForm?.get('EndDate')?.setValue(this.projectmappingForm?.get('EndDate')?.value)
    }
  }
  get Employee() {
    return this.projectmappingForm.get('Employee');
  }
  get ProjectId() {
    return this.projectmappingForm.get('ProjectId');
  }
  get StartDate() {
    return this.projectmappingForm.get('StartDate');
  }
  get EndDate() {
    return this.projectmappingForm.get('EndDate');
  }
  get BillingStatusId() {
    return this.projectmappingForm.get('BillingStatusId');
  }
  get ShadowToEmployeeId() {
    return this.projectmappingForm.get('ShadowToAssociateId');
  }
  get EffortPercentage() {
    return this.projectmappingForm.get('EffortPercentage');
  }
  get Status() {
    return this.projectmappingForm.get('Status');
  }
 
  ngOnInit(): void {
    this.Employee?.valueChanges.subscribe((employee : EmployeeModel)=> {
      if (employee && this.EmployeeOptions) {
        const selectedEmployee = this.EmployeeOptions?.find(e => e.Id === employee.Id);
        if (selectedEmployee) {
          this.projectmappingForm.patchValue({
            // EffortPercentage: selectedEmployee.RemainingEffortPercentage,
            // UtilizedPercentage: selectedEmployee.EffortPercentage,
          });
        }
      }
    });
    this.Employee?.valueChanges.subscribe((searchValue: string) => {
      if (searchValue && searchValue.length > 0 ) {
        this.EmployeeOptions = this.EmployeeList?.filter((employee: EmployeeModel) =>
        employee.AssociateName.toLowerCase().includes(searchValue.toLowerCase()) 
        );
      } else if(this.Employee?.touched == false&& searchValue?.length == 0) {
        this.EmployeeOptions = this.EmployeeList
      }
    });
    this.ShadowToEmployeeId?.valueChanges.subscribe((searchValue: string) => {
      if (searchValue && searchValue.length > 0 ) {
        this.ShadowToEmployeeOptions = this.ShadowToEmployeeList?.filter((shadowtoemployee: EmployeeModel) =>
        shadowtoemployee.AssociateName.toLowerCase().includes(searchValue.toLowerCase())
        );
      } else if(this.ShadowToEmployeeId?.touched == false&& searchValue === ''){
        this.ShadowToEmployeeOptions = this.ShadowToEmployeeList
      }
    });
    this.BillingStatusId?.valueChanges.subscribe((billingStatusId: number)=>{
     const billingStatusName= this.BillingStatusList?.filter((m: BillingStatusModel)=> m.Id==billingStatusId)[0]?.BillingStatus ||'';
     this.projectmappingForm.get('ShadowToEmployeeId')?.setValue(null);
     if(billingStatusName && billingStatusName.toLowerCase().includes('shadow')){
       this.projectmappingForm.get('ShadowToEmployeeId')?.setValidators([Validators.required]);
       this.projectmappingForm.get('ShadowToEmployeeId')?.updateValueAndValidity();
       this.isShadowToEmployee= true;
     }
     else{
      this.projectmappingForm.get('ShadowToEmployeeId')?.clearValidators();
      this.projectmappingForm.get('ShadowToEmployeeId')?.updateValueAndValidity();
      this.isShadowToEmployee= false;
     }
    })
  }

  ngAfterViewInit(): void {
    if(this.data){
      this.gs.getById(this.config.environment.endpoints.EmployeeProjectMapping,this.data.projectmappingId).subscribe({
        next:(res:ProjectMappingReq)=>{
          if(res && res.data){
            console.log(res.data, 'on edit data by ID');
            this.projectmappingForm.patchValue(res.data)
            this.projectmappingForm.get('Id')?.setValue(this.data.projectmappingId);
            this.projectmappingForm.get('Employee')?.setValue(res.data.Associate);
            this.projectmappingForm.get('ProjectId')?.setValue(res.data.Project.Id);
            this.projectmappingForm.get('BillingStatusId')?.setValue(res.data.BillingStatus.Id);
            this.projectmappingForm.get('ShadowToAssociateId')?.setValue(res.data.ShadowToAssociate.Id);
            this.projectmappingForm.get('EffortPercentage')?.setValue(res.data.EffortPercentage);
            this.projectmappingForm.get('Status')?.setValue(res.data.Status);
            this.projectmappingForm.get('StartDate')?.setValue(res.data.StartDate);
            this.projectmappingForm.get('StartDate')?.markAsTouched();
            this.projectmappingForm.get('EndDate')?.markAsTouched();
            this.projectmappingForm.get('EndDate')?.setValue(res.data.EndDate);
            this.onProjectChange();
            this.onbillingChange();
            console.log('project form', this.projectmappingForm.value);
            
            
            this.employeeService
            .get(this.config.environment.endpoints.employeeEffort)
            .subscribe({
                next: (resEffort: any) => {
                if (resEffort && resEffort.data) {
                  this.projectmappingForm.patchValue({
                    RemainingPercentage: resEffort.data.find((e: any) => e.Id === res.data.Associate.Id)?.RemainingEffortPercentage,
                  });
                }
              },
            });
          }
        }
      })
    }
  }

  

  onFormSubmit() {
    this.isSubmitted= true;
    if (this.projectmappingForm.valid) {
      const rawForm = this.projectmappingForm.getRawValue();
      let projectmappingObj:ProjectMapping = {
        AuthUserId: rawForm.Employee.Id,
        IsActive:true,
        BillingStatus: rawForm.BillingStatusId,
        ProjectId:rawForm.ProjectId,
        BillingStatusId: rawForm.BillingStatusId,
        EffortPercentage: rawForm.EffortPercentage,
        EndDate: rawForm.EndDate,
        StartDate: rawForm.StartDate,
        ShadowToAssociateId: rawForm.ShadowToEmployeeId,
        Status: rawForm.Status
      };
      projectmappingObj.EndDate =
        this.datepipe
          .transform(this.projectmappingForm.value.EndDate, 'yyyy-MM-dd')
          ?.toString() ?? '';
          projectmappingObj.StartDate =
        this.datepipe
          .transform(this.projectmappingForm.value.StartDate, 'yyyy-MM-dd')
          ?.toString() ?? '';
          projectmappingObj.AuthUserId = this.projectmappingForm.value.Employee?.Id;
          projectmappingObj.ShadowToAssociateId = this.projectmappingForm.value.ShadowToEmployeeId?.Id || null;
      if (this.data) {
        this.gsForPost.update(this.config.environment.endpoints.EmployeeProjectMapping,this.data.projectmappingId, projectmappingObj)
          .subscribe({
            next: (res: any) => {
              if (res && res.code === 200) {
                this.alertService.show('Success',' Updated Successfully');
                this._dialogRef.close(true);
              }else{
                this.alertService.show('Error','Not Updated',);
              }
            },
            error: (err: any) => {
              this.alertService.show('Error','Not Updated');
            },
          });
      } else {
        this.gsForPost.create(this.config.environment.endpoints.EmployeeProjectMapping,projectmappingObj).subscribe({
          next: (res: any) => {
            if (res && res.code === 201) {
              this.alertService.show('Success',' Added successfully!');
              this._dialogRef.close(true);
            }else{
              this.alertService.show('Error','Not added !');
            }
            
          },
          error: (err: any)=>{
            this.alertService.show('Error','Not added !');
           },
        });
      }
    }
  }
  loadDropdowns(){
    this.loadProject()
    this.loadBillingStatus()
    this.loadEmployee()
    this.loadEmployeesMappedToProjects()
  }
  loadProject(){
    this.projectTypeService
      .get(this.config.environment.endpoints.project)
      .subscribe({
        next: (res: ProjectRes) => {
          if (res && res.data) {
            this.ProjectList = res.data;
          } else {
            this.ProjectList = [];
          }
        },
      });
  }
  loadBillingStatus(){
    this.billingStatusService
      .get(this.config.environment.endpoints.BillingStatus)
      .subscribe({
        next: (res: BillingStatusRes) => {
          if (res && res.data) {
            this.BillingStatusList = res.data;
          } else {
            this.BillingStatusList = [];
          }
        },
      });
  }
  loadEmployee(){
    this.employeeService
      .get(this.config.environment.endpoints.employeeEffort)
      .subscribe({
        next: (res: EmployeeRes) => {
          if (res && res.data) {
            console.log(res.data, 'Employtee Dropdown Data');
            
            this.EmployeeList = res.data;
            this.EmployeeOptions = res.data;
            this.ShadowToEmployeeList = res.data;
            this.ShadowToEmployeeOptions= res.data;
          } else {
            this.EmployeeList = [];
            this.ShadowToEmployeeList = [];
            this.EmployeeOptions=[];
            this.ShadowToEmployeeOptions=[];
          }
        },
      });
  }
  loadEmployeesMappedToProjects(){
    this.gs.get(this.config.environment.endpoints.EmployeeProjectMapping).subscribe((res:any) => {
     this.EmployeesMappedToProjectsList=res.data;
     console.log(this.EmployeesMappedToProjectsList,'emp mapped to projects')
    })
  }
  displayFn(emp: EmployeeModel): string {
    return emp && emp.AssociateName ? emp.AssociateName : '';
  }
}
function autocompleteObjectValidator(): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } | null => {
    if (typeof control.value === 'string') {
      return { 'invalidAutocompleteObject': { value: control.value } }
    }
    return null
  }
}