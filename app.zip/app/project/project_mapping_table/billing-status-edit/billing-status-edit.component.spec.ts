import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BillingStatusEditComponent } from './billing-status-edit.component';

describe('BillingStatusEditComponent', () => {
  let component: BillingStatusEditComponent;
  let fixture: ComponentFixture<BillingStatusEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BillingStatusEditComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BillingStatusEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
