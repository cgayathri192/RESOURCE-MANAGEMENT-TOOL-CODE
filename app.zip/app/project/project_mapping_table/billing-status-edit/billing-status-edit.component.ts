import { Component, Inject } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { BillingStatusReq } from '@core/models_new/billingstatus';
import { AlertService } from '@core/services/alert.service';
import { ConfigService } from '@core/services/config.service';
import { GenericRepositoryService } from '@core/services/generic-repository.service';

@Component({
  selector: 'app-billing-status-edit',
  templateUrl: './billing-status-edit.component.html',
  styleUrls: ['./billing-status-edit.component.scss']
})
export class BillingStatusEditComponent {
  billingstatusForm!: FormGroup;
  isSubmitted: boolean=false;
  constructor(
    private _fb: FormBuilder,
    private gs:GenericRepositoryService<BillingStatusReq>,
    private config:ConfigService,
    private alertService:AlertService,
    private _dialogRef: MatDialogRef<BillingStatusEditComponent>,
    @Inject(MAT_DIALOG_DATA) public data: {billingId:number},
  ) {
    this.billingstatusForm = this._fb.group({
      BillingStatus: new FormControl('', [Validators.required]),
    });
  }
  get BillingStatus(){
    return this.billingstatusForm.get('BillingStatus');
  }
 
  ngOnInit(): void {
    if(this.data){
      this.gs.getById(this.config.environment.endpoints.BillingStatus,this.data.billingId).subscribe({
        next:(res:BillingStatusReq)=>{
          if(res.data){
            this.billingstatusForm.get('Id')?.setValue(this.data.billingId);
            this.billingstatusForm.get('BillingStatus')?.setValue(res.data.BillingStatus);
            
            
          }
        }
      })
    } 
  }
  onFormSubmit() {
    this.isSubmitted= true;
    if (this.billingstatusForm.valid) {
      if (this.data) {
        this.gs
          .update(this.config.environment.endpoints.BillingStatus,this.data.billingId, this.billingstatusForm.value)
          .subscribe({
            next: (res: any) => {
              if (res && res.code === 200) {
                this.alertService.show('Success','Billing Status updated successfully!');
                this._dialogRef.close(true);
              }else{
                this.alertService.show( 'Error','Billing Status not updated!');
              }
              
            },
            error: (err: any) => {
              this.alertService.show('Error','Billing Status not updated!');
            },
          });
      } else {
        this.gs.create(this.config.environment.endpoints.BillingStatus,this.billingstatusForm.value).subscribe({
          next: (res: any) => {
            if (res && res.code === 201) {
              this.alertService.show('Success','Billing Status added successfully!');
              this._dialogRef.close(true);
            }else{
              this.alertService.show( 'Error','Billing Status not added !');
            }
            
          },
          error: (err: any) => {
            this.alertService.show('Error','Billing Status not added!');
          },
        });
      }
    }
  }
}
