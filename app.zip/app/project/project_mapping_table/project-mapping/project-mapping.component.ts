import { DatePipe } from '@angular/common';
import { Component, ViewChild, inject } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ProjectMappingModel, ProjectMappingRes } from '@core/models_new/project-mapping';
import { ConfigService } from '@core/services/config.service';
import { GenericRepositoryService } from '@core/services/generic-repository.service';
import { ProjectMappingEditComponent } from '../project-mapping-edit/project-mapping-edit.component';
import { FormGroup, FormControl } from '@angular/forms';
import { Column } from '@home-module/skills_table/skills/skills.component';
import { MAT_DATE_FORMATS ,DateAdapter} from '@angular/material/core';
import { AppDateAdapter, APP_DATE_FORMATS } from '@core/common/dateAdapter';
import { StatusModel, StatusRes } from '@core/models/status';
import { BillingStatusModel, BillingStatusRes } from '@core/models_new/billingstatus';
import { Project, ProjectModel, ProjectRes } from '@core/models_new/project';
import { AlertService } from '@core/services/alert.service';

@Component({
  selector: 'app-project-mapping',
  templateUrl: './project-mapping.component.html',
  styleUrls: ['./project-mapping.component.scss'],
  providers: [
    { provide: DateAdapter, useClass: AppDateAdapter },
    { provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS },
  ],
})
export class ProjectMappingComponent {
  fixedColumns: Column[] = [
    { ColumnName: 'SNo', DisplayName: 'S.no', DefaultLoad: true },
    { ColumnName: 'BillingStatus', DisplayName: 'Billing Status', DefaultLoad: true },
    { ColumnName: 'Employee',DisplayName: 'Employee',DefaultLoad: true,},
    { ColumnName: 'Project', DisplayName: 'Project', DefaultLoad: true },
  ];
  allColumns: Column[] = [
    { ColumnName: 'ShadowToEmployee', DisplayName: 'Shadow to Associate',DefaultLoad: true},
    { ColumnName: 'EffortPercentage', DisplayName: 'Effort Percentage', DefaultLoad: false },
    { ColumnName: 'Status', DisplayName: 'Status',DefaultLoad: false},
    { ColumnName: 'StartDate', DisplayName: 'Start Date', DefaultLoad: false },
    { ColumnName: 'EndDate', DisplayName: 'End Date',DefaultLoad: false},
    { ColumnName: 'ModifiedBy', DisplayName: 'Modified By', DefaultLoad: false },
    { ColumnName: 'ModifiedAt', DisplayName: 'Modified At',DefaultLoad: false},
    { ColumnName: 'CreatedAt', DisplayName: 'Created At', DefaultLoad: false },
  ]
  actionColumn: Column = { ColumnName: 'action',DisplayName: 'Action',DefaultLoad: true };
  displayedColumns: string[] = [...this.fixedColumns.filter((col: Column) => col.DefaultLoad).map((column: Column) => column.ColumnName),...this.allColumns.filter((col: Column) => col.DefaultLoad).map((column: Column) => column.ColumnName),].concat(this.actionColumn.ColumnName);
  projectmapping_list:ProjectMappingModel[]=[];
  ModifiedDateRange = new FormGroup({
    start: new FormControl(null),
    end: new FormControl(null),
  });
  EndDate = new FormGroup({
    start: new FormControl(null),
    end: new FormControl(null),
  });
  CreatedAtDateRange = new FormGroup({
    start: new FormControl(null),
    end: new FormControl(null),
  });
  BillingStatus = new FormControl('');
  ModifiedBy = new FormControl('');
  allStatusesSelected:boolean=true;
  ProjectStatusList: any;
  Status=new FormControl('');
  BillingStatusList:any;
  allBillingSelected:boolean=true;
  allProjectSelected:boolean=true;
  ProjectList:any;
  Project=new FormControl('');
  ShadowToEmployee=new FormControl('');
  ShadowToEmployeeList:any;
  allShadowToEmployeeSelected:boolean=true;
  projectstatusService = inject(GenericRepositoryService<StatusRes>);
  BillingStatusService=inject(GenericRepositoryService<BillingStatusRes>);
  ShadowService = inject(GenericRepositoryService<ProjectMappingRes>)
  ProjectService=inject(GenericRepositoryService<ProjectRes>);
  sortOrder: 'asc' | 'desc' = 'asc';
  dataSource: MatTableDataSource<ProjectMappingModel>;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  StartDateRange = new FormGroup({
    start: new FormControl(null),
    end: new FormControl(null),
  });
  EndDateRange = new FormGroup({
    start: new FormControl(null),
    end: new FormControl(null),
  });
  allSelected = false;
  constructor(private gs: GenericRepositoryService<ProjectMappingRes>, 
    private config: ConfigService, private _dialog: MatDialog, 
    private alertService: AlertService, private datepipe: DatePipe) 
    { this.dataSource = new MatTableDataSource<ProjectMappingModel>();}
  ngOnInit(): void {
    let controlFilters: any[] = [
      { control: this.BillingStatus, value: 'BillingStatus.BillingStatusName' },
      { control: this.ModifiedBy, value: 'ModifiedBy.ResourceName' },
      { control: this.Status, value: 'ProjectStatus.Projectstatus' },
      {control:this.Project, value:'Project.ProjectName'},
      {control:this.ShadowToEmployee, value:'ShadowToEmployee.ResourceName'}
    ];
    for (var controlfilter = 0; controlfilter < controlFilters.length; controlfilter++) {
      this.applyDynamicFilter(controlFilters[controlfilter].control, controlFilters[controlfilter].value);
    }
    this.getProjectMapping();
    this.loadDropdowns(); 
    this.StartDateRange.valueChanges.subscribe((formValues: any) => {
      if (formValues.start && formValues.end) {
        this.dataSource = new MatTableDataSource(
          this. projectmapping_list.filter((prosd: any) => {
            let projectStartDate = new Date(prosd.StartDate);
            let startDate = new Date(formValues.start);
            let endDate = new Date(formValues.end);
            endDate.setDate(endDate.getDate() + 1);
            return projectStartDate >= startDate && projectStartDate < endDate;
          })
        );
      } else {
        this.dataSource = new MatTableDataSource(this. projectmapping_list);
        this.dataSource.paginator = this.paginator;
      }
    });
    this.EndDateRange.valueChanges.subscribe((formValues: any) => {
      if (formValues.start && formValues.end) {
        this.dataSource = new MatTableDataSource(
          this. projectmapping_list.filter((profd: any) => {
            let projectFinishDate = new Date(profd.FinishDate);
            let startDate = new Date(formValues.start);
            let endDate = new Date(formValues.end);
            endDate.setDate(endDate.getDate() + 1);
            return projectFinishDate >= startDate && projectFinishDate < endDate;
          })
        );
      } else {
        this.dataSource = new MatTableDataSource(this. projectmapping_list);
        this.dataSource.paginator = this.paginator;
      }
    });
    this.ModifiedDateRange.valueChanges.subscribe((formValues: any) => {
      if (formValues.start && formValues.end) {
        this.dataSource = new MatTableDataSource(this.projectmapping_list.filter((client: any) => {
            let clientDate = new Date(client.ModifiedAt);
            let startDate = new Date(formValues.start);
            let endDate = new Date(formValues.end);
            endDate.setDate(endDate.getDate() + 1);
            return clientDate >= startDate && clientDate < endDate;
          })
        );
      } else {
        this.dataSource = new MatTableDataSource(this.projectmapping_list);
      }
    });
    this.CreatedAtDateRange.valueChanges.subscribe((formValues: any) => {
      if (formValues.start && formValues.end) {
        this.dataSource = new MatTableDataSource(
          this.projectmapping_list.filter((emp: any) => {
            let projectCreateAt = new Date(emp.CreatedAt);
            let startDate = new Date(formValues.start);
            let endDate = new Date(formValues.end);
            endDate.setDate(endDate.getDate() + 1);
            return projectCreateAt >= startDate && projectCreateAt < endDate;
          })
        );
      } else {
        this.dataSource = new MatTableDataSource(this.projectmapping_list);
        this.dataSource.paginator = this.paginator;
      }
    });
  }
  loadDropdowns(){
    this.loadStatus();
    this.loadBillingStatus();
    this.loadProject();
    this.loadShadowToEmployee();
    
  }
  loadShadowToEmployee(){
    this.ShadowService.get(this.config.environment.endpoints.EmployeeProjectMapping).subscribe({
      next: (shadow:ProjectMappingRes)=>{
        if(shadow && shadow.data.length>0){
          this.ShadowToEmployeeList=[...new Set(shadow.data.map((ShadowToEmployee:ProjectMappingModel)=>ShadowToEmployee.Associate.AssociateName))];
        }else{
          this.ShadowToEmployeeList=[];
        }
      }
    })
  }
  loadStatus(){
    this.projectstatusService.get(this.config.environment.endpoints.projectstatus).subscribe({
      next: (statuses: StatusRes) => {
        if (statuses && statuses.data.length > 0) {
          this.ProjectStatusList = [...new Set(statuses.data.map((projectstatus: StatusModel) => projectstatus.Projectstatus))];
        } else {
          this.ProjectStatusList = [];
        }
      },
    });
  }
  loadBillingStatus(){
    this.BillingStatusService.get(this.config.environment.endpoints.BillingStatus).subscribe({
      next:(Billing:BillingStatusRes)=>{
        if(Billing && Billing.data.length>0){
          this.BillingStatusList = [...new Set(Billing.data.map((BillingStatus:BillingStatusModel)=>BillingStatus.BillingStatus))];
        }else{
          this.BillingStatusList=[];
        }
      }
    })
  }
  loadProject(){
    this.ProjectService.get(this.config.environment.endpoints.project).subscribe({
      next:(pro:ProjectRes)=>{
        if(pro && pro.data.length>0){
          this.ProjectList=[...new Set(pro.data.map((Project:ProjectModel)=>Project.Project))];
        }
        else{
          this.ProjectList=[];
        }
      }
    })
  }
  toggleDisplayColumns(): void {
    if (this.displayedColumns.length - (this.fixedColumns.length + 1) === this.allColumns.length) {
      this.displayedColumns = [...this.fixedColumns.map((column) => column.ColumnName)].concat(this.actionColumn.ColumnName);
    } else {
      this.displayedColumns = [...this.fixedColumns.map((column) => column.ColumnName), ...this.allColumns.map((column) => column.ColumnName)].concat(this.actionColumn.ColumnName);
    }
  }
  onColumnSelect(selectedColumns: string[]) {
    this.displayedColumns = [...this.fixedColumns.map((column) => column.ColumnName), ...selectedColumns].concat(this.actionColumn.ColumnName);
    if (selectedColumns.length !== this.allColumns.length) {
      this.displayedColumns = [...this.fixedColumns.map((column) => column.ColumnName), ...selectedColumns].concat(this.actionColumn.ColumnName);
    }
  }
  openEditProjectMappingForm() {
    const dialogRef = this._dialog.open(ProjectMappingEditComponent);
    dialogRef.afterClosed().subscribe({
      next: (val) => {
        if (val) {
          this.getProjectMapping();
        }
      },
    });
  }
  applyDynamicFilter(control: FormControl, searchproperty: any) {
    if (control) {
      control.valueChanges.subscribe((res: any) => {
        if (res && res.length > 0) {
          this.dataSource = new MatTableDataSource(this.projectmapping_list.filter((mapping: any) => {
              const propertyValue = this.getNestedPropertyValue(mapping, searchproperty);
              return res.findIndex((r: any) => r === propertyValue) >= 0;
            })
          );
        } else {
          this.dataSource = new MatTableDataSource(this.projectmapping_list);
        }
      });
    }
  }
  getNestedPropertyValue(object: any, propertyPath: string): any {
    return propertyPath.split('.').reduce((obj, prop) => obj && obj[prop], object);
  }
  getProjectMapping() {
    this.gs.get(this.config.environment.endpoints.EmployeeProjectMapping).subscribe((res: ProjectMappingRes) => {
      if (res && res.code == 200) {
        this.projectmapping_list = res.data;
        this.dataSource = new MatTableDataSource(this.projectmapping_list);
        const sort = new MatSort();
        sort.active = 'CreatedAt';
        sort.direction = 'desc';
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
      }
    });
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value.trim().toLowerCase();;
    this.dataSource.filter = filterValue;
    this.dataSource.filterPredicate = (data:ProjectMappingModel, filter:string)=> {
      return this.filterData(data,filter);
    };
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  filterData(data: any, filter: string): boolean {
    for (const key in data) {
      if (data.hasOwnProperty(key)) {
        let value = data[key]  ?? null;
        if(key == "ModifiedAt" || key == "CreatedAt"){
          value = this.datepipe.transform(data[key], 'dd MMM, yyyy') ?? null;
        }
        if (typeof value === 'object' && value !== null) {
          if (this.filterData(value, filter)) {
            return true;
          }
        } else {
          if (value !== null && value.toString().toLowerCase().includes(filter)) {
            return true;
          }
        }
      }
    }
    return false;
  }
  openEditForm(projectmappingId: number) {
    const dialogRef = this._dialog.open(ProjectMappingEditComponent, {
      data:{projectmappingId:projectmappingId}
    });
    dialogRef.afterClosed().subscribe({
      next: (val) => {
        if (val) {
          this.getProjectMapping();
        }
      },
    });
  }
  deleteProjectMapping(id: number) {
    this.gs.delete(this.config.environment.endpoints.EmployeeProjectMapping, id).subscribe({
      next: (res: ProjectMappingRes) => {
        if (res && res.code == 200) {
          this.alertService.show( 'Success','Deleted successfully!');
          this.getProjectMapping();
        }
        else {
          this.alertService.show('Error','Not deleted successfully!');
        }
      },
      error: (err: any)=>{
         this.alertService.show('Error','Not deleted successfully!');
        },
    });
  }
  selectAllForStatus(e: any) {
    this.allStatusesSelected = !this.allStatusesSelected;
    if (e.checked) {
      this.Status.setValue(this.ProjectStatusList.slice(0));
    } else {
      this.Status.setValue('');
    }
    this.dataSource.paginator = this.paginator;
  }
  selectAllForBillingStatus(e:any){
    this.allBillingSelected=!this.allBillingSelected;
    if(e.checked){
      this.BillingStatus.setValue(this.BillingStatusList.slice(0));
    }else{
      this.BillingStatus.setValue('');
    }
    this.dataSource.paginator = this.paginator;
  }
  selectAllForProject(e:any){
    this.allProjectSelected=!this.allProjectSelected;
    if(e.checked){
      this.Project.setValue(this.ProjectList.slice(0));
    }else{
      this.Project.setValue('');
    }
    this.dataSource.paginator=this.paginator;
  }
  selectAllForShadowToEmployee(e:any){
    this.allShadowToEmployeeSelected=!this.allShadowToEmployeeSelected;
    if(e.checked){
      this.ShadowToEmployee.setValue(this.ShadowToEmployeeList.slice(0));
    }else{
      this.ShadowToEmployee.setValue('');
    }
    this.dataSource.paginator=this.paginator;
  }
  applySort(type: any) {
    this.sortOrder = this.sortOrder === 'asc' ? 'desc' : 'asc';
    let valueA: any;
    let valueB: any;
  }
  clearStartDateRange(): void {
    this.StartDateRange.reset();
  }
  clearEndDateRange(): void {
    this.EndDateRange.reset();
  }
  clearModifiedDateRange():void{
    this.ModifiedDateRange.reset();
  }
  clearCreatedAtDateRange(): void {
    this.CreatedAtDateRange.reset();
  }
  checkIfAllSelected(formControl: FormControl, arrayList: []): boolean {
    if (formControl.value?.length) {
      return formControl.value.length === arrayList.length;
    } else {
      return false;
    }
  }
}
