import { DatePipe } from '@angular/common';
import { Component, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { BillingStatusModel, BillingStatusRes } from '@core/models_new/billingstatus';
import { ConfigService } from '@core/services/config.service';
import { GenericRepositoryService } from '@core/services/generic-repository.service';
import { BillingStatusEditComponent } from '../billing-status-edit/billing-status-edit.component';
import { AlertService } from '@core/services/alert.service';

@Component({
  selector: 'app-billing-status',
  templateUrl: './billing-status.component.html',
  styleUrls: ['./billing-status.component.scss']
})
export class BillingStatusComponent {
  displayedColumns: string[] = ['SNo','BillingStatusName', 'CreatedAt', 'ModifiedBy','ModifiedAt','action']
  dataSource: MatTableDataSource<BillingStatusModel>;
  constructor(private gs1: GenericRepositoryService<BillingStatusRes>, private gs: GenericRepositoryService<BillingStatusRes>, private config: ConfigService, private _dialog: MatDialog, private alertService: AlertService, private datepipe: DatePipe ) {
    this.dataSource = new MatTableDataSource<BillingStatusModel>();
  }
  @ViewChild(MatSort) sort!: MatSort;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  ngOnInit(): void {
    this.getBillingStatus();
  }
  openAddEditForm() {
    const dialogRef = this._dialog.open(BillingStatusEditComponent);
    dialogRef.afterClosed().subscribe({
      next: (val) => {
        if (val) {
          this.getBillingStatus();
          this.alertService.show( 'Success','Billing Status Added Successfully!');
        }
      },
    });
  }
  getBillingStatus() {
    this.gs.get(this.config.environment.endpoints.BillingStatus).subscribe((res: BillingStatusRes) => {
      if (res && res.code == 200) {
        res.data.sort((a, b) => {
          return new Date(b.CreatedDateTime).getTime() - new Date(a.CreatedDateTime).getTime();
        });
        this.dataSource = new MatTableDataSource(res.data);
        const sort = new MatSort();
        sort.active = 'CreatedAt';
        sort.direction = 'desc';
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
      }
    });
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value.trim().toLowerCase();;
    this.dataSource.filter = filterValue;
    this.dataSource.filterPredicate = (data:BillingStatusModel, filter:string)=> {
      return this.filterData(data,filter);
    };
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  openEditForm(billingId: string) {
    const dialogRef = this._dialog.open(BillingStatusEditComponent, {
      data: { billingId: billingId },
    });
    dialogRef.afterClosed().subscribe({
      next: (val) => {
        if (val) {
          this.getBillingStatus();
        }
      },
    });
  }
  deleteBillingStatus(id: number) {
    this.gs.delete(this.config.environment.endpoints.BillingStatus, id).subscribe({
      next: (res: BillingStatusRes) => {
        if (res && res.code == 200) {
          this.alertService.show('Success','Deleted successfully!');
          this.getBillingStatus();
        }
        else {
          this.alertService.show('Error','Not deleted !');
        }
      },
      error: (err: any) => {
        this.alertService.show('Error','Not deleted !');
      },
    });
  }
  filterData(data: any, filter: string): boolean {
    for (const key in data) {
      if (data.hasOwnProperty(key)) {
        let value = data[key]  ?? null;
        if(key == "ModifiedAt" || key == "CreatedAt"){
          value = this.datepipe.transform(data[key], 'dd MMM yyyy') ?? null;
        }
        if (typeof value === 'object' && value !== null) {
          if (this.filterData(value, filter)) {
            return true;
          }
        } else {
          if (value !== null && value.toString().toLowerCase().includes(filter)) {
            return true;
          }
        }
      }
    }
    return false;
  }
}
