import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BillingStatusComponent } from './billing-status.component';

describe('BillingStatusComponent', () => {
  let component: BillingStatusComponent;
  let fixture: ComponentFixture<BillingStatusComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BillingStatusComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BillingStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
