import { Component, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ProjectTypeModel, ProjectTypeRes } from '@core/models_new/projecttype';
import { ConfigService } from '@core/services/config.service';
import { GenericRepositoryService } from '@core/services/generic-repository.service';
import { ProjecttypeEditComponent } from '../projecttype-edit/projecttype-edit.component';
import { AlertService } from '@core/services/alert.service';

@Component({
  selector: 'app-project-type',
  templateUrl: './project-type.component.html',
  styleUrls: ['./project-type.component.scss']
})
export class ProjectTypeComponent {
  displayedColumns: string[] = ['SNo', 'ProjectTypeName', 'CreatedAt', 'ModifiedBy', 'ModifiedAt', 'action']
  dataSource: MatTableDataSource<ProjectTypeModel>;
  constructor(private gs: GenericRepositoryService<ProjectTypeRes>, private config: ConfigService, private _dialog: MatDialog, private alertService: AlertService) {
    this.dataSource = new MatTableDataSource<ProjectTypeModel>();
  }
  @ViewChild(MatSort) sort!: MatSort;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  ngOnInit(): void {
    this.getProjecttypeList();
  }
  openAddEditForm() {
    const dialogRef = this._dialog.open(ProjecttypeEditComponent);
    dialogRef.afterClosed().subscribe({
      next: (val) => {
        if (val) {
          this.getProjecttypeList();
          this.alertService.show('Success','ProjectType Added Successfully!');
        }
      },
    });
  }
  getProjecttypeList() {
    this.gs.get(this.config.environment.endpoints.projecttype).subscribe((res: ProjectTypeRes) => {
      if (res && res.code == 200) {
        res.data.sort((a, b) => {
          return new Date(b.CreatedDateTime).getTime() - new Date(a.CreatedDateTime).getTime();
        });
        this.dataSource = new MatTableDataSource(res.data);
        const sort = new MatSort();
        sort.active = 'CreatedAt';
        sort.direction = 'desc';
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
      }
    });
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  deleteProjectTypeName(id: number) {
    this.gs.delete(this.config.environment.endpoints.projecttype, id).subscribe({
      next: (res: ProjectTypeRes) => {
        if (res && res.code == 200) {
          this.alertService.show( 'Success','Deleted successfully!');
          this.getProjecttypeList();
        }
        else {
          this.alertService.show('Error','Not deleted successfully!');
        }
      },
      error: (err: any) => {
        this.alertService.show( 'Error','Not deleted successfully!');
      },
    });
  }
  openEditForm(projecttypeId: string) {
    const dialogRef = this._dialog.open(ProjecttypeEditComponent, {
      data: { projecttypeId: projecttypeId },
    });
    dialogRef.afterClosed().subscribe({
      next: (val) => {
        if (val) {
          this.getProjecttypeList();
          this.alertService.show('Success','ProjectType updated!');
        }
      },
    });
  }
  deleteProjecttype(id: number) {
    this.gs.delete(this.config.environment.endpoints.projecttype, id).subscribe({
      next: (res: ProjectTypeRes) => {
        if (res && res.code == 200) {
          this.alertService.show('Success','Deleted successfully!');
          this.getProjecttypeList();
        }
        else {
          this.alertService.show('Error','Not deleted !');
        }
      },
      error: (err: any) => {
        this.alertService.show( 'Error','Not deleted !');
      },
    });
  }

}
