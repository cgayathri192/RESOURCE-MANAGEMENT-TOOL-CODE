import { Component, Inject } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ProjectTypeReq } from '@core/models_new/projecttype';
import { AlertService } from '@core/services/alert.service';
import { ConfigService } from '@core/services/config.service';
import { GenericRepositoryService } from '@core/services/generic-repository.service';

@Component({
  selector: 'app-projecttype-edit',
  templateUrl: './projecttype-edit.component.html',
  styleUrls: ['./projecttype-edit.component.scss']
})
export class ProjecttypeEditComponent {
  projecttypeForm!: FormGroup;
  isSubmitted: boolean = false;
  constructor(
    private _fb: FormBuilder,
    private gs: GenericRepositoryService<ProjectTypeReq>,
    private config: ConfigService,
    private alertService: AlertService,
    private _dialogRef: MatDialogRef<ProjecttypeEditComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { projecttypeId: number },
  ) {
    this.projecttypeForm = this._fb.group({
      ProjectType: new FormControl('', [Validators.required])
    });
  }
  get ProjectType() {
    return this.projecttypeForm.get('ProjectType');
  }
  ngOnInit(): void {
    if (this.data) {
      this.gs.getById(this.config.environment.endpoints.projecttype, this.data.projecttypeId).subscribe({
        next: (res: ProjectTypeReq) => {
          if (res.data) {
            this.projecttypeForm.patchValue(res.data);
          }
        }
      })
    }
  }
  onFormSubmit() {
    this.isSubmitted = true;
    if (this.projecttypeForm.valid) {
      if (this.data) {
        this.gs
          .update(this.config.environment.endpoints.projecttype, this.data.projecttypeId, this.projecttypeForm.value)
          .subscribe({
            next: (res: any) => {
              if (res && res.code === 200) {
                this.alertService.show( 'Success','ProjectType  updated successfully');
                this._dialogRef.close(true);
              }else{
                this.alertService.show('Error','ProjectType  not updated ');
              }
            },
            error: (err: any) => {
              this.alertService.show( 'Error','ProjectType  not updated ');
            },
          });
      } else {
        this.gs.create(this.config.environment.endpoints.projecttype, this.projecttypeForm.value).subscribe({
          next: (res: any) => {
            if (res && res.code === 201) {
              this.alertService.show( 'Success','ProjectType  added successfully',);
              this._dialogRef.close(true);
            }else{
              this.alertService.show( 'Error','ProjectType  not added ',);
            }
            
          },
          error: (err: any) => {
            this.alertService.show( 'Error','ProjectType  not added ');
          },
        });
      }
    }
  }

}
