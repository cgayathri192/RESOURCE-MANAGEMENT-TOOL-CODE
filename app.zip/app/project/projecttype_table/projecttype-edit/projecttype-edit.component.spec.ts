import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProjecttypeEditComponent } from './projecttype-edit.component';

describe('ProjecttypeEditComponent', () => {
  let component: ProjecttypeEditComponent;
  let fixture: ComponentFixture<ProjecttypeEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProjecttypeEditComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ProjecttypeEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
