import { DatePipe } from '@angular/common';
import { Component, ViewChild, inject } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { BlankAllocationModel, BlankAllocationRes } from '@core/models/blankallocation';
import { DepartmentModel, DepartmentRes } from '@core/models/department';
import { Employee, EmployeeModel, EmployeeRes } from '@core/models/employee';
import { GradeRes } from '@core/models/grade';
import { Location, LocationRes } from '@core/models/location';
import { Mttenurity, MttenurityRes } from '@core/models/mttenurity';
import { Practice, PracticeModel, PracticeRes } from '@core/models/practice';
import { RoleRes, Roles } from '@core/models/role';
import { Grade, TitleModel, TitleRes } from '@core/models/title';
import { ConfigService } from '@core/services/config.service';
import { CoreService } from '@core/services/core.service';
import { GenericRepositoryService } from '@core/services/generic-repository.service';

@Component({
  selector: 'app-blank-allocation',
  templateUrl: './blank-allocation.component.html',
  styleUrls: ['./blank-allocation.component.scss']
})
export class BlankAllocationComponent {
  fixedColumns: Column[] = [
    {ColumnName: 'SNo',DisplayName: 'Sno',DefaultLoad: true},
    {ColumnName: 'ResourceName',DisplayName: 'ResourceName',DefaultLoad: true},
    {ColumnName: 'RoleId',DisplayName: 'Role',DefaultLoad: true},
    {ColumnName: 'PracticeId',DisplayName: 'Practice',DefaultLoad: true},
  ]
  allColumns : Column[] = [
    {ColumnName: 'EmployeeCompanyId',DisplayName: 'Associate CompanyId',DefaultLoad: false},
    {ColumnName: 'Email',DisplayName: 'Email',DefaultLoad: false},
    {ColumnName: 'DateOfBirth',DisplayName: 'Date of birth',DefaultLoad: false},
    {ColumnName: 'Gender',DisplayName: 'Gender',DefaultLoad: false},
    {ColumnName: 'DateOfJoining',DisplayName: 'Date of joining',DefaultLoad: false},
    {ColumnName: 'IsActive',DisplayName: 'Active',DefaultLoad: false},
    {ColumnName: 'DepartmentId',DisplayName: 'Department',DefaultLoad:true},
    {ColumnName: 'LeadershipTeam',DisplayName: 'Leadership Team',DefaultLoad: true},
    {ColumnName: 'GradeId',DisplayName: 'Grade',DefaultLoad: false},
    {ColumnName: 'TitleId',DisplayName: 'Title',DefaultLoad: false},
    {ColumnName: 'LocationId',DisplayName: 'Location',DefaultLoad: false},
    {ColumnName: 'ReportingManagerId',DisplayName: 'Reporting Manager',DefaultLoad: false},
    {ColumnName: 'MouriTechTenurityId',DisplayName: 'MOURI Tech Tenurity',DefaultLoad: false},
    {ColumnName: 'last_login',DisplayName: 'Last_Login',DefaultLoad: false},
    {ColumnName: 'ModifiedAt',DisplayName: 'Modified At',DefaultLoad: false},
    {ColumnName: 'ModifiedBy',DisplayName: 'Modified By',DefaultLoad: false},
    {ColumnName: 'CreatedAt',DisplayName: 'Created At',DefaultLoad: false}
  ];
  displayedColumns: string[] = [...this.fixedColumns.filter((col: Column) => col.DefaultLoad).map((column: Column) => column.ColumnName), ...this.allColumns.filter((col: Column) => col.DefaultLoad).map((column: Column) => column.ColumnName)];  
  dataSource: MatTableDataSource<BlankAllocationModel>;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  blank_list:BlankAllocationModel[]=[];
  sortOrder: 'asc' | 'desc' = 'asc';
  Practice= new FormControl('');
  Role = new FormControl('');
  Department=new FormControl('');
  LeadershipTeam=new FormControl('');
  Gender=new FormControl('');
  Grade=new FormControl('');
  Title = new FormControl('');
  IsActive=new FormControl('');
  Location = new FormControl('');
  MouriTechTenurity = new FormControl('');
  ReportingManager = new FormControl('');
  ModifiedBy = new FormControl('')
  allRolesSelected:boolean=true;
  allPracticesSelected:boolean=true;
  allDepartmentsSelected:boolean=true;
  allLeadersSelected:boolean=true;
  allLeaders: any[] = [];
  allGenderSelected:boolean=true;
  allMtGradeSelected:boolean=true;
  allTitlesSelected: boolean = true;
  allLocationsSelected: boolean = true;
  allReportingSelected: boolean = true;
  allMtTenuritySelected:boolean=true;
  allActivesSelected:boolean=true;
  last_login:any;
  RolesList:any;
  PracticeList:any;
  DepartmentList:any;
  LeadershipTeamList:any;
  GenderList:any;
  ActiveList:any;
  GradeList:any;
  TitleList: any;
  LocationList: any;
  ReportingManagerList: any;
  MouriTechTenurityList: any;
  IsActiveList: any;
  practiceService = inject(GenericRepositoryService<PracticeRes>);
  rolesService = inject(GenericRepositoryService<RoleRes>);
  departmentService=inject(GenericRepositoryService<DepartmentRes>);
  leaderService=inject(GenericRepositoryService<EmployeeRes>);
  genderService=inject(GenericRepositoryService<EmployeeRes>)
  activeService = inject(GenericRepositoryService<EmployeeRes>);
  gradeService = inject(GenericRepositoryService<GradeRes>);
  titleService = inject(GenericRepositoryService<TitleRes>);
  locationService = inject(GenericRepositoryService<LocationRes>);
  mtTenurityService = inject(GenericRepositoryService<MttenurityRes>);
  reportingservice=inject(GenericRepositoryService<EmployeeRes>)
  dateOfBirthRange = new FormGroup({
    start: new FormControl(null),
    end: new FormControl(null),
  });
  dateOfJoiningRange = new FormGroup({
    start: new FormControl(null),
    end: new FormControl(null),
  });
  ModifiedDateRange = new FormGroup({
    start: new FormControl(null),
    end: new FormControl(null),
  });
  CreatedDateRange = new FormGroup({
    start: new FormControl(null),
    end: new FormControl(null),
  });
  constructor(private _dialog: MatDialog,
    private  gs: GenericRepositoryService<BlankAllocationRes>,
    private config: ConfigService,
    private datepipe:DatePipe) {
      this.dataSource = new MatTableDataSource<BlankAllocationModel>();
     }
     ngOnInit(): void {
      this.getblankList();
      this.loadDropdowns();
      let controlFilters: any[] = [
        { control: this.Role, value: 'Role.RoleName'},
        {control:this.Practice,value:'Practice.PracticeName'},
        { control: this.Gender, value: 'Gender' },
        { control: this.Grade, value: 'Grade.GradeName' },
        { control: this.Department, value: 'Department.DepartmentName'},
        { control: this.Title, value: 'Title.TitleName' },
        { control: this.IsActive, value: 'IsActive' },
        { control: this.Location, value: 'Location.LocationName' },
        { control: this.LeadershipTeam, value: 'LeadershipTeam.ResourceName' },
        { control: this.ReportingManager,value:'ReportingManager.ResourceName'},
        { control: this.MouriTechTenurity, value: 'MouriTechTenurity.MouriTechTenurityGroup'},
        { control: this.ModifiedBy,value: 'ModifiedBy.ResourceName'}

      ]
      for (var controlfilter = 0; controlfilter < controlFilters.length; controlfilter++) {
        this.applyDynamicFilter(controlFilters[controlfilter].control, controlFilters[controlfilter].value);
      }
      this.dateOfBirthRange.valueChanges.subscribe((formValues: any) => {
        if (formValues.start && formValues.end) {
          this.dataSource = new MatTableDataSource(this.blank_list.filter((blank: any) => {
              let blankDOB = new Date(blank.DateOfBirth);
              let startDate = new Date(formValues.start);
              let endDate = new Date(formValues.end);
              endDate.setDate(endDate.getDate() + 1);
              return blankDOB >= startDate && blankDOB < endDate;
            })
          );
        } else {
          this.dataSource = new MatTableDataSource(this.blank_list);
          this.dataSource.paginator = this.paginator;
        }
      });
      this.dateOfJoiningRange.valueChanges.subscribe((formValues: any) => {
        if (formValues.start && formValues.end) {
          this.dataSource = new MatTableDataSource(this.blank_list.filter((blank: any) => {
              let blankDOJ = new Date(blank.DateOfJoining);
              let startDate = new Date(formValues.start);
              let endDate = new Date(formValues.end);
              endDate.setDate(endDate.getDate() + 1);
              return blankDOJ >= startDate && blankDOJ < endDate;
            })
          );
        } else {
          this.dataSource = new MatTableDataSource(this.blank_list);
          this.dataSource.paginator = this.paginator;
        }
      });
      this.ModifiedDateRange.valueChanges.subscribe((formValues: any) => {
        if (formValues.start && formValues.end) {
          this.dataSource = new MatTableDataSource(this.blank_list.filter((blank: any) => {
              let modDate = new Date(blank.ModifiedAt);
              let startDate = new Date(formValues.start);
              let endDate = new Date(formValues.end);
              endDate.setDate(endDate.getDate() + 1);
              return modDate >= startDate && modDate < endDate;
            })
          );
        } else {
          this.dataSource = new MatTableDataSource(this.blank_list);
          this.dataSource.paginator = this.paginator;
        }
      });
      this.CreatedDateRange.valueChanges.subscribe((formValues: any) => {
        if (formValues.start && formValues.end) {
          this.dataSource = new MatTableDataSource(this.blank_list.filter((blank: any) => {
              let creatDate = new Date(blank.CreatedAt);
              let startDate = new Date(formValues.start);
              let endDate = new Date(formValues.end);
              endDate.setDate(endDate.getDate() + 1);
              return creatDate >= startDate && creatDate < endDate;
            })
          );
        } else {
          this.dataSource = new MatTableDataSource(this.blank_list);
          this.dataSource.paginator = this.paginator;
        }
      });
      }
      
      getblankList(){
        this.gs.get(this.config.environment.endpoints.blankallocation).subscribe({
          next: (res : BlankAllocationRes) => {
          if (res && res.code == 200) {
            res.data.sort((a, b) => {
              return new Date(b.CreatedAt).getTime() - new Date(a.CreatedAt).getTime();
            });
            this.blank_list = res.data
            this.dataSource = new MatTableDataSource(this.blank_list);
            const sort = new MatSort();
            sort.active = 'CreatedAt';
            sort.direction = 'desc';
            this.dataSource.sort = this.sort;
            this.dataSource.paginator = this.paginator;
          }
          },
        });
      }
  toggleDisplayColumns(): void {
    if ((this.displayedColumns.length - this.fixedColumns.length) === this.allColumns.length) {
      this.displayedColumns = [...this.fixedColumns.map(column => column.ColumnName)];
    } else {
      this.displayedColumns = [...this.fixedColumns.map(column => column.ColumnName), ...this.allColumns.map(column => column.ColumnName)];
    }
  }
  applySort(type: any) {
    this.sortOrder = this.sortOrder === 'asc' ? 'desc' : 'asc';
    let valueA: any;
    let valueB: any;
    this.blank_list.sort((a, b) => {
      if (type === 'Role') {
        valueA = a?.Role?.RoleName;
        valueB = b?.Role?.RoleName;
      } else if (type === 'Practice') {
        valueA = a?.Practice?.PracticeName;
        valueB = b?.Practice?.PracticeName;
      } else if ( type === 'Department'){
        valueA = a?.Department?.DepartmentName;
        valueB = b?.Department?.DepartmentName;
      } else if ( type === 'Location'){
        valueA = a?.Location?.LocationName;
        valueB = b?.Location?.LocationName;
      } else if ( type === 'Title'){
        valueA = a?.Title?.TitleName;
        valueB = b?.Title?.TitleName;
      } else if ( type === 'Grade'){
        valueA = a?.Grade?.GradeName;
        valueB = b?.Grade?.GradeName;
      } else if( type === 'LeadershipTeam'){
        valueA = a?.LeadershipTeam?.ResourceName
        valueB = b?.LeadershipTeam?.ResourceName
      } else if ( type === 'ReportingManager'){
        valueA = a?.ReportingManager?.ResourceName
        valueB = b?.ReportingManager?.ResourceName
      } else if ( type === 'MouriTechTenurity'){
        valueA = a?.MouriTechTenurity?.MouriTechTenurityGroup
        valueB = b?.MouriTechTenurity?.MouriTechTenurityGroup
      }
      else if ( type === 'ModifiedBy'){
        valueA = a?.ModifiedBy?.ResourceName
        valueB = b?.ModifiedBy?.ResourceName
      }

      if (this.sortOrder === 'asc') {
        return valueA < valueB ? -1 : 1;
      } else {
        return valueA > valueB ? -1 : 1;
      }
    });
  }
  filterEmp() {
    this.IsActiveList = [...new Set(this.blank_list.map((res: any) => res.IsActive)),];
    this.GenderList = [...new Set(this.blank_list.map((res: any) => res.Gender)),];
    this.LeadershipTeamList = [...new Set(this.blank_list.map((res: any) => res.LeadershipTeam.ResourceName)),];
    this.ReportingManagerList = [...new Set(this.blank_list.map((res: any) => res.ReportingManager.ResourceName)),];

  }

  onColumnSelect(selectedColumns: string[]) {
    this.displayedColumns = [...this.fixedColumns.map(column => column.ColumnName), ...selectedColumns];
    if (selectedColumns.length !== this.allColumns.length) {
      this.displayedColumns = [...this.fixedColumns.map(column => column.ColumnName), ...selectedColumns];
    }
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value.trim().toLowerCase();;
    this.dataSource.filter = filterValue
    this.dataSource.filterPredicate = (data:BlankAllocationModel, filter:string)=> {
      return this.filterData(data,filter);
    };
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  
  applyDynamicFilter(control: FormControl, searchproperty: any) {
    if (control) {
      control.valueChanges.subscribe((res: any) => {
        if (res && res.length > 0) {
          this.dataSource = new MatTableDataSource(this.blank_list.filter((emp: any) => {
            const propertyValue = this.getNestedPropertyValue(emp, searchproperty);
            if (searchproperty === 'IsActive') {
              return res.includes(propertyValue ? 'Yes' : 'No');
            }

            return res.findIndex((r: any) => r === propertyValue) >= 0;
          }));
        }
        else {
          this.dataSource = new MatTableDataSource(this.blank_list);
        }
      })
    }
  }
  getNestedPropertyValue(object: any, propertyPath: string): any {
    return propertyPath.split('.').reduce((obj, prop) => obj && obj[prop], object);
  }
  loadDropdowns() {
    this.loadRoles();
    this.loadPractices();
    this.loadDepartments();
    this.loadActive();
    this.loadGrades();
    this.loadTitles();
    this.loadLocations();
    this.loadMttenurity();
    this.loadLeadership();
    this.loadGender();
    this.loadReportingManager();
  }
  loadRoles(): void {
    this.rolesService.get(this.config.environment.endpoints.role).subscribe({
      next: (roles: RoleRes) => {
        if (roles && roles.data.length > 0) {
          this.RolesList = roles.data.map((role: Roles) => role.RoleName);
        } else {
          this.RolesList = [];
        }
      },
    });
  }
  loadPractices(): void {
    this.practiceService.get(this.config.environment.endpoints.practice).subscribe({
        next: (practices: PracticeRes) => {
          if (practices && practices.data.length > 0) {
            this.PracticeList = practices.data.map((practice: PracticeModel) => practice.PracticeName);
          } else {
            this.PracticeList = [];
          }
        },
      });
  }
  loadDepartments(): void {
    this.departmentService.get(this.config.environment.endpoints.department).subscribe({
        next: (departments: DepartmentRes) => {
          if (departments && departments.data.length > 0) {
            this.DepartmentList = departments.data.map((department: DepartmentModel) => department.DepartmentName);
          } else {
            this.DepartmentList = [];
          }
        },
      });
  }
  loadLeadership():void {
    this.leaderService.get(this.config.environment.endpoints.employee).subscribe({
        next: (leaders: EmployeeRes) => {
          if (leaders && leaders.data.length > 0) {
            this.LeadershipTeamList = leaders.data.map((lead:EmployeeModel)=>lead.LeadershipTeam.ResourceName);
            const filterdata=this.LeadershipTeamList.filter((item:any,index:any)=>this.LeadershipTeamList.indexOf(item)===index)
            this.LeadershipTeamList=filterdata;
          } else {
            this.LeadershipTeamList = [];
          }
        },
      });
  }
  loadActive(): void {
    this.activeService.get(this.config.environment.endpoints.employee).subscribe({
        next: (actives: EmployeeRes) => {
          if (actives) {
            this.ActiveList = [...new Set(actives.data.map((emloyee: EmployeeModel) => emloyee.IsActive?"Yes":"No"))];
          } else {
            this.ActiveList = [];
          }
        },
      });
  }
  loadGender(): void {
    this.genderService.get(this.config.environment.endpoints.employee).subscribe({
      next: (gender: EmployeeRes) => {
        if (gender && gender.data.length > 0) {
          this.GenderList = gender.data.map((g:EmployeeModel)=>g.Gender);
          const filterdata=this.GenderList.filter((item:any,index:any)=>this.GenderList.indexOf(item)===index)
          this.GenderList=filterdata;
        } else {
          this.GenderList = [];
        }
      },
    });
    
  }
  loadReportingManager():void{
    this.reportingservice.get(this.config.environment.endpoints.employee).subscribe({
      next: (Reporting: EmployeeRes) => {
        if (Reporting && Reporting.data.length > 0) {
          this.ReportingManagerList = Reporting.data.map((r:EmployeeModel)=>r.ReportingManager.ResourceName);
          const filterdata=this.ReportingManagerList.filter((item:any,index:any)=>this.ReportingManagerList.indexOf(item)===index)
          this.ReportingManagerList=filterdata;
        } else {
          this.ReportingManagerList = [];
        }
      },
    });
  }
  
  loadGrades(): void {
    this.gradeService.get(this.config.environment.endpoints.grade).subscribe({
      next: (grades: GradeRes) => {
        if (grades && grades.data.length > 0) {
          this.GradeList = grades.data.map((grade: Grade) => grade.GradeName);
        } else {
          this.GradeList = [];
        }
      },
    });
  }
  loadTitles(): void {
    this.titleService.get(this.config.environment.endpoints.title).subscribe({
      next: (titles: TitleRes) => {
        if (titles && titles.data.length > 0) {
          this.TitleList = titles.data.map((title: TitleModel) => title.TitleName);
        } else {
          this.TitleList = [];
        }
      },
    });
  }
  loadLocations(): void {
    this.locationService.get(this.config.environment.endpoints.location).subscribe({
        next: (locations: LocationRes) => {
          if (locations && locations.data.length > 0) {
            this.LocationList = locations.data.map((location: Location) => location.LocationName);
          } else {
            this.LocationList = [];
          }
        },
      });
  }
  loadMttenurity(): void {
    this.mtTenurityService.get(this.config.environment.endpoints.mttenurity).subscribe({
        next: (tenurity: MttenurityRes) => {
          if (tenurity && tenurity.data.length > 0) {
            this.MouriTechTenurityList = tenurity.data.map((t: Mttenurity) => t.MouriTechTenurityGroup);
          } else {
            this.MouriTechTenurityList = [];
          }
        },
      });
  }
  filterData(data: any, filter: string): boolean {
    for (const key in data) {
      if (data.hasOwnProperty(key)) {
        let value = data[key]  ?? null;
        if(key == "ModifiedAt" || key == "CreatedAt"){
          value = this.datepipe.transform(data[key], 'dd MMM, yyyy') ?? null;
        }
        if (typeof value === 'object' && value !== null) {
          if (this.filterData(value, filter)) {
            return true;
          }
        } else {
          if (value !== null && value.toString().toLowerCase().includes(filter)) {
            return true;
          }
        }
      }
    }
    return false;
  }
  selectAllForRole(e: any) {
    this.allRolesSelected = !this.allRolesSelected;
    if (e.checked) {
      this.Role.setValue(this.RolesList.slice(0));
    } else {
      this.Role.setValue('');
    }
    this.dataSource.paginator = this.paginator;
  }
  selectAllForPractice(e: any) {
    this.allPracticesSelected = !this.allPracticesSelected;
    if (e.checked) {
      this.Practice.setValue(this.PracticeList.slice(0));
    } else {
      this.Practice.setValue('');
    }
    this.dataSource.paginator = this.paginator;
  }
  selectAllForDepartment(e: any) {
    this.allDepartmentsSelected = !this.allDepartmentsSelected;
    if (e.checked) {
      this.Department.setValue(this.DepartmentList.slice(0));
    } else {
      this.Department.setValue('');
    }
    this.dataSource.paginator = this.paginator;
  }
  selectAllForLeadershipTeam(e: any) {
    this.allLeadersSelected = !this.allLeadersSelected;
    if (e.checked) {
      this.LeadershipTeam.setValue(this.LeadershipTeamList.slice(0));
    } else {
      this.LeadershipTeam.setValue('');
    }
    this.dataSource.paginator = this.paginator;
  }

  selectAllForGender(e: any) {
    this.allGenderSelected = !this.allGenderSelected;
    if (e.checked) {
      this.Gender.setValue(this.GenderList.slice(0));
    } else {
      this.Gender.setValue('');
    }
    this.dataSource.paginator = this.paginator;
  }
  selectAllForMtGrade(e: any) {
    this.allMtGradeSelected = !this.allMtGradeSelected;
    if (e.checked) {
      this.Grade.setValue(this.GradeList.slice(0));
    } else {
      this.Grade.setValue('');
    }
    this.dataSource.paginator = this.paginator;
  }
  selectAllForTitle(e: any) {
    this.allTitlesSelected = !this.allTitlesSelected;
    if (e.checked) {
      this.Title.setValue(this.TitleList.slice(0));
    } else {
      this.Title.setValue('');
    }
    this.dataSource.paginator = this.paginator;
  }
  selectAllForLocation(e: any) {
    this.allLocationsSelected = !this.allLocationsSelected;
    if (e.checked) {
      this.Location.setValue(this.LocationList.slice(0));
    } else {
      this.Location.setValue('');
    }
    this.dataSource.paginator = this.paginator;
  }
  selectAllForActive(e: any) {
    this.allActivesSelected = !this.allActivesSelected;
    if (e.checked) {
      this.IsActive.setValue(this.ActiveList.slice(0));
    } else {
      this.IsActive.setValue('');
    }
    this.dataSource.paginator = this.paginator;
  }
  selectAllForReportingManager(e: any) {
    this.allReportingSelected = !this.allReportingSelected;
    if (e.checked) {
      this.ReportingManager.setValue(this.ReportingManagerList.slice(0));
    } else {
      this.ReportingManager.setValue('');
    }
    this.dataSource.paginator = this.paginator;
  }
  selectAllForMtTenurity(event: any) {
    this.allMtTenuritySelected = !this.allMtTenuritySelected;
    if (event.checked) {
      this.MouriTechTenurity.setValue(this.MouriTechTenurityList.slice(0));
    } else {
      this.MouriTechTenurity.setValue('');
    }
    this.dataSource.paginator = this.paginator;
  }
 
  checkIfAllSelected(formControl: FormControl, arrayList: []): boolean {
    if (formControl.value?.length) {
      return formControl.value.length === arrayList.length;
    } else {
      return false;
    }
  }
  clearDateOfBirthRange(): void {
    this.dateOfBirthRange.reset();
  }
  clearDateOfJoiningRange(): void {
    this.dateOfJoiningRange.reset();
  }
  clearModifiedDateRange():void{
    this.ModifiedDateRange.reset();
  }
  clearCreatedDateRange():void{
    this.CreatedDateRange.reset();
  }
}
export interface Column {
  ColumnName: string;
  DisplayName: string;
  DefaultLoad: boolean;
}
