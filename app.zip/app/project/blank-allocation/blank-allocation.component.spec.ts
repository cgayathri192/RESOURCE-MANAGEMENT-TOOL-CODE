import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BlankAllocationComponent } from './blank-allocation.component';

describe('BlankAllocationComponent', () => {
  let component: BlankAllocationComponent;
  let fixture: ComponentFixture<BlankAllocationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BlankAllocationComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BlankAllocationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
