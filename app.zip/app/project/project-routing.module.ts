import { NgModule, inject } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ProjectComponent } from './project/project.component';
import { ClientComponent } from './client_table/client/client.component';
import { AuthService } from '@core/services/auth.service';
import { ClientTypeComponent } from './client_table/client-type/client-type.component';
import { ProjectTypeComponent } from './projecttype_table/project-type/project-type.component';
import { ProjectDetailsComponent } from './project_table/project-details/project-details.component';
import { BillingStatusComponent } from './project_mapping_table/billing-status/billing-status.component';
import { ProjectMappingComponent } from './project_mapping_table/project-mapping/project-mapping.component';
import { EmployeeStatusComponent } from './employee-status/employee-status.component';
import { BlankAllocationComponent } from './blank-allocation/blank-allocation.component';

const routes: Routes = [{
  path: '', component: ProjectComponent,
  canActivate: [() => inject(AuthService).isLoggedIn()],
  children:[{
    path: 'client', component: ClientComponent
  },
  {
    path:'project-details',component:ProjectDetailsComponent,
    canActivate: [() => inject(AuthService).isAdmin()]
  },
  {
    path:'client-type',component:ClientTypeComponent,
    canActivate: [() => inject(AuthService).isAdmin()]
  },
  {
    path:'projecttype',component:ProjectTypeComponent,
    canActivate: [() => inject(AuthService).isAdmin()]
  },
  {
    path:'billingstatus',component:BillingStatusComponent,
    canActivate: [() => inject(AuthService).isAdmin()]
  },
  {
    path:'projectmapping',component:ProjectMappingComponent,
    canActivate: [() => inject(AuthService).isAdmin()]
  },
  {
    path:'employeestatus',component:EmployeeStatusComponent,
  }, {
    path:'blankallocation',component:BlankAllocationComponent,
    canActivate: [() => inject(AuthService).isAdmin()]
  }
]
}
]

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProjectRoutingModule { }
