import { Component, ViewChild } from '@angular/core';
import { DatePipe } from '@angular/common';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import {EmployeeStatusModel,EmployeeStatusRes,} from '@core/models/employeestatus';
import { AuthService } from '@core/services/auth.service';
import { ConfigService } from '@core/services/config.service';
import { GenericRepositoryService } from '@core/services/generic-repository.service';
import { Column } from '@home-module/skills_table/skills/skills.component';
import { HttpClient } from '@angular/common/http';
import { FormGroup, FormControl } from '@angular/forms';
import { MAT_DATE_FORMATS,DateAdapter } from '@angular/material/core';
import { AppDateAdapter, APP_DATE_FORMATS } from '@core/common/dateAdapter';

@Component({
  selector: 'app-employee-status',
  templateUrl: './employee-status.component.html',
  styleUrls: ['./employee-status.component.scss'],
  providers: [
    { provide: DateAdapter, useClass: AppDateAdapter },
    { provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS },
  ],
})
export class EmployeeStatusComponent {
  selectedDate!: Date;
  employees: any;
  fixedColumns: Column[] = [
    { ColumnName: 'SNo', DisplayName: 'Sno', DefaultLoad: true },
    { ColumnName: 'ResourceName',DisplayName: 'Resource Name',DefaultLoad: true,},
    { ColumnName: 'Project name', DisplayName: 'Project Name', DefaultLoad: true },
    { ColumnName: 'Effort percentage', DisplayName: 'Effort Percentage ', DefaultLoad: true },
  ];

  allColumns: Column[] = [
    { ColumnName: 'Billing status', DisplayName: 'Billing Status',DefaultLoad: true},
    { ColumnName: 'Is active', DisplayName: 'Is Active', DefaultLoad: false,},
    { ColumnName: 'Status', DisplayName: 'Status', DefaultLoad: false },
    { ColumnName: 'Start date', DisplayName: 'Start Date', DefaultLoad: true },
    { ColumnName: 'Shadow toemployee', DisplayName: 'Shadow to Associate', DefaultLoad: false,},
    { ColumnName: 'End date', DisplayName: 'End Date', DefaultLoad: true },
    { ColumnName: 'Modified by', DisplayName: 'Modified By', DefaultLoad: false },
    { ColumnName: 'Modified at', DisplayName: 'Modified At', DefaultLoad: false,},
    { ColumnName: 'Created at', DisplayName: 'Created At', DefaultLoad: false },
  ];
  displayedColumns: string[] = [
    ...this.fixedColumns
      .filter((col: Column) => col.DefaultLoad)
      .map((column: Column) => column.ColumnName),
    ...this.allColumns
      .filter((col: Column) => col.DefaultLoad)
      .map((column: Column) => column.ColumnName),
  ];

  empstatuslist: any;
  dataSource: MatTableDataSource<EmployeeStatusModel>;

  constructor(
    private gs: GenericRepositoryService<EmployeeStatusRes>,
    private http: HttpClient,
    private employeeService: AuthService,
    private config: ConfigService,
    private datepipe:DatePipe
  ) {
    this.dataSource = new MatTableDataSource<EmployeeStatusModel>();
  }

  @ViewChild(MatSort) sort!: MatSort;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
 
  ngOnInit(): void {
    this.selectedDate = new Date();
    this.getEmployeeByDate();
  }

  toggleDisplayColumns(): void {
    if (
      (this.displayedColumns.length - this.fixedColumns.length) ===
      this.allColumns.length
    ) {
      // On Select
      this.displayedColumns = [
        ...this.fixedColumns.map((column) => column.ColumnName),
      ]
    } else {
      // On Deselect
      this.displayedColumns = [...this.fixedColumns.map(column => column.ColumnName),
        ...this.allColumns.map(column => column.ColumnName)
      ]
    }
  }
  onColumnSelect(selectedColumns: string[]) {
    this.displayedColumns = [...this.fixedColumns.map(column=> column.ColumnName), ...selectedColumns];
    if (selectedColumns.length !== this.allColumns.length) {
      this.displayedColumns = [...this.fixedColumns.map(column => column.ColumnName), ...selectedColumns];
    }
  }
  private formatDate(date: Date): string {
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    return `${year}-${month}-${day}`;
  }
  getEmployeeByDate() {
    const formattedDate = this.formatDate(this.selectedDate);
    this.gs.get(this.config.environment.endpoints.empstatus+`?end_date=${formattedDate}`).subscribe((res: EmployeeStatusRes) => {
      if (res && res.code === 200) {
        res.data.sort((a, b) => {
          return new Date(b.CreatedAt).getTime() - new Date(a.CreatedAt).getTime();
        });
        if (res.data.length > 0) {
          this.empstatuslist = res.data;
          this.dataSource = new MatTableDataSource(res.data);
          this.dataSource.sort = this.sort;
          this.dataSource.paginator = this.paginator;
        } else {
          this.dataSource.data=[]
        }
      } else {
        this.dataSource.data=[]
      }
    });
  }
 
  
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value.trim().toLowerCase();;
    this.dataSource.filter = filterValue
    this.dataSource.filterPredicate = (data:EmployeeStatusModel, filter:string)=> {
      return this.filterData(data,filter);
    };
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  filterData(data: any, filter: string): boolean {
    for (const key in data) {
      if (data.hasOwnProperty(key)) {
        let value = data[key]  ?? null;
        if(key == "ModifiedAt" || key == "CreatedAt"){
          value = this.datepipe.transform(data[key], 'dd MMM, yyyy') ?? null;
        }
        if (typeof value === 'object' && value !== null) {
          if (this.filterData(value, filter)) {
            return true;
          }
        } else {
          if (value !== null && value.toString().toLowerCase().includes(filter)) {
            return true;
          }
        }
      }
    }
    return false;
  }
}
