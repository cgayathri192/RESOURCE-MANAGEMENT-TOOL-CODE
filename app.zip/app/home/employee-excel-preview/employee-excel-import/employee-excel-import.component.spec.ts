import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeExcelImportComponent } from './employee-excel-import.component';

describe('EmployeeExcelImportComponent', () => {
  let component: EmployeeExcelImportComponent;
  let fixture: ComponentFixture<EmployeeExcelImportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EmployeeExcelImportComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EmployeeExcelImportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
