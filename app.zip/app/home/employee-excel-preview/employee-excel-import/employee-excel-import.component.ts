import { DatePipe } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, inject, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, ValidatorFn, AbstractControl } from '@angular/forms';
import { DateAdapter, MAT_DATE_FORMATS } from '@angular/material/core';
import { MatTableDataSource } from '@angular/material/table';
import { AppDateAdapter, APP_DATE_FORMATS } from '@core/common/dateAdapter';
import { DepartmentModel, DepartmentRes } from '@core/models/department';
import { EmployeeModel, EmployeeRes } from '@core/models/employee';
import { EmployeeImportModel,EmployeeImportReq } from '@core/models/EmployeeImport';
import { GradeModel, GradeRes } from '@core/models/grade';
import { LocationModel, LocationRes } from '@core/models/location';
import { MttenurityModel, MttenurityRes } from '@core/models/mttenurity';
import { PracticeRes, PracticeModel } from '@core/models/practice';
import { RoleRes, RolesModel } from '@core/models/role';
import { TitleModel, TitleRes } from '@core/models/title';
import { AlertService } from '@core/services/alert.service';
import { ConfigService } from '@core/services/config.service';
import { CoreService } from '@core/services/core.service';
import { ExcelService } from '@core/services/excel.service';
import { GenericRepositoryService } from '@core/services/generic-repository.service';

@Component({
  selector: 'app-employee-excel-import',
  templateUrl: './employee-excel-import.component.html',
  styleUrls: ['./employee-excel-import.component.scss'],
  providers: [
    { provide: DateAdapter, useClass: AppDateAdapter },
    { provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS },
  ]
})
export class EmployeeExcelImportComponent implements OnInit {
  practiceService = inject(GenericRepositoryService<PracticeRes>);
  leaderService = inject(GenericRepositoryService<EmployeeRes>)
  reportingService = inject(GenericRepositoryService<EmployeeRes>)
  departmentService = inject(GenericRepositoryService<DepartmentRes>);
  locationService = inject(GenericRepositoryService<LocationRes>);
  rolesService = inject(GenericRepositoryService<RoleRes>);
  titleService = inject(GenericRepositoryService<TitleRes>);
  mtTenurityService = inject(GenericRepositoryService<MttenurityModel>);
  gradeService = inject(GenericRepositoryService<GradeModel>);
  displayedColumns: string[] = ['EmployeeId', 'ResourceName', 'Email', 'DateOfBirth', 'Gender', 'Role', 'Practice','Department', 'Grade', 'Title','LeaderShipTeam', 'ReportingManager', 'Location','DateOfJoining', 'MouriTechTenurity','actions'];
  dataSource = new MatTableDataSource<EmployeeImportModel>();
  editRowId: number | undefined;
  dataForm: FormGroup;
  validationMessage! : string;
  hide: boolean = true;
  genders = [
    { value: 'Male', viewValue: 'Male' },
    { value: 'Female', viewValue: 'Female' },
  ];
  PracticeList: PracticeModel[] = [];
  ReportingList: EmployeeModel[] = [];
  LeadershipTeamList: EmployeeModel[] = [];
  DepartmentList: DepartmentModel[] = [];
  departmentListforDropdown: DepartmentModel[]=[];
  titleListforDropdown: TitleModel[]=[];
  TitleList: TitleModel[] = [];
  LocationList: LocationModel[] = [];
  RolesList: RolesModel[] = [];
  MtTenurityList: MttenurityModel[] = [];
  GradeList: GradeModel[] = [];
  constructor(private formBuilder: FormBuilder, private http: HttpClient, private excel: ExcelService, private config: ConfigService, private datepipe: DatePipe,
    private gs: GenericRepositoryService<EmployeeImportReq[]>, private alertService: AlertService) {
    this.loadDropdowns();
    this.dataForm = this.formBuilder.group({
      EmployeeId: ['', Validators.required],
      ResourceName: ['', Validators.required],
      Email: ['', Validators.required],
      DateOfBirth: ['', Validators.required],
      Gender: ['', Validators.required],
      DateOfJoining: ['', Validators.required],
      PracticeId: ['', Validators.required],
      LeaderShipTeamId: ['', { validators: [autocompleteObjectValidator(), Validators.required] }],
      ReportingManager: ['', { validators: [autocompleteObjectValidator(), Validators.required] }],
      LocationId: ['', Validators.required],
      GradeId: ['', Validators.required],
      TitleId: ['',{ validators: [this.titleValidator(), Validators.required] }],
      RoleId: ['', Validators.required],
      DepartmentId: ['', { validators: [this.departmentValidator(), Validators.required] }],
      MouriTechTenurityId: ['', Validators.required]
    });
  }
  ngOnInit(): void {
    this.loadTenurity();
  }
  loadTenurity() {
    this.dataForm.get('DateOfJoining')?.valueChanges.subscribe((DateOfJoining: string) => {
      if (DateOfJoining && this.MtTenurityList) {
        this.calculateTenure(DateOfJoining);
      }
    });
  }
  calculateTenure(dateOfJoining: string) {
    if (dateOfJoining) {
      const now = new Date();
      const joinDate = new Date(dateOfJoining);
      const diffInMilliseconds = Math.abs(now.getTime() - joinDate.getTime());

      const years = Math.floor(diffInMilliseconds / (1000 * 60 * 60 * 24 * 365));

      for (const range of this.MtTenurityList) {
        const rangeValues = range.MouriTechTenurityGroup.split('-');
        const lowerBound = parseInt(rangeValues[0], 10);
        const upperBound = parseInt(rangeValues[1], 10);

        if (years >= lowerBound && (years < upperBound || !upperBound)) {
          this.dataForm.controls['MouriTechTenurityId'].setValue(range.Id)
          break;
        }
      }
    } else {
      this.dataForm.controls['MouriTechTenurityId'].setValue(null);
    }
  }
  bindTenure(employees: EmployeeImportModel[]): EmployeeImportModel[] {
    if (employees && employees.length > 0) {
      employees.forEach((employee: EmployeeImportModel) => {
        if (employee['Date Of Joining']) {
          const now = new Date();
          const joinDate = new Date(employee['Date Of Joining']);
          const diffInMilliseconds = Math.abs(now.getTime() - joinDate.getTime());

          const years = Math.floor(diffInMilliseconds / (1000 * 60 * 60 * 24 * 365));

          for (const range of this.MtTenurityList) {
            const rangeValues = range.MouriTechTenurityGroup.split('-');
            const lowerBound = parseInt(rangeValues[0], 10);
            const upperBound = parseInt(rangeValues[1], 10);

            if (years >= lowerBound && (years < upperBound || !upperBound)) {
              employee['MOURITECH Tenurity'] = range;
              break;
            }
          }
        } else {
          employee['MOURITECH Tenurity'] = null;
        }
      });
    }
    return employees;
  }
  loadDropdowns() {
    this.loadPractice();
    this.loadRoles();
    this.loadDepartment();
    this.loadTitle();
    this.loadLocation();
    this.loadMtTenurity();
    this.loadGrade();
    this.loadLeadership();
    this.loadReporting();
  }
  startEdit(rowId: number): void {
    this.editRowId = rowId;
    const row = this.dataSource.data.find(data => data['Employee Id'] === rowId);
    if (row) {
      this.dataForm.patchValue({
        EmployeeId: row['Employee Id'],
        ResourceName: row['Resource Name'],
        Email: row.Email,
        DateOfBirth: new Date(row['Date Of Birth']),
        Gender: row.Gender,
        DateOfJoining: new Date(row['Date Of Joining']),
        PracticeId: row?.Practice?.Id,
        LeaderShipTeamId: row['LeaderShip Team'],
        ReportingManager: row['Reporting Manager'],
        LocationId: row.Location?.Id,
        GradeId: row.Grade?.Id,
        TitleId: row.Title?.Id,
        RoleId: row?.Role?.Id,
        DepartmentId: row?.Department?.Id,
        MouriTechTenurityId: row['MOURITECH Tenurity']?.Id
      });
    }
  }

  cancelEdit(): void {
    this.editRowId = undefined;
    this.dataForm.reset();
  }
  deleteRow(rowId: number): void {
    const index = this.dataSource.data.findIndex(data => data['Employee Id'] === rowId);
    if (index !== -1) {
      const data = this.dataSource.data;
      data.splice(index, 1);
      this.dataSource.data = data;
    }
  }
  saveEdit(rowId: number): void {
    if (this.dataForm.invalid) {
      console.log(this.dataForm)
      return;
    }
    const row = this.dataSource.data.find(data => data['Employee Id'] === rowId);
    if (row) {
      console.log(row)
      row['Employee Id'] = this.dataForm.value.EmployeeId;
      row['Resource Name'] = this.dataForm.value.ResourceName;
      row.Email = this.dataForm.value.Email;
      row['Date Of Birth'] = this.dataForm.value.DateOfBirth,
      row.Gender = this.dataForm.value.Gender,
      row['Date Of Joining'] = this.dataForm.value.DateOfJoining,
      row.Practice = this.PracticeList.filter((m: PracticeModel) => m.Id == this.dataForm.value.PracticeId)[0];
      row['LeaderShip Team'] = this.LeadershipTeamList.filter((m: EmployeeModel) => m.Id == this.dataForm.value.LeaderShipTeamId?.Id)[0];
      row['Reporting Manager'] = this.ReportingList.filter((m: EmployeeModel) => m.Id == this.dataForm.value.ReportingManager?.Id)[0];
      row.Location = this.LocationList.filter((m: LocationModel) => m.Id == this.dataForm.value.LocationId)[0];
      row.Grade = this.GradeList.filter((m: GradeModel) => m.Id == this.dataForm.value.GradeId)[0];
      row.Title = this.titleListforDropdown.filter((m: TitleModel) => m.Id == this.dataForm.value.TitleId)[0];
      row.Role = this.RolesList.filter((m: RolesModel) => m.Id == this.dataForm.value.RoleId)[0];
      row.Department = this.departmentListforDropdown.filter((m: DepartmentModel) => m.Id == this.dataForm.value.DepartmentId)[0];
      row['MOURITECH Tenurity'] = this.MtTenurityList.filter((m: MttenurityModel) => m.Id == this.dataForm.value.MouriTechTenurityId)[0];
    }
    this.cancelEdit();
  }
  downloadExcelFile() {
    this.excel.downloadExcelTemplate(this.config.environment.endpoints.employeeExcelTemplate)
      .subscribe((response: Blob) => {
        const url = window.URL.createObjectURL(response);
        const link = document.createElement('a');
        link.href = url;
        link.download = 'AssociateExcelTemplate.xlsx';
        link.click();
        window.URL.revokeObjectURL(url);
      });
  }
  selectedFile: File | null = null;

  onFileSelected(event: any) {
    this.selectedFile = event.target.files[0];
    this.validationMessage = "";
  }

  sendExcelFile() {
    if (!this.selectedFile) {
      this.validationMessage = 'Please choose a file to upload.';
      console.error('No file selected');
      return;
    }
this.validationMessage = "";

    const formData = new FormData();
    formData.append('excel_file', this.selectedFile, this.selectedFile.name);

    this.excel.UploadExcelTemplate(this.config.environment.endpoints.employeeExcelTemplateResponse, formData).subscribe({
      next: (response) => {
        let employees: EmployeeImportModel[] = this.bindTenure(response)
        this.dataSource = new MatTableDataSource<EmployeeImportModel>(employees);
      },
      error: (error) => {
        console.error('Error sending file', error);
      }
    });
  }
  loadPractice() {
    this.practiceService
      .get(this.config.environment.endpoints.practice)
      .subscribe({
        next: (res: PracticeRes) => {
          if (res && res.data) {
            this.PracticeList = res.data;
          } else {
            this.PracticeList = [];
          }
        },
      });
  }
  loadReporting() {
    this.reportingService
      .get(this.config.environment.endpoints.employee)
      .subscribe({
        next: (res: EmployeeRes) => {
          if (res && res.data) {
            this.ReportingList = res.data;
          } else {
            this.ReportingList = [];
          }
        },
      });
  }
  loadLeadership() {
    this.leaderService
      .get(this.config.environment.endpoints.employee)
      .subscribe({
        next: (res: EmployeeRes) => {
          if (res && res.data) {
            this.LeadershipTeamList = res.data;
          } else {
            this.LeadershipTeamList = [];
          }
        },
      });
  }

  loadDepartment() {
    this.departmentService
      .get(this.config.environment.endpoints.department)
      .subscribe({
        next: (res: DepartmentRes) => {
          if (res && res.data) {
            this.DepartmentList = res.data;
            this.departmentListforDropdown= res.data;
          } else {
            this.DepartmentList = [];
            this.departmentListforDropdown= [];
          }
        },
      });
  }
  loadTitle() {
    this.titleService.get(this.config.environment.endpoints.title).subscribe({
      next: (res: TitleRes) => {
        if (res && res.data) {
          this.TitleList = res.data;
          this.titleListforDropdown= res.data;
        } else {
          this.TitleList = [];
          this.titleListforDropdown= [];
        }
      },
    });
  }
  loadLocation() {
    this.locationService
      .get(this.config.environment.endpoints.location)
      .subscribe({
        next: (res: LocationRes) => {
          if (res && res.data) {
            this.LocationList = res.data;
          } else {
            this.LocationList = [];
          }
        },
      });
  }
  loadRoles() {
    this.rolesService.get(this.config.environment.endpoints.role).subscribe({
      next: (res: RoleRes) => {
        if (res && res.data) {
          this.RolesList = res.data;
        } else {
          this.RolesList = [];
        }
      },
    });
  }
  loadMtTenurity() {
    this.mtTenurityService
      .get(this.config.environment.endpoints.mttenurity)
      .subscribe({
        next: (res: MttenurityRes) => {
          if (res && res.data) {
            this.MtTenurityList = res.data;
          } else {
            this.MtTenurityList = [];
          }
        },
      });
  }
  loadGrade() {
    this.gradeService.get(this.config.environment.endpoints.grade).subscribe({
      next: (res: GradeRes) => {
        if (res && res.data) {
          this.GradeList = res.data;
        } else {
          this.GradeList = [];
        }
      },
    });
  }
  displayFn(emp: EmployeeModel): string {
    return emp && emp.ResourceName ? emp.ResourceName : '';
  }
  parseDate(dateString: string): Date | null {
    return new Date(dateString) || null;
  }
formatDate(dateString: string): Date {
    const parts = dateString.split('-');
    const day = parseInt(parts[0], 10);
    const month = parseInt(parts[1], 10);
    const year = parseInt(parts[2], 10);
    return new Date(year, month - 1, day);
  }
  get TitleId() {
    return this.dataForm.get('TitleId');
  }
  get GradeId() {
    return this.dataForm.get('GradeId');
  }
  get DepartmentId() {
    return this.dataForm.get('DepartmentId');
  }
  onDepartmentSelectionChange(){
    this.loadEmployeeTitles();
  }
  onGradeSelectionChange(){
    this.loadEmployeeTitles();
  }
  loadEmployeeTitles(): void {
    if (this.titleListforDropdown) {
      let titles: TitleModel[] = this.titleListforDropdown.filter((t: TitleModel) => t.Grade.Id == this.GradeId?.value);
      if (titles && titles.length == 1) {
        this.TitleId?.setValue(titles[0].Id)
      }
      else if (titles && titles.length > 1) {
        titles = this.titleListforDropdown.filter((t: TitleModel) => t.Grade.Id == this.GradeId?.value && t.Department.Id == this.DepartmentId?.value);
        this.TitleId?.setValue(titles[0]?.Id)
      }
      else {
        this.TitleId?.setValue(null);
      }
    }
    else {
      this.TitleId?.setValue(null);
    }
  }
  onSubmit(){

      let employees:EmployeeImportModel[]= this.dataSource.data;
      let employeeslist: EmployeeImportReq[]=[];
      employees.forEach((employee:EmployeeImportModel)=>{
        let employeeObj: EmployeeImportReq={
          EmployeeCompanyId: employee['Employee Id'],
          ResourceName: employee['Resource Name'],
          Email: employee.Email,
          DateOfBirth: this.datepipe.transform(employee['Date Of Birth'], 'yyyy-MM-dd')?.toString() ?? '',
          Gender: employee.Gender,
          RoleId: employee?.Role?.Id.toString(),
          TitleId: employee.Title?.Id.toString(),
          DateOfJoining: this.datepipe.transform(employee['Date Of Joining'], 'yyyy-MM-dd')?.toString() ?? '',
          LocationId: employee.Location?.Id.toString(),
          PracticeId: employee.Practice?.Id.toString(),
          DepartmentId: employee.Department?.Id?.toString(),
          ReportingManagerId: employee['Reporting Manager']?.Id,
          LeadershipTeamId: employee['LeaderShip Team']?.Id,
          MouriTechTenurityId: employee['MOURITECH Tenurity']?.Id.toString(),
          GradeId: employee.Grade?.Id.toString()
        }
        employeeslist.push(employeeObj);
      });
       if(employeeslist && employeeslist.length >0){
        this.gs.create(this.config.environment.endpoints.employeeExcelInsert,employeeslist)
        .subscribe({
          next: (res: any) => {
            if (res && res.code === 201) {
              this.alertService.show('Success','Associates added successfully!');
            }else{
              this.alertService.show('Error','Associates Not added!');
            }
          },
          error: (err: any) => {
            this.alertService.show('Error','Associates Not added!');
          },
        });
       }
  }
  onPracticeOptionChange(event: any) {
    this.DepartmentList = this.departmentListforDropdown.filter(
      (department) => department.Practice.Id == event.value
    );
    this.dataForm.get('DepartmentId')?.setValue(null);
  }
  departmentValidator(): ValidatorFn {
    return (control: AbstractControl): { [key: string]: any } | null => {
      let department: DepartmentModel= this.departmentListforDropdown?.filter((dept: DepartmentModel)=> dept.Id == control.value)[0];
      if(department?.Practice?.Id !== this.dataForm?.get('PracticeId')?.value){
        if(control.value){
        return { 'invalidDepartment': true }
      }
      else{
        return { 'required': true }
      }
      }
      return null;
    }
  }
  titleValidator(): ValidatorFn {
    return (control: AbstractControl): { [key: string]: any } | null => {
      let titles: TitleModel[] = this.titleListforDropdown.filter((t: TitleModel) => t.Grade.Id == this.GradeId?.value);
      if (titles && titles.length == 1) {
        if(control.value && control.value != titles[0]?.Id){
          return { 'invalidTitle': true }
        }
        else if(!control.value){
          return { 'required': true }
        }
      }
      else if (titles && titles.length > 1) {
        titles = this.titleListforDropdown.filter((t: TitleModel) => t.Grade.Id == this.GradeId?.value && t.Department.Id == this.DepartmentId?.value);
        if(control.value && control.value != titles[0]?.Id){
          return { 'invalidTitle': true }
        }
        else if(!control.value){
          return { 'required': true }
        }
      }
      return null;
    }
  }
}

function autocompleteObjectValidator(): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } | null => {
    if (typeof control.value === 'string') {
      return { 'invalidAutocompleteObject': { value: control.value } }
    }
    return null;
  }
  
}

