import { DatePipe } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, inject } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidatorFn, Validators } from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
import { CompetencyModel, CompetencyRes } from '@core/models/competency';
import { CompetencylevelModel, CompetencylevelRes } from '@core/models/competencylevel';
import { CompetencyTypeModel, CompetencyTypeRes } from '@core/models/competencytype';
import { SkillImportModel, SkillImportReq } from '@core/models/skillimport';
import { ConfigService } from '@core/services/config.service';
import { ExcelService } from '@core/services/excel.service';
import { AlertService } from '@core/services/alert.service';
import { GenericRepositoryService } from '@core/services/generic-repository.service';
import { Competency, SkillModel, SkillRes } from '@core/models/skill';

@Component({
  selector: 'app-skill-excel-preview',
  templateUrl: './skill-excel-preview.component.html',
  styleUrls: ['./skill-excel-preview.component.scss']
})
export class SkillExcelPreviewComponent {
  dataSource = new MatTableDataSource<SkillImportModel>();
  dataForm: FormGroup;
  primaryskills = [
    { value: 'Yes', viewValue: 'Yes' },
    { value: 'No', viewValue: 'No' },
  ];
  editRowId: number | undefined;
  PrimarySkillList:SkillImportModel[]=[];
  validationMessage!: string;
  CompetencyLevelList:CompetencylevelModel[]=[];
  CompetencyTypeList:CompetencyTypeModel[]=[];
  CompetencyList:CompetencyModel[]=[];
  competencyListforDropdown: CompetencyModel[]= [];
  competencyService = inject(GenericRepositoryService<CompetencyRes>);
  competencyTypeService = inject(GenericRepositoryService<CompetencyTypeRes>)
  competencyLevelService = inject(GenericRepositoryService<CompetencylevelRes>)
  primaryService = inject(GenericRepositoryService<SkillRes>)
  constructor(private formBuilder: FormBuilder, private http: HttpClient, private excel: ExcelService, private config: ConfigService, private alertService: AlertService, private datepipe: DatePipe,  private gs: GenericRepositoryService<SkillImportReq[]>) {
    this.loadDropdowns()
    this.dataForm = this.formBuilder.group({
      EmployeeId: ['', Validators.required],
      PrimarySkill:['',Validators.required],
      SkillVersion:['',Validators.required],
      Competency:['',{ validators: [this.competencyValidator(), Validators.required] }],
      CompetencyLevel:['',Validators.required],
      CompetencyType:['',Validators.required]
    });
  }
  loadDropdowns() {
    this.loadCompetency()
    this.loadCompetencyType()
    this.loadCompetencyLevel()
  }
  displayedColumns: string[] = ['EmployeeId','CompetencyType','Competency','CompetencyLevel','PrimarySkill','SkillVersion','actions'];
  downloadExcelFile() {
    this.excel.downloadExcelTemplate(this.config.environment.endpoints.skillExcelTemplate)
      .subscribe((response: Blob) => {
        const url = window.URL.createObjectURL(response);
        const link = document.createElement('a');
        link.href = url;
        link.download = 'SkillExcelTemplate.xlsx';
        link.click();
        window.URL.revokeObjectURL(url);
      });
  }
  selectedFile: File | null = null;
  onFileSelected(event: any) {
    this.selectedFile = event.target.files[0];
    this.validationMessage = '';
  }
  sendExcelFile() {
    if (!this.selectedFile) {
      this.validationMessage = 'Please choose a file to upload.';
      console.error('No file selected');
      return;
    }
    this.validationMessage = '';
  
    const url = '/skillimport';
    const formData = new FormData();
    formData.append('skill_excel', this.selectedFile, this.selectedFile.name);

    this.excel.UploadExcelTemplate(this.config.environment.endpoints.skillExcelTemplateResponse,formData).subscribe({
      next: (response) => {
        this.dataSource = new MatTableDataSource<SkillImportModel>(response);
      },
      error: (error) => {
        console.error('Error sending file', error);
      }
    });
  }
  startEdit(rowEmployeeId: number): void {
    this.editRowId = rowEmployeeId;
    const row = this.dataSource.data.find(data => data['Employee Id'] === rowEmployeeId);
    if (row) {
      this.dataForm.patchValue({
      EmployeeId: row['Employee Id'],
      Competency:row.Competency?.Id,
      PrimarySkill : row['Primary Skill'],
      SkillVersion : row['Skill Version'],
      CompetencyLevel : row['Competency Level']?.Id,
      CompetencyType : row['Competency Type']?.Id,
      }); 
    }
  }
  cancelEdit(): void {
    this.editRowId = undefined;
    this.dataForm.reset();
  }
  deleteRow(rowEmployeeId: number): void {
    const index = this.dataSource.data.findIndex(data => data.Id === rowEmployeeId);
    if (index !== -1) {
      const data = this.dataSource.data;
      data.splice(index, 1);
      this.dataSource.data = data;
    }
  }
  saveEdit(rowEmployeeId: number): void {
    if (this.dataForm.invalid) {
      
      return;
    }
    const row = this.dataSource.data.find(data => data['Employee Id'] === rowEmployeeId);
    if (row) {
      row['Employee Id'] = this.dataForm.value.EmployeeId;
      row['Primary Skill'] = this.dataForm.value.PrimarySkill;
      row['Skill Version'] = this.dataForm.value.SkillVersion;
      row['Competency Level'] =  this.CompetencyLevelList.filter(m=>m.Id == this.dataForm.value.CompetencyLevel)[0];
      row['Competency Type'] = this.CompetencyTypeList.filter((m:CompetencyTypeModel)=>m.Id==this.dataForm.value.CompetencyType)[0];
      row.Competency= this.competencyListforDropdown.filter((m:CompetencyModel)=> m.Id== this.dataForm.value.Competency)[0];
    }
    this.cancelEdit();
  }
  loadCompetency() {
    this.competencyService.get(this.config.environment.endpoints.competency)
      .subscribe({
        next: (res: CompetencyRes) => {
          if (res && res.data) {
            this.CompetencyList = res.data;
            this.competencyListforDropdown= res.data;
          } else {
            this.CompetencyList = [];
            this.competencyListforDropdown=[];
          }
        },
      });
  }
  onCompetencyTypeChange(event: any) {
    this.CompetencyList = this.competencyListforDropdown.filter(
      (c) => c.CompetencyType.Id == event.value
    );
    this.dataForm.get('Competency')?.setValue(null);
  }
  loadCompetencyLevel(){
    this.competencyLevelService.get(this.config.environment.endpoints.competencylevel)
    .subscribe({
      next: (res: CompetencylevelRes) => {
        if (res && res.data) {
          this.CompetencyLevelList = res.data;
        } else {
          this.CompetencyLevelList = [];
        }
      },
    });
  }
  loadCompetencyType(){
    this.competencyTypeService.get(this.config.environment.endpoints.competencytype)
    .subscribe({
      next: (res: CompetencyTypeRes) => {
        if (res && res.data) {
          this.CompetencyTypeList = res.data;
        } else {
          this.CompetencyTypeList = [];
        }
      },
    });
  }
  onSubmit(){
    let skills:SkillImportModel[]= this.dataSource.data;
    let skillslist: SkillImportReq[]=[];
    skills.forEach((skill:SkillImportModel)=>{
      let skillObj: SkillImportReq= {
        EmployeeId:skill['Employee Id'],
        Primary: skill['Primary Skill'],
        SkillVersion: skill['Skill Version'],
        CompetencyId: skill.Competency?.Id.toString(),
        CompetencyLevelId:skill['Competency Level']?.Id?.toString(),
        CompetencyTypeId:skill['Competency Type']?.Id?.toString()
      }
      skillslist.push(skillObj);
    });
     if(skillslist && skillslist.length >0){
      this.gs.create(this.config.environment.endpoints.skillExcelInsert,skillslist)
      .subscribe({
        next: (res: any) => {
          if (res && res.code === 201) {
            this.alertService.show('Success','Skills added!');
          }else{
            this.alertService.show('Error','Skills Not added!');
          }
        },
        error: (err: any) => {
          this.alertService.show('Error','Skills Not added!');
        },
      });
     }
     
}
competencyValidator(): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } | null => {
    let competency: CompetencyModel= this.competencyListforDropdown?.filter((c: CompetencyModel)=> c.Id == control.value)[0];
    if(competency?.CompetencyType?.Id !== this.dataForm?.get('CompetencyType')?.value){
      if(control.value){
      return { 'invalidCompetency': true }
    }
    else{
      return { 'required': true }
    }
    }
    return null;
  }
}
}
