import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SkillExcelPreviewComponent } from './skill-excel-preview.component';

describe('SkillExcelPreviewComponent', () => {
  let component: SkillExcelPreviewComponent;
  let fixture: ComponentFixture<SkillExcelPreviewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SkillExcelPreviewComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SkillExcelPreviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
