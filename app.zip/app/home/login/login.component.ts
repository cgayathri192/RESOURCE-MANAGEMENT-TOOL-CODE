import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '@core/services/auth.service';
import {
  FormBuilder,
  FormGroup,
  Validators
} from '@angular/forms';
import { Response } from '@core/models/response';
import { Tokens } from '@core/models/tokens';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  errorMessage: string | undefined;
  submitted : boolean = false;
  hide: boolean= true;
  public showPassword: boolean= false;
  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {
    this.loginForm = this.fb.group({
      username: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required,Validators.minLength(6)]],
    });
  }

  ngOnInit(): void {
    if(this.authService.isLoggedIn()){
      this.router.navigate(['/']);
    }
  }

  onSubmit() {
    this.submitted = true;
    if (this.loginForm.invalid) {
      return;
    }
    this.login(this.username?.value,this.password?.value)
  }
  login(email: string, password: string) {
    this.authService.login(email, password)
      .subscribe({
        next:(res: Response<Tokens>)=> {
          if(res && res.code==201){
            this.router.navigate(['/']);
          }
          else if(res && res.code==406){
            this.errorMessage = 'Invalid username or password';
          }
        },
        error:(error) => {
          this.errorMessage = 'Invalid username or password';
        }
  });
  }
  togglePasswordVisibility(){
    this.showPassword=!this.showPassword
  
  }
  //validators
  get username(){
    return this.loginForm.get('username');
  }
  get password(){
    return this.loginForm.get('password');
  }
}
