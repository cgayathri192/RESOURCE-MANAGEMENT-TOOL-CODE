import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { HomeRoutingModule } from './home-routing.module';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { HeaderComponent } from './layout/header/header.component';
import { SidenavComponent } from './layout/sidenav/sidenav.component';
import { SharedModule } from '@shared/shared.module';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { MatTableModule } from '@angular/material/table';
import { MatDialogModule } from '@angular/material/dialog';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { SkillsComponent } from './skills_table/skills/skills.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { RoleDetailsComponent } from './roles/role-details/role-details.component';
import { RoleEditComponent } from './roles/role-edit/role-edit.component';
import { TitleDetailsComponent } from './title/title-details/title-details.component';
import { TitleEditComponent } from './title/title-edit/title-edit.component';
import { LocationEditComponent } from './locations/location-edit/location-edit.component';
import { LocationDetailsComponent } from './locations/location-details/location-details.component';
import { PracticeDetailsComponent } from './practice/practice-details/practice-details.component';
import { PracticeEditComponent } from './practice/practice-edit/practice-edit.component';
import { DepartmentDetailsComponent } from './departments/department-details/department-details.component';
import { DepartmentEditComponent } from './departments/department-edit/department-edit.component';
import { CompetencyComponent } from './competency_table/competency/competency.component';
import { CompetencyTypeComponent } from './competency_table/competency-type/competency-type.component';
import { CompetencyEditComponent } from './competency_table/competency-edit/competency-edit.component';
import { CompetencyLevelEditComponent } from './competency_table/competency-level/competency-level-edit/competency-level-edit.component';
import { CompetencyLevelComponent } from './competency_table/competency-level/competency-level.component';
import { CompetencyTypeEditComponent } from './competency_table/competency-type/competency-type-edit/competency-type-edit.component';
import { EmployeeDetailsComponent } from './employee/employee-details/employee-details.component';
import { EmployeeEditComponent } from './employee/employee-edit/employee-edit.component';
import { LoaderComponent } from './layout/loader/loader.component';
import { PassportComponent } from './employee/passport/passport.component';
import { VisatypeComponent } from './employee/visatype/visatype.component';
import { VisatypeEditComponent } from './employee/visatype-edit/visatype-edit.component';
import { ProfileComponent } from './profile/profile.component';
import { GradeComponent } from './grade/grade.component';
import { GradeEditComponent } from './grade-edit/grade-edit.component';
import {MatGridListModule} from '@angular/material/grid-list';
import {MatTabsModule} from '@angular/material/tabs';
import { DashboardComponent } from './dashboard/dashboard.component';
import { MatInputModule } from '@angular/material/input';
import { EmployeeViewDetailsComponent } from './employee/employee-view-details/employee-view-details.component';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { EmployeeRelieveComponent } from './employee/employee-relieve/employee-relieve.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { OrgChartComponent } from './organization/org-chart/org-chart.component';
import { OrganizationChartComponent } from './organization/organization-chart/organization-chart.component';
import { ProfileSkillEditComponent } from './profile/profile-skill-edit/profile-skill-edit.component';
import { EmployeeExcelImportComponent } from './employee-excel-preview/employee-excel-import/employee-excel-import.component';
import { SkillExcelPreviewComponent } from './employee-excel-preview/skill-excel/skill-excel-preview/skill-excel-preview.component';
import { ProfilePassportEditComponent } from './profile/profile-passport-edit/profile-passport-edit.component';
import { AddassociateComponent } from './addassociate/addassociate.component';
import { RouterModule } from '@angular/router';



@NgModule({
  declarations: [
    HomeComponent,
    LoginComponent,
    HeaderComponent,
    SidenavComponent,
    EmployeeDetailsComponent,
    EmployeeEditComponent,
    SkillsComponent,
    ForgotPasswordComponent,
    RoleDetailsComponent,
    RoleEditComponent,
    LocationEditComponent,
    TitleDetailsComponent,
    TitleEditComponent,
    LocationDetailsComponent,
    LocationEditComponent,
    PracticeDetailsComponent,
    PracticeEditComponent,
    CompetencyComponent,
    CompetencyTypeComponent,
    CompetencyLevelComponent,
    CompetencyEditComponent,
    CompetencyLevelEditComponent,
    CompetencyTypeEditComponent,
    DepartmentDetailsComponent,
    DepartmentEditComponent,
    LoaderComponent,
    PassportComponent,
    VisatypeComponent,
    VisatypeEditComponent,
    ProfileComponent,
    GradeComponent,
    GradeEditComponent,
    DashboardComponent,
    EmployeeViewDetailsComponent,
    EmployeeRelieveComponent,
    ChangePasswordComponent,
    OrgChartComponent,
    OrganizationChartComponent,
    ProfileSkillEditComponent,
    EmployeeExcelImportComponent,
    SkillExcelPreviewComponent,
    ProfilePassportEditComponent,
    AddassociateComponent
  ],
  imports: [
    ReactiveFormsModule,
    FormsModule,
    RouterModule,
    CommonModule,
    HomeRoutingModule,
    SharedModule,
    HttpClientModule,
    MatTableModule,
    MatDialogModule,
    MatGridListModule,
    MatTabsModule,
    MatInputModule,
    MatSlideToggleModule
    
    
  ],
  exports:[LoaderComponent],
  providers:[MatSnackBar, DatePipe]
})
export class HomeModule { }
