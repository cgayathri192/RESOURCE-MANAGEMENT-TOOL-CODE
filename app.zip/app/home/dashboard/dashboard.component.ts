
import { AfterViewInit, Component, ElementRef, inject, Input, ViewChild } from '@angular/core';
// import { AllEmployee, AllEmployeeRes, Employee, Employeebilling, EmployeebillingRes, EmployeeLocation, EmployeeLocationRes, EmployeeSkillsRes, LocationSkills, TenurityLocation, TenurityLocationRes } from '@core/models/dashboard';
import { AllEmployee, AllEmployeeRes, Associate, Employeebilling, LocationData,EmployeebillingRes, Location, AssociateLocationRes, EmployeeSkillsRes, LocationSkills, TenurityLocation, TenurityLocationRes } from '@core/models_new/dashboard';
// import { LocationModel, LocationRes } from '@core/models/location';
import { locationModel, LocationRes } from '@core/models_new/Location';
import { ConfigService } from '@core/services/config.service';
import { GenericRepositoryService } from '@core/services/generic-repository.service';
import { Chart, ChartConfiguration, registerables } from 'chart.js';
Chart.register(...registerables);
import 'chartjs-plugin-datalabels'; 


export interface Tile {

  cols: number;
  rows: number;
  text: string;
}

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent {
  locationDropdown:boolean=false
  @ViewChild('doughnutSkillsChart', { static: false }) doughnutSkillsChart!: ElementRef;
  @ViewChild('doughnutEmployeeChart', { static: false }) doughnutEmployeeChart!: ElementRef;
  @ViewChild('barLocationChart', { static: true }) barLocationChart!: ElementRef;
  @ViewChild('lineBillingChart', { static: true }) lineBillingChart!: ElementRef;
  doughnutEmpChart!: Chart<'doughnut', number[], unknown>;
  doughnutSkillChart!: Chart<'doughnut', number[], unknown>;
  barlocationChart!: Chart<'bar', number[], unknown>;
  lineBillingChartInstance!: Chart<'line', number[], unknown>;
  selectedLocation: string = "All";
  LocationList!: locationModel[];
  locationService = inject(GenericRepositoryService<LocationRes>);
  employeeLocationService = inject(GenericRepositoryService<AssociateLocationRes>)
  employeeSkillsService = inject(GenericRepositoryService<EmployeeSkillsRes>)
  allEmployeeService = inject(GenericRepositoryService<AllEmployeeRes>)
  employeeMTTenurityService = inject(GenericRepositoryService<TenurityLocationRes>)
  employeeCountbillingService = inject(GenericRepositoryService<EmployeebillingRes>)
  employeelocationData: Location[] = [];
  employeelocationSkillsData: LocationSkills[] = [];
  employeeCountByMTTenurity: TenurityLocation[] = [];
  employeeCountbilling!: Employeebilling;
  allEmployee!: AllEmployee;

  constructor(private config: ConfigService,
  ) {
    this.loadLocation();
    this.employeeSkillsService
      .get(this.config.environment.endpoints.employeeSkillsLocationCount)
      .subscribe({
        next: (res: EmployeeSkillsRes) => {
         
          if (res && res.locations) {
            this.employeelocationSkillsData = res.locations;
          } else {
            this.employeelocationSkillsData = [];
          }
          this.generateLocationDoughnutChart();
          this.generateSkillsDoughnutChart();
        },
      });
    this.employeeLocationService
      .get(this.config.environment.endpoints.employeeLocationCount)
      .subscribe({
        next: (res: AssociateLocationRes) => {
        
          if (res && res.LocationData) {
            this.employeelocationData = res.LocationData;
          } else {
            this.employeelocationData = [];
          }
          this.generateLocationDoughnutChart();
          this.generateSkillsDoughnutChart();
        },
      });
    this.employeeMTTenurityService
      .get(this.config.environment.endpoints.employeeCountByMTTenurity)
      .subscribe({
        next: (res: TenurityLocationRes) => {
          if (res && res.locations) {
            this.employeeCountByMTTenurity = res.locations;
          } else {
            this.employeeCountByMTTenurity = [];
          }
          this.generateLocationDoughnutChart();
          this.generateSkillsDoughnutChart();
          this.generatebarLocationChart();
        },
      });
      this.employeeCountbillingService
  .get(this.config.environment.endpoints.employeeCountbilling)
  .subscribe({
    next: (res: EmployeebillingRes) => {
      if (res && res.data) {
        this.employeeCountbilling = res.data;
        console.log(this.employeeCountbilling,"this.employeeCountbilling")
      } 
      this.generateLocationDoughnutChart();
      this.generateSkillsDoughnutChart();
      this.generatebarLocationChart();
      this.generateLineBillingChart();
    },
  });

  }
  
  ngOnInit(): void {
    this.loadAllEmployeeData();
  }
    
  loadAllEmployeeData(): void {
    this.allEmployeeService
      .get(this.config.environment.endpoints.AllEmployee)
      .subscribe({
        next: (res: AllEmployeeRes) => {
          this.allEmployee = res.data;
        },
      });
  }
  
  onLLocationchange(): void {
    this.generateLocationDoughnutChart();
    this.generateSkillsDoughnutChart();
    this.generatebarLocationChart();
    this.generateLineBillingChart();
  }

  onLocationSelection(location: string): void {
    this.selectedLocation = location;
    this.locationDropdown = false; 
    this.onLLocationchange(); 
}


  generateLocationDoughnutChart(): void {
    const filteredData = this.employeelocationData.filter(location => {
      if (this.selectedLocation === 'All') {
        return location.Location !=='All';
      } else {
        // console.log(this.employeelocationData,"this.employeelocationData")
        return location.Location === this.selectedLocation ;
      }
    });
    
    // console.log("filtereddata",filteredData)
    const ctx = this.doughnutEmployeeChart.nativeElement.getContext('2d');
  
    if (this.doughnutEmpChart) {
      this.doughnutEmpChart.destroy();
    }
  
    const employeeCounts = filteredData.map(location => location.AssocaiateCount);
    // console.log(employeeCounts,"employeeCounts")
    this.doughnutEmpChart = new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: filteredData.map(location => location.Location),
        datasets: [
          {
            data: employeeCounts,
            backgroundColor: ['#0098DA', '#F89B43', '#FFD525', '#57B952'],
          },
        ],
      },
      options: {
        responsive: true,
        cutout: '60%',
        aspectRatio: 2.7,
        maintainAspectRatio: false,
        layout: {
          autoPadding: true,
        },
        plugins: {
          tooltip: {
            yAlign: 'bottom',
            xAlign: 'center',
            bodyAlign: 'center',
          },
          legend: {
            display: true,
            position: 'right',
            align: 'center',
            labels: {
              usePointStyle: true,
              pointStyle: 'circle',
              padding: 15,
              font: {
                family: 'poppins',
                size: 14,
                style: "normal",
                weight: '400',
                lineHeight: 'normal',
              },
            },
          },
        },
        elements: {
          point: {
            pointStyle: 'circle',
          },
        },
      },
    });
  }
  
  generateSkillsDoughnutChart(): void {
    const filteredData = this.employeelocationSkillsData.filter(
      location => location.city === this.selectedLocation
    );
    // console.log(filteredData,"data")
    const ctx = this.doughnutSkillsChart.nativeElement.getContext('2d');
    if (this.doughnutSkillChart) {
      this.doughnutSkillChart.destroy();
    }
    this.doughnutSkillChart = new Chart(ctx, {
      type: 'doughnut',
      data: {
        datasets: [{
          data: filteredData[0]?.Associate?.map(s => s.count),
          backgroundColor: ['#91D8F7','#0098DA','#CE7622','#F89B43','#E5BE1A','#FFD525','#339E2E','#57B952','#51a351'].slice(0, filteredData[0]?.Associate.map(s => s.count).length),
          borderAlign: 'center'
        }],
        labels: filteredData[0]?.Associate?.map(s => s.competency),
      },
      options: {
        responsive: true,
        cutout: '60%',
        aspectRatio:4,
        maintainAspectRatio: false,
        layout: {
          autoPadding: true,
        },
        plugins: {
          tooltip: {
            yAlign: 'bottom',
            xAlign: 'center',
            bodyAlign: 'center'
          },
          legend: {
            display: true,
            position: 'right',
            align: 'center',           
            labels: {
              usePointStyle: true,
              pointStyle: 'circle',
              padding: 15,
              font: {
                family: 'poppins',
                size:12,
                style:"normal",
                weight:'400',
                lineHeight:'normal',
              },
            }
          },
        }
      }
      
    });
  }
  loadLocation() {
    this.locationService
      .get(this.config.environment.endpoints.location)
      .subscribe({
        next: (res: LocationRes) => {
          if (res && res.data) {
            this.LocationList = res.data;
          } else {
            this.LocationList = [];
          }
        },
      });
  }
  generatebarLocationChart(): void {
    const filteredData = this.employeeCountByMTTenurity.filter(
      location => location.city === this.selectedLocation
    );
    if (filteredData.length === 0 || !filteredData[0]?.associates) {
      const ctx = this.barLocationChart.nativeElement.getContext('2d');
      ctx.clearRect(0, 0, this.barLocationChart.nativeElement.width, this.barLocationChart.nativeElement.height);
      ctx.fillText('No data available for the selected location.', this.barLocationChart.nativeElement.width / 2, this.barLocationChart.nativeElement.height / 2);
      return;
    }
    let tenurityGroups: string[] = [];
    filteredData[0]?.associates.forEach((employee) => {
      if (!tenurityGroups.includes(employee.MouriTechTenurityGroup)) {
        tenurityGroups.push(employee.MouriTechTenurityGroup);
      }
    });
    tenurityGroups.sort((a, b) => {
      const aValue = parseInt(a.split('-')[0]);
      const bValue = parseInt(b.split('-')[0]);
      return aValue - bValue;
    });
    const sortedEmployees = filteredData[0]?.associates.slice();
    sortedEmployees.sort((a, b) => {
      const aValue = parseInt(a.MouriTechTenurityGroup.split('-')[0]);
      const bValue = parseInt(b.MouriTechTenurityGroup.split('-')[0]);
      return aValue - bValue;
    });
    const ctx = this.barLocationChart.nativeElement.getContext('2d');
    if (this.barlocationChart) {
      this.barlocationChart.destroy();
    }
    this.barlocationChart = new Chart(ctx, {
      type: 'bar',
      data: {   
        labels: sortedEmployees?.map(s => s.MouriTechTenurityGroup),
        datasets: [
          {
          barPercentage: 0.9,
          barThickness: 18,
          maxBarThickness: 25,
          minBarLength: 2,
          borderRadius: 10.5,
          borderSkipped:false,
          borderWidth:0,
          data: sortedEmployees.map(s => s.count),
          backgroundColor: ['#FFD525','#91D8F7','#86C0E1','#D1D1D1','#0098DA','#57B952','#D1D1D1']
            .slice(0, sortedEmployees?.length),
            label: 'MOURITech Tenurity Groups'
        },
      ],
      },
      options: {
        responsive: true,
        layout: {
          autoPadding: true,
        },
        scales: {
          y: 
            {
              beginAtZero: true,
              ticks:{
                stepSize:4,
              },
              grid: {
                display: true,
              },
            },
          x: 
            {
              grid: {
                display:false,
              }
            }
        },
        plugins: {
          tooltip: {
            yAlign: 'bottom',
            xAlign: 'center',
            bodyAlign: 'center'
          },
          legend: {
            display: true,
            position: 'bottom',
            align: 'center',
            labels: {
              usePointStyle: true,
              padding: 15
            }
          },
        },
      } 
    });
  }
  generateLineBillingChart(): void {
    const locations = this.employeeCountbilling.LocationData.map(entry => entry.Location);
    const billableEmployees = this.employeeCountbilling.LocationData.map(entry => entry.Billable);
    const nonBillableEmployees = this.employeeCountbilling.LocationData.map(entry => entry.NonBillable);
  
    const ctx = this.lineBillingChart?.nativeElement?.getContext('2d');
    if (!ctx) {
      return; 
    }
  
    if (this.lineBillingChartInstance) {
      this.lineBillingChartInstance.destroy();
    }
  
    this.lineBillingChartInstance = new Chart(ctx, {
      type: 'line',
      data: {
        labels: locations,
        datasets: [
          {
            label: 'Billable Employees',
            data: billableEmployees,
            borderColor: '#27A360',
            fill: 'yes',
            backgroundColor:['#27A360'],
          },
          {
            label: 'Non-Billable Employees',
            data: nonBillableEmployees,
            borderColor: '#EB5757',
            fill: 'yes',
            backgroundColor:['#EB5757']
          },
        ]
      },
      options: {
        responsive: true,
        scales: {
          x: {
            display: true,
            title: {
              display: true,
              text: 'Location',
              font:{
                family:'poppins'
              }
            }
          },
          y: {
            display: true,
            title: {
              display: true,
              text: 'Number of Employees',
              font:{
                family:'poppins'
              }
            },
            ticks: {
              stepSize: 4, 
              precision: 0 
            }
          }
        },
        plugins: {
          tooltip: {
            mode: 'index',
            intersect: false,
            yAlign: 'bottom',
            xAlign: 'center',
            bodyAlign: 'center'
          },
          legend: {
            display: true,
            position: 'bottom',
            align: 'center',
            labels: {
              usePointStyle: true,
              padding: 15,
              
            }
          }
        }
      }
    });
  }
}
