import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProfilePassportEditComponent } from './profile-passport-edit.component';

describe('ProfilePassportEditComponent', () => {
  let component: ProfilePassportEditComponent;
  let fixture: ComponentFixture<ProfilePassportEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProfilePassportEditComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ProfilePassportEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
