import { DatePipe } from '@angular/common';
import { Component, Inject, inject } from '@angular/core';
import {FormArray,FormBuilder,FormControl,FormGroup,Validators,} from '@angular/forms';
import {MAT_DIALOG_DATA, MatDialog,MatDialogRef,} from '@angular/material/dialog';
// import { Employee, EmployeeReq, Passport } from '@core/models/employee';
import { EmployeeReq, Passport } from '@core/models_new/employee';
// import { PassportModel, PassportReq } from '@core/models/passport';
import { PassportModel, PassportModelUpdate } from '@core/models_new/passport';
// import { VisatypeModel, VisatypeRes } from '@core/models/visatype';
import { VisatypeModel, visaTypeRes } from '@core/models_new/visatype';
import { AlertService } from '@core/services/alert.service';
import { ConfigService } from '@core/services/config.service';
import { GenericRepositoryService } from '@core/services/generic-repository.service';
import { EmployeeEditComponent } from '@home-module/employee/employee-edit/employee-edit.component';

@Component({
  selector: 'app-profile-passport-edit',
  templateUrl: './profile-passport-edit.component.html',
  styleUrls: ['./profile-passport-edit.component.scss'],
})
export class ProfilePassportEditComponent {
  passportForm!: FormGroup;
  enablePassport: boolean = false;
  visaVisable: boolean = true;
  defaultOption = 'Yes';
  isSubmitted: boolean = false;
  loadData: boolean = true;
  visaButtonsOptions: string[] = ['Yes', 'No'];
  isActives = [
    { values: true, isActiveValue: 'Active' },
    { values: false, isActiveValue: 'Inactive' },
  ];
  VisaTypeList!: VisatypeModel[];
  visaTypeService = inject(GenericRepositoryService<VisatypeModel>);
  employeeId!: number;
  constructor(
    private _fb: FormBuilder,
    private config: ConfigService,
    private _dialogRef: MatDialogRef<EmployeeEditComponent>,
    private gsreq: GenericRepositoryService<EmployeeReq>,
    private gs: GenericRepositoryService<PassportModelUpdate>,
    @Inject(MAT_DIALOG_DATA) public data: { employeeId: number },
    private alertService: AlertService,
    private datepipe: DatePipe,
    private fb: FormBuilder,
    public dialog: MatDialog
  ) {
    let passportValidator = this.enablePassport ? [Validators.required] : null;
    this.employeeId = this.data ? this.data.employeeId : 0;
    this.passportForm = this._fb.group({
      Passport: this.fb.group({
        Id: 0,
        AuthUserId: this.employeeId,
        // PassportNumber: new FormControl('',passportValidator),
        PassportExpiry: new FormControl('', passportValidator),
        PassportStatus: new FormControl(''),
        // VisaValidity: new FormControl('',passportValidator),
        // VisaTypeId: new FormControl('',passportValidator),
        // VisaStatus: new FormControl('',passportValidator)
      }),
      Visa: this.fb.array([this.preloadVisa()]),
    });
  }
  ngOnInit(): void {
    this.loadDropdowns();
    if (this.data) {
      this.gsreq
        .getById(
          this.config.environment.endpoints.associate,
          this.data.employeeId
        )
        .subscribe({
          next: (res: EmployeeReq) => {
            console.log(res.data, 'res.data');
            if (res && res.data) {
              this.passportForm.patchValue(res.data);
              if (res.data.Passport) {
                this.enablePassport = true;
                let passport = {
                  Id: res.data.Passport.Id,
                  AuthUserId: res.data.Passport.AuthUserId,
                  PassportExpiry: res.data.Passport.PassportExpiry,
                  PassportStatus: res.data.Passport.PassportStatus,
                };
                if (this.validatePassportData(passport))
                  this.passportForm.get('Passport')?.setValue(passport);
              }
              if (res.data.Visa) {
                const visaArray = this.passportForm.get('Visa') as FormArray;
              
                for (let i = 0; i < res.data.Visa.length; i++) {
                  const visa = res.data.Visa[i];
                  let patchVisa = {
                    Id: visa.Id,
                    AuthUserId: visa.AuthUserId.Id,
                    VisaStatus: visa.VisaStatus,
                    VisaTypeId: visa.VisaTypeId.Id,
                    VisaValidity: visa.VisaValidity
                  };
                  const visaFormGroup = visaArray.at(i) as FormGroup;
                  visaFormGroup.patchValue(patchVisa);
                }
              }
              
              this.loadData = true;
            }
          },
        });
    }
  }

  get Visa(): FormArray {
    return this.passportForm.get('Visa') as FormArray;
  }

  preloadVisa(){
    return this._fb.group({
      Id: 0,
      AuthUserId: this.employeeId,
      VisaTypeId: ['', Validators.required],
      VisaStatus: ['', Validators.required],
      VisaValidity: ['', Validators.required],
    })
  }
  addVisa() {
    const visaArray = this.preloadVisa();
    this.Visa.push(visaArray);

  }
  removeVisa(index: number) {
    this.Visa.removeAt(index);
  }

  loadDropdowns(): void {
    this.loadVisaType();
  }
  loadVisaType() {
    this.visaTypeService
      .get(this.config.environment.endpoints.visatype)
      .subscribe({
        next: (res: visaTypeRes) => {
          if (res && res.data) {
            this.VisaTypeList = res.data;
          } else {
            this.VisaTypeList = [];
          }
        },
      });
  }
  togglePassport() {
    this.enablePassport = !this.enablePassport;
    if (this.enablePassport) {
      this.visaVisable = true;
      this.defaultOption = 'Yes';
      // this.passportForm.get("Passport.PassportNumber")?.setValidators([Validators.required]);
      this.passportForm.get('Passport.PassportExpiry')?.setValidators([Validators.required]);
      this.passportForm.get('Passport.PassportStatus')?.setValidators([Validators.required]);
      this.passportForm.get('Visa.VisaValidity')?.setValidators([Validators.required]);
      this.passportForm.get('Visa.VisaTypeId')?.setValidators([Validators.required]);
      this.passportForm.get('Visa.VisaStatus')?.setValidators([Validators.required]);
    } else {
      // this.passportForm.get("Passport.PassportNumber")?.clearValidators();
      // this.passportForm.get("Passport.PassportNumber")?.updateValueAndValidity();
      this.passportForm.get('Passport.PassportExpiry')?.clearValidators();
      this.passportForm.get('Passport.PassportExpiry')?.updateValueAndValidity();
      this.passportForm.get('Passport.PassportStatus')?.clearValidators();
      this.passportForm.get('Passport.PassportStatus')?.updateValueAndValidity();
      this.passportForm.get("Visa.VisaValidity")?.clearValidators();
      this.passportForm.get("Visa.VisaValidity")?.updateValueAndValidity();
      this.passportForm.get("Visa.VisaTypeId")?.clearValidators();
      this.passportForm.get("Visa.VisaTypeId")?.updateValueAndValidity();
      this.passportForm.get("Visa.VisaStatus")?.clearValidators();
      this.passportForm.get("Visa.VisaStatus")?.updateValueAndValidity();
    }
  }
  visaButton(event: string) {
    if (event == 'Yes') {
      this.visaVisable = true;
      this.passportForm.get('Visa.VisaValidity')?.setValidators([Validators.required]);
      this.passportForm.get('Visa.VisaTypeId')?.setValidators([Validators.required]);
      this.passportForm.get('Visa.VisaStatus')?.setValidators([Validators.required]);
    } else {
      this.visaVisable = false;
      this.passportForm.get('Visa.VisaTypeId')?.setValue(null)
      this.passportForm.get('Visa.VisaStatus')?.setValue(null)
      this.passportForm.get('Visa.VisaValidity')?.setValue(null)
      this.passportForm.get('Visa.VisaValidity')?.clearValidators();
      this.passportForm.get('Visa.VisaValidity')?.updateValueAndValidity();
      this.passportForm.get('Visa.VisaTypeId')?.clearValidators();
      this.passportForm.get('Visa.VisaTypeId')?.updateValueAndValidity();
      this.passportForm.get('Visa.VisaStatus')?.clearValidators();
      this.passportForm.get('Visa.VisaStatus')?.updateValueAndValidity();
    }
  }
  onFormSubmit() {
    this.isSubmitted = true;
    if (this.passportForm.valid) {
      let passportobj: PassportModelUpdate = this.passportForm.value as PassportModelUpdate;
      passportobj.Passport.AuthUserId = this.employeeId;
      passportobj.Passport.PassportExpiry =this.datepipe.transform(passportobj.Passport.PassportExpiry, 'yyyy-MM-dd')
          ?.toString() ?? '';
          for (let visa of passportobj.Visa) {
            visa.AuthUserId=this.employeeId,
            visa.VisaValidity = this.datepipe.transform(visa.VisaValidity, 'yyyy-MM-dd') || '';
          }
          passportobj.VisaRemoved=[]
      console.log(passportobj, 'passportobj');
      if (this.enablePassport == false) {
        console.log('when enable pass is false');
        this.gs
          .delete(
            this.config.environment.endpoints.passport,
            passportobj.Passport.Id
          )
          .subscribe({
            next: (val: any) => {
              this.alertService.show('Success', 'passport details Deleted!');
              this._dialogRef.close(true);
            },
            error: (err: any) => {
              this.alertService.show('Error', 'passport details not Deleted!');
            },
          });
      } else {
        if (this.data) {
          this.gs
            .update(
              this.config.environment.endpoints.passport,
              null,
              passportobj
            )
            .subscribe({
              next: (val: any) => {
                this.alertService.show('Success', 'passport details updated!');
                this._dialogRef.close(true);
              },
              error: (err: any) => {
                this.alertService.show(
                  'Error',
                  'passport details not updated!'
                );
              },
            });
        } else {
          this.gs
            .create(this.config.environment.endpoints.passport, passportobj)
            .subscribe({
              next: (val: any) => {
                this.alertService.show('Success', 'passport details added!');
                this._dialogRef.close(true);
              },
              error: (err: any) => {
                this.alertService.show('Error', 'passport details not added!');
              },
            });
        }
      }
    }
  }
  closeDialog() {
    this._dialogRef.close();
  }
  validatePassportData(passportInformation: Passport): boolean {
    for (let data of Object.values(passportInformation)) {
      if (data == undefined || data === null) {
        return false;
      }
    }
    return true;
  }
}
