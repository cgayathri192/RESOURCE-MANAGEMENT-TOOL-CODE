import { Component } from '@angular/core';
import { FormBuilder } from '@angular/forms';
// import { EmployeeModel, EmployeeReq, SkillRes } from '@core/models/employee';
import { EmployeeModel, EmployeeReq, Competency } from '@core/models_new/employee';
import { JwtToken } from '@core/models/tokens';
import { AuthService } from '@core/services/auth.service';
import { ConfigService } from '@core/services/config.service';
import { GenericRepositoryService } from '@core/services/generic-repository.service';
import { MatDialog } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { SkillModel } from '@core/models/skill';
import { ProfileSkillEditComponent } from './profile-skill-edit/profile-skill-edit.component';
import { ProfileService } from '@core/services/profile.service';
import { ProfilePassportEditComponent } from './profile-passport-edit/profile-passport-edit.component';
@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})

export class ProfileComponent {
  form: any;
  loggedInUserDetails: JwtToken;
  profileDetails!: EmployeeModel;
  dataSource: any;
  loadData:boolean=true;
  emplist: any;
  skill_list: SkillModel[] = [];
  public showInitials = false;
  public initials: string='';
  public circleColor: string='';
  constructor(private authService: AuthService,
    private profile:ProfileService,
    private genericService: GenericRepositoryService<EmployeeReq>,
    private gs: GenericRepositoryService<Competency>,
    private configService: ConfigService,
    private fb: FormBuilder,
    private _dialog: MatDialog,
    private config:ConfigService


  ) {
    this.form = this.fb.group({
      id: [],
    })
    if (this.authService.isLoggedIn()) {
      let userName: string= this.authService.getTokenDetails().ResourceName;
      this.profile.createInititals(userName);
      this.showInitials = this.profile.showInitials;
      this.profile.$initials.subscribe((res: string)=>{
        this.initials= res;
        this.circleColor = this.profile.circleColor;
      });
    }
    this.loggedInUserDetails = this.authService.getTokenDetails();
    this.getEmployeeDetails();
  }
  getEmployeeDetails() {
    this.genericService.getById(this.configService.environment.endpoints.employee, this.loggedInUserDetails.user_id).subscribe({
      next: (employee: EmployeeReq) => {
        if (employee) {
          this.profileDetails = employee.data;
          // console.log(this.profileDetails,"this.profileDetails")
        }
      }
    })
  };
  addEmployeeSkillsForm(data:any) {
    const dialogRef = this._dialog.open(ProfileSkillEditComponent,{
      width:'60vw',
      data,
    });
    dialogRef.afterClosed().subscribe({
      next: (val) => {
        if (val) {
          this.getEmployeeListSkills();
          this.getEmployeeDetails();
        }
      },
    });
  }
  addEmployeepassportForm(data:any) {
    const dialogRef = this._dialog.open(ProfilePassportEditComponent,{
      width:'60vw',
      data:{ employeeId:this.loggedInUserDetails.user_id},
    });
    dialogRef.afterClosed().subscribe({
      next: (val) => {
        if (val) {
          this.getEmployeeDetails();
        }
      },
    });
  }
  getEmployeeListSkills() {
    this.gs.get(this.config.environment.endpoints.AssociateCompetencies).subscribe((res: Competency) => {
    this.dataSource = new MatTableDataSource(this.skill_list);
      }
    )
  }
  openEditForm(data: any) {
    const dialogRef = this._dialog.open(ProfileSkillEditComponent, {
      data
    });

    dialogRef.afterClosed().subscribe({
      next: (val) => {
        if (val) {
          this.getEmployeeListSkills();
        }
      },
    });
  }
 
}