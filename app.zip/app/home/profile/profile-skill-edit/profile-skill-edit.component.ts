import { Component, Inject, inject } from '@angular/core';
import { FormGroup, FormBuilder, FormArray, FormControl, Validators, ValidatorFn, AbstractControl } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
// import { CompetencyRes, CompetencyModel } from '@core/models/competency';
import { CompetencyRes, CompetencyModel } from '@core/models_new/competency';
// import { CompetencylevelModel, CompetencylevelRes } from '@core/models/competencylevel';
import { CompetencylevelModel, CompetencylevelRes } from '@core/models_new/competencylevel';
// import { CompetencyTypeModel, CompetencyTypeRes } from '@core/models/competencytype';
import { CompetencyTypeModel, CompetencyTypeRes } from '@core/models_new/competencytype';
// import { EmployeeReq, Skill } from '@core/models/employee';
import { EmployeeReq, Competency } from '@core/models_new/employee';
// import { SkillReq, SkillModel, CompetencyType, SkillUpdateModel } from '@core/models/skill';
import { SkillReq, SkillModel, CompetencyType ,SkillUpdateModel,skillUpdate} from '@core/models_new/skill';
import { JwtToken } from '@core/models/tokens';
import { AlertService } from '@core/services/alert.service';
import { AuthService } from '@core/services/auth.service';
import { ConfigService } from '@core/services/config.service';
import { GenericRepositoryService } from '@core/services/generic-repository.service';

@Component({
  selector: 'app-profile-skill-edit',
  templateUrl: './profile-skill-edit.component.html',
  styleUrls: ['./profile-skill-edit.component.scss']
})
export class ProfileSkillEditComponent {
  skillForm : FormGroup;
  loggedInUserDetails: JwtToken;
  CompetencyLevelList!: CompetencylevelModel[];
  loadData:boolean=false;
  CompetencyTypeList!: CompetencyTypeModel[];
  competencyTypeService = inject(GenericRepositoryService<CompetencyTypeRes>);
  competencyService = inject(GenericRepositoryService<CompetencyRes>);
  skillRemoved: number[] = [];
  competencyListforDropdown: CompetencyModel[][]= [];
  isSubmitted: boolean=false;
  CompetencyList!: CompetencyModel[];
  isPrimaryList = [
    { values: true, isActiveValue: 'Yes'},
    { values: false, isActiveValue: 'No'},
  ];
  skillDetails:any;
  constructor(
    private fb: FormBuilder,
    private _dialogRef: MatDialogRef<ProfileSkillEditComponent>,
    private alertService: AlertService,
    private config: ConfigService,
    private gs:GenericRepositoryService<skillUpdate>,
    private genericService: GenericRepositoryService<EmployeeReq>,
    private gsreq: GenericRepositoryService<SkillReq>,
    @Inject(MAT_DIALOG_DATA) public data: {Id: number, competencyList: CompetencyModel[], Skills:SkillModel[] },
    private authService: AuthService,
  ) {
    let AuthUserId: number = this.data ? this.data.Id : 0;
    this.loggedInUserDetails = this.authService.getTokenDetails();
    this.skillForm = this.fb.group(
      {
      Skills:new FormArray([]),
    });

  }
  get Competency() {
    return this.skillForm.get('Competency');
  }
  get CompetencyType() {
    return this.skillForm.get('CompetencyType');
  }
  get CompetencyLevel() {
    return this.skillForm.get('CompetencyLevel');
  }
  get CompetencyVersion() {
    return this.skillForm.get('CompetencyVersion');
  }
  get Primary() {
    return this.skillForm.get('Primary');
  }
  ngOnInit(): void {
    this.loadDropdowns();
    this.getskilldetails();
      if (this.data) {
        this.gsreq.getById(this.config.environment.endpoints.employee, this.data.Id).subscribe({
        next: (res: SkillReq) => {
          if (res && res.data) {
            this.skillForm.patchValue(res.data);
            // console.log(res.data,"this.skillForm")
            this.skillForm.get('Competency')?.setValue(res.data.Competency.Id);
            this.skillForm.get('CompetencyType')?.setValue(res.data.Competency.CompetencyType);
            this.skillForm.get('CompetencyLevel')?.setValue(res.data.CompetencyLevel);
            this.skillForm.get('CompetencyVersion')?.setValue(res.data.CompetencyVersion);
            this.skillForm.get('Primary')?.setValue(res.data.Primary);
          }
          this.loadData=true;
        }
      }
      )
     }
  }
  
  loadDropdowns(): void {
    this.loadCompetencyType();
    this.loadCompetency();
    this.loadCompetencyLevel();
  }
  loadCompetencyType() {
    this.competencyTypeService
      .get(this.config.environment.endpoints.competencytype)
      .subscribe({
        next: (res: CompetencyTypeRes) => {
          if (res && res.data) {
            this.CompetencyTypeList = res.data;
          } else {
            this.CompetencyTypeList = [];
          }
        },
      });
  }
  loadCompetencyLevel() {
    this.competencyService
      .get(this.config.environment.endpoints.competencylevel)
      .subscribe({
        next: (res: CompetencylevelRes) => {
          if (res && res.data) {
            this.CompetencyLevelList = res.data;
          } else {
            this.CompetencyLevelList = [];
          }
        },
      });
  }
  loadCompetency() {
    this.competencyService
      .get(this.config.environment.endpoints.competency)
      .subscribe({
        next: (res: CompetencyRes) => {
          if (res && res.data) {
            this.CompetencyList = res.data;
          } else {
            this.CompetencyList = [];
          }
        },
      });
  }
    getCompetencylist(competencyType: CompetencyType, competencyList: CompetencyModel[]): CompetencyModel[] {
      if (!competencyList) {
        return [];
      }
      return competencyList.filter((m: CompetencyModel) => m.CompetencyType && m.CompetencyType.Id === competencyType.Id);
    }
    get skills() {
      return this.skillForm.get('Skills') as FormArray;
    }
    addSkill() {
      let AuthUserId: number = this.data ? this.data.Id : 0;
      const skill = this.fb.group({
        Id: 0,
        AuthUserId: AuthUserId,
        CompetencyVersion: new FormControl(''),
        CompetencyTypeId: new FormControl('',[Validators.required]),
        CompetencyId: new FormControl('', [Validators.required,this.competencyVailidator()]),
        CompetencyLevelId: new FormControl('',[Validators.required]),
        Primary: new FormControl('',[Validators.required]),
      });
      this.skills.push(skill);
    }
    removeSkill(index: number) {
      const removedSkill: Competency = this.skills.at(index).value;
      if (removedSkill && removedSkill.Id != 0) {
        this.skillRemoved.push(removedSkill.Id);
      }
      this.skills.removeAt(index);
    }
    competencyVailidator(): ValidatorFn {
      return (control: AbstractControl): { [key: string]: any } | null => {
        const skillsArray = this.skillForm.get('Skills') as FormArray;
        if (skillsArray.length) {
          let duplicateSkill;
          if(control?.parent?.value.Id) {
            duplicateSkill = skillsArray.value.filter((skill: any) => 
             control.value === skill.CompetencyId && control?.parent?.value.Id !== skill.Id
            );
          } else {
            duplicateSkill = skillsArray.value.filter((skill: any) => control.value === skill.CompetencyId);
            duplicateSkill =  duplicateSkill.length > 1 ? duplicateSkill : [];
          }
          return duplicateSkill.length ? { invalidCompetency: true } : null;
        } else {
          return null;
        }
      };
    }
    selectedCompetencyChanged(){
      const skillsArray = this.skillForm.get('Skills') as FormArray;
      skillsArray.controls.forEach((skill:AbstractControl<any,any>) => {
        skill.get("CompetencyId")?.markAsTouched();
        skill.get("CompetencyId")?.updateValueAndValidity();
      });
    }
    oncompetencyTypeOptionChange(event: any, index: number) {
      this.competencyListforDropdown[index] = this.CompetencyList.filter(
       (competency) => competency.CompetencyType.Id == event.value
      );
    }
    
    getCompetencyOptions(index: number): CompetencyModel[] {
      return this.competencyListforDropdown[index] || [];
    }
    getskilldetails(){
      this.genericService.getById(this.config.environment.endpoints.associate, this.loggedInUserDetails.user_id).subscribe({
        next: (employee: EmployeeReq) => {
          if (employee) {
            this.skillDetails = employee.data.Competencies;
              if ( this.skillDetails && this.skillDetails.length > 0) {
                this.skillDetails.forEach((skillRes: { Competency: {Id: any;}; CompetencyType: { Id: any; }; Id: any; AuthUserId: {Id:any}; CompetencyVersion: any; CompetencyLevel: { Id: any; }; Primary: any; }, index: number) => {
                  // console.log(skillRes,"skillRes")
              if (skillRes) {
                this.competencyListforDropdown[index] = this.getCompetencylist(skillRes.CompetencyType.Id,  this.CompetencyList)
                this.getCompetencyOptions(skillRes.Competency.Id)
                let skillform = this.fb.group({
                  Id: skillRes.Id,
                  AuthUserId: skillRes.AuthUserId.Id,
                  CompetencyVersion: new FormControl(skillRes.CompetencyVersion),
                  CompetencyTypeId: new FormControl(skillRes.CompetencyType.Id, [Validators.required]),
                  CompetencyId: new FormControl(skillRes.Competency.Id, [Validators.required,this.competencyVailidator()]),
                  CompetencyLevelId: new FormControl(
                    skillRes.CompetencyLevel.Id
                  ),
                  Primary: new FormControl(skillRes.Primary),
                });
                this.skills.push(skillform);
              }
            })
          }
          }
        }
      })
    }
    onFormSubmit() {
      this.isSubmitted = true;
      if (this.skillForm.valid) {
        if (this.data) {
          this.skillForm.value.Skills.forEach((skill: SkillUpdateModel, i: number) => {
            if (!skill.CompetencyVersion)
              this.skillForm.get('Skills')?.get(i.toString())?.get('CompetencyVersion')?.setValue(null);
              console.log(this.skillForm,"form")
          });
    
          const skills= this.skillForm.value.Skills.map((skill: SkillUpdateModel) => {
            return {
              Id: skill.Id,
              AuthUserId: skill.AuthUserId, 
              CompetencyVersion:skill.CompetencyVersion,
              CompetencyTypeId: skill.CompetencyTypeId,
              CompetencyId: skill.CompetencyId,
              CompetencyLevelId: skill.CompetencyLevelId,
              Primary: skill.Primary,
            };
          });
          
          const skillUpdate:skillUpdate = {
            Competenciesdata: skills,
            CompetenciesRemoved: []
          }
          console.log(skillUpdate,"skill")
  
          this.gs.update(this.config.environment.endpoints.skill_update, null, skillUpdate)
            .subscribe({
              next: (val: any) => {
                this.alertService.show('Success', 'Skills updated!');
                this._dialogRef.close(true);
              },
              error: (err: any) => {
                this.alertService.show('Error', 'Skills not updated!');
              },
            });
        }
      }
    }
    
    closeDialog() {
      this._dialogRef.close();
    }
}