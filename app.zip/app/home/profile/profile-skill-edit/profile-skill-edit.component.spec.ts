import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProfileSkillEditComponent } from './profile-skill-edit.component';

describe('ProfileSkillEditComponent', () => {
  let component: ProfileSkillEditComponent;
  let fixture: ComponentFixture<ProfileSkillEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProfileSkillEditComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ProfileSkillEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
