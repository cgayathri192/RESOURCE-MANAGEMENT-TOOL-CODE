import { Component, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
// import { PracticeModel, PracticeRes } from '@core/models/practice';
import { PracticeModel, PracticeRes } from '@core/models_new/practice';
import { ConfigService } from '@core/services/config.service';
import { GenericRepositoryService } from '@core/services/generic-repository.service';
import { PracticeEditComponent } from '../practice-edit/practice-edit.component';
import { DatePipe } from '@angular/common';
import { AlertService } from '@core/services/alert.service';

@Component({
  selector: 'app-practice-details',
  templateUrl: './practice-details.component.html',
  styleUrls: ['./practice-details.component.scss']
})
export class PracticeDetailsComponent {
  displayedColumns: string[] = ['SNo', 'PracticeName', 'IsActive','CreatedAt', 'ModifiedBy', 'ModifiedAt', 'action']
  dataSource: MatTableDataSource<PracticeModel>;
  constructor(private gs: GenericRepositoryService<PracticeRes>, private config: ConfigService, private _dialog: MatDialog, private alertService: AlertService,private datepipe:DatePipe) {
    this.dataSource = new MatTableDataSource<PracticeModel>();
  }
  @ViewChild(MatSort) sort!: MatSort;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  ngOnInit(): void {
    this.getPractice();
  }
  openPractice() {
    const dialogRef = this._dialog.open(PracticeEditComponent);
    dialogRef.afterClosed().subscribe({
      next: (val) => {
        if (val) {
          this.getPractice();
        }
      },
    });
  }
  getPractice() {
    this.gs.get(this.config.environment.endpoints.practice).subscribe((res: PracticeRes) => {
      if(res && res.code == 200){
        res.data.sort((a, b) => {
          return new Date(b.ModifiedDateTime).getTime() - new Date(a.ModifiedDateTime).getTime();
        });
      this.dataSource = new MatTableDataSource(res.data);
      const sort = new MatSort();
      sort.active = 'CreatedAt';
      sort.direction = 'desc';
      this.dataSource.sort = this.sort;
      this.dataSource.paginator = this.paginator;
      }
    });
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value.trim().toLowerCase();;
    this.dataSource.filter = filterValue
    this.dataSource.filterPredicate = (data:PracticeModel, filter:string)=> {
      return this.filterData(data,filter);
    };
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  filterData(data: any, filter: string): boolean {
    for (const key in data) {
      if (data.hasOwnProperty(key)) {
        let value = data[key]  ?? null;
        if(key == "ModifiedAt" || key == "CreatedAt"){
          value = this.datepipe.transform(data[key], 'dd MMM, yyyy') ?? null;
        }
        if (typeof value === 'object' && value !== null) {
          if (this.filterData(value, filter)) {
            return true;
          }
        } else {
          if (value !== null && value.toString().toLowerCase().includes(filter)) {
            return true;
          }
        }
      }
    }
    return false;
  }
  deletePractice(id: number) {
    this.gs.delete(this.config.environment.endpoints.practice, id).subscribe({
      next: (res: PracticeRes) => {
        if (res && res.code == 200) {
          this.alertService.show( 'Success','Deleted successfully!');
          this.getPractice();
        }
        else {
          this.alertService.show('Error','Not deleted !');
        }
      },
      error: (err: any) => {
        this.alertService.show( 'Error','Not deleted !');
      },
    });
  }
  openEditForm(practiceId: number) {
    const dialogRef = this._dialog.open(PracticeEditComponent, {
      data:{practiceId:practiceId},
    });
    dialogRef.afterClosed().subscribe({
      next: (val) => {
        if (val) {
          this.getPractice();
        }
      },
    });
  }
}
