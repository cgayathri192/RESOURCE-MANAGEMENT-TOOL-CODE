import { Component, Inject } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
// import { Practice, PracticeRes} from '@core/models/practice';
import { PracticeRes} from '@core/models_new/practice';
import { AlertService } from '@core/services/alert.service';
import { ConfigService } from '@core/services/config.service';
import { GenericRepositoryService } from '@core/services/generic-repository.service';
import { LocationEditComponent } from '@home-module/locations/location-edit/location-edit.component';

@Component({
  selector: 'app-practice-edit',
  templateUrl: './practice-edit.component.html',
  styleUrls: ['./practice-edit.component.scss']
})
export class PracticeEditComponent {
  practiceForm: FormGroup;
  isSubmitted: boolean=false;
  constructor(
    private _fb: FormBuilder,
    private gs:GenericRepositoryService<PracticeRes>,
    private config:ConfigService,
    private alertService:AlertService,
    private _dialogRef: MatDialogRef<LocationEditComponent>,
    @Inject(MAT_DIALOG_DATA) public data: {practiceId:number},
  ) {
    this.practiceForm = this._fb.group({
      Id:new FormControl(''),
      Practice: new FormControl(null, [Validators.required]),
      IsActive: new FormControl(true, [Validators.required])
    });
  }
  get Practice(){
    return this.practiceForm.get('Practice');
  }
  get isActive(){
    return this.practiceForm.get('IsActive');
  }
  ngOnInit(): void {
    if(this.data){
      this.gs.getById(this.config.environment.endpoints.practice,this.data.practiceId).subscribe({
        next:(res:PracticeRes)=>{
          if(res.data){
            this.practiceForm.patchValue(res.data)
          }
        }
      })
    }  }
    onFormSubmit() {
      this.isSubmitted= true;
      if (this.practiceForm.valid) {
        if (this.data) {
          this.gs
          .update(this.config.environment.endpoints.practice,this.data.practiceId, this.practiceForm.value)
          .subscribe({
            next: (res: any) => {
              if (res && res.code === 200) {
                this.alertService.show('Success','Practice updated successfully!' );
                this._dialogRef.close(true);
              }else{
                this.alertService.show('Error','Practice not updated successfully!');
              }
              
            },
            error: (err: any) => {
              this.alertService.show('Error','Practice not updated successfully!');
            },
          });
        } else {
          this.gs.create(this.config.environment.endpoints.practice,this.practiceForm.value).subscribe({
            next: (res: any) => {
            if (res && res.code === 201) {
              this.alertService.show('Success','Practice added successfully!');
              this._dialogRef.close(true);
            }else{
              this.alertService.show('Error','Practice not added successfully!');
            }
            
          },
           error: (err: any) => {
        this.alertService.show('Error','Practice not added successfully!');
      },
        });
      }
    }
  }
}
