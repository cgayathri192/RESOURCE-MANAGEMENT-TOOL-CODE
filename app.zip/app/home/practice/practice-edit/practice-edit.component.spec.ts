import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PracticeEditComponent } from './practice-edit.component';

describe('PracticeEditComponent', () => {
  let component: PracticeEditComponent;
  let fixture: ComponentFixture<PracticeEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PracticeEditComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PracticeEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
