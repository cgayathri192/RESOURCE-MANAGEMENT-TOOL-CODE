import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { LocationReq } from '@core/models/location';
import { AlertService } from '@core/services/alert.service';
import { ConfigService } from '@core/services/config.service';
import { GenericRepositoryService } from '@core/services/generic-repository.service';
@Component({
  selector: 'app-location-edit',
  templateUrl: './location-edit.component.html',
  styleUrls: ['./location-edit.component.scss']
})
export class LocationEditComponent implements OnInit{
  locForm: FormGroup;
  isSubmitted: boolean=false;
  constructor(
    private _fb: FormBuilder,
    private gs:GenericRepositoryService<LocationReq>,
    private config:ConfigService,
    private alertService: AlertService, 
    private _dialogRef: MatDialogRef<LocationEditComponent>,
    @Inject(MAT_DIALOG_DATA) public data: {locationId:number},
  ) {
    this.locForm = this._fb.group({
      Id:new FormControl(''),
      Location: new FormControl('', [Validators.required]),
      LocationCode:new FormControl('', [Validators.required])
    });
  }
  get Location(){
    return this.locForm.get('Location');
  }

  get LocationCode(){
    return this.locForm.get('LocationCode');
  }
  ngOnInit(): void {
    if(this.data){
      this.gs.getById(this.config.environment.endpoints.location,this.data.locationId).subscribe({
        next:(res: LocationReq)=>{
          if(res.data){
            this.locForm.patchValue(res.data);
          }
        }
      })
    }  }
  onFormSubmit() {
    this.isSubmitted= true;
    if (this.locForm.valid) {
      if (this.data) {
        this.gs
          .update(this.config.environment.endpoints.location,this.data.locationId, this.locForm.value)
          .subscribe({
            next: (res: any) => {
              if (res && res.code === 200) {
                this.alertService.show( 'Success','Location Name updated successfully!');
                this._dialogRef.close(true);
              }else{
                this.alertService.show('Error','Location Name not updated !');
              }
              
            },
            error: (err: any) => {
              this.alertService.show('Error','Location Name not updated !');
            },
          });
      } else {
        this.gs.create(this.config.environment.endpoints.location,this.locForm.value).subscribe({
          next: (res: any) => {
            if (res && res.code === 201) {
              this.alertService.show('Success','Location Name added successfully!');
              this._dialogRef.close(true);
            }else{
              this.alertService.show('Error','Location Name not added !');
            }
            
          },
          error: (err: any) => {
            this.alertService.show('Error','Location Name not added !');
          },
        });
      }
    }
  }
}


 


