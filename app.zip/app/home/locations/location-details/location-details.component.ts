import { Component, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { LocationEditComponent } from '../location-edit/location-edit.component';
import { GenericRepositoryService } from '@core/services/generic-repository.service';
import { ConfigService } from '@core/services/config.service';
// import { LocationModel, LocationRes } from '@core/models/location';
// import { locationModel, LocationRes } from '@core/models/models_new/Location';
import { locationModel, LocationRes } from '@core/models_new/Location';
import { AlertService } from '@core/services/alert.service';


@Component({
  selector: 'app-location-details',
  templateUrl: './location-details.component.html',
  styleUrls: ['./location-details.component.scss']
})
export class LocationDetailsComponent {
  loc_list:locationModel[]=[]
  sortOrder: 'asc' | 'desc' = 'asc';
  displayedColumns: string[] = ['SNo','Location','LocationCode','CreatedBy','CreatedDateTime','ModifiedBy','ModifiedDateTime','action'] 
  dataSource: MatTableDataSource<locationModel>;
  constructor(private gs: GenericRepositoryService<LocationRes>,private config : ConfigService ,private _dialog: MatDialog,private alertService: AlertService) {
    this.dataSource = new MatTableDataSource<locationModel>();
  }
  @ViewChild(MatSort) sort!: MatSort;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
    ngOnInit(): void {
      this.getLocation();
    }
    openAddEditlocForm() {
      const dialogRef = this._dialog.open(LocationEditComponent);
      dialogRef.afterClosed().subscribe({
        next: (val) => {
          if (val) {
            this.getLocation();
            this.alertService.show('Success','Location Added Successfully!');
          }
        },
      });
    }
    getLocation() {
    this.gs.get(this.config.environment.endpoints.location).subscribe((res: LocationRes) => {
      if (res && res.code == 200) {
        res.data.sort((a:any, b:any) => {
          return new Date(b.CreatedBy).getTime() - new Date(a.CreatedBy).getTime();
        });
        this.loc_list = res.data
        this.dataSource = new MatTableDataSource(this.loc_list);
        const sort = new MatSort();
        sort.active = 'CreatedBy';
        sort.direction = 'desc';
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
      }
    });
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  deleteLocation(id: number) {
    this.gs.delete(this.config.environment.endpoints.location,id).subscribe({
      next: (res: LocationRes) => {
        if (res && res.code == 200) {
          this.alertService.show( 'Success','Deleted successfully!');
          this.getLocation();
        }
        else {
          this.alertService.show('Error','Not deleted successfully!');
        }
      },
      error: (err: any) => {
        this.alertService.show('Error','Not deleted successfully!');
      },
    });
  }
  openEditForm(locationId: string) {
    const dialogRef = this._dialog.open(LocationEditComponent, {
      data:{locationId:locationId},
    });
    dialogRef.afterClosed().subscribe({
      next: (val) => {
        if (val) {
          this.getLocation();
          this.alertService.show('Success','Location updated!');
        }
      },
    });
  }
  applySort(type: any) {
    this.sortOrder = this.sortOrder === 'asc' ? 'desc' : 'asc';
    let valueA: any;
    let valueB: any;
    this.loc_list.sort((a, b) => {
      if (type === 'ModifiedBy') {
        valueA = a?.ModifiedBy?.AssociateName;
        valueB = b?.ModifiedBy?.AssociateName;
      }
      if (this.sortOrder === 'asc') {
        return valueA < valueB ? -1 : 1;
      } else {
        return valueA > valueB ? -1 : 1;
      }
    });
  }
}
