import { ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import { LoaderService } from '@core/services/loader.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-loader',
  templateUrl: './loader.component.html',
  styleUrls: ['./loader.component.scss']
})
export class LoaderComponent implements OnInit, OnDestroy {
  showLoader = false;
  private subscription!: Subscription;

  constructor(private loaderService: LoaderService, private cdr: ChangeDetectorRef) { }

  ngOnInit(): void {
    this.subscription = this.loaderService.loaderState.subscribe((state) => {
      this.showLoader = state;
      this.cdr.detectChanges();
    });
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
