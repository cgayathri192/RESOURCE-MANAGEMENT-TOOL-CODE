import { Component, Input } from '@angular/core';
import { MatSidenav } from '@angular/material/sidenav';
import { AuthService } from '@core/services/auth.service';
import { ProfileService } from '@core/services/profile.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent {
  @Input() drawer?: MatSidenav;
  @Input() showMenuIcon: boolean= false;
  @Input() showProfile: boolean= true;
  public showInitials = false;
  public initials: string='';
  public circleColor: string='';
  constructor(private authService: AuthService, private profile:ProfileService){
    if (this.authService.isLoggedIn()) {
      let userName: string= this.authService.getTokenDetails().ResourceName;
      this.profile.createInititals(userName);
      this.showInitials = this.profile.showInitials;
      this.circleColor = this.profile.circleColor;
      this.profile.$initials.subscribe((res: string)=>{
        this.initials= res;
      });
    }
  }
  logout(): void{
    this.authService.logout();
  }
}
