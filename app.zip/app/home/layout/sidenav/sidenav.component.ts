import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Component } from '@angular/core';
import { Menu } from '@core/models/menu';
import { AuthService } from '@core/services/auth.service';
import { NavigationService } from '@core/services/navigation.service';
import { Observable, map } from 'rxjs';

@Component({
  selector: 'app-sidenav',
  templateUrl: './sidenav.component.html',
  styleUrls: ['./sidenav.component.scss']
})
export class SidenavComponent {
  menus : Menu[]=[];
  constructor(private breakpointObserver: BreakpointObserver, private navigationService: NavigationService,private authService: AuthService) {
    if (this.authService.isLoggedIn()) {
      let roleIdIsLeader: boolean= this.authService.getTokenDetails().RoleIdIsLeader;
      this.menus = this.navigationService.getMenus(roleIdIsLeader).sort((a, b) => (a.order > b.order) ? 1 : -1);
      this.menus.forEach((menu: Menu)=>{menu?.children?.sort((a, b) => (a.order > b.order) ? 1 : -1);})
    }
  }
  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches)
    );
}
