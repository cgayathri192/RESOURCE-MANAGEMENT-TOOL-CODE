import { AfterViewInit, Component, ElementRef, ViewChild, inject } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { MatDialog } from '@angular/material/dialog'
import { FormControl } from '@angular/forms';
import { GenericRepositoryService } from '@core/services/generic-repository.service';
import { SkillModel, SkillRes } from '@core/models_new/skill';
import { ConfigService } from '@core/services/config.service';
import { DatePipe } from '@angular/common';
import * as XLSX from 'xlsx';
import { JwtToken } from '@core/models/tokens';
import { AuthService } from '@core/services/auth.service';
import { AlertService } from '@core/services/alert.service';

@Component({
  selector: 'app-skills',
  templateUrl: './skills.component.html',
  styleUrls: ['./skills.component.scss']
})
export class SkillsComponent {
  fixedColumns: Column[] = [
    {ColumnName: 'SNo',DisplayName: 'Sno',DefaultLoad: true},
    {ColumnName:'EmployeeId',DisplayName:'Employee',DefaultLoad:true},
    {ColumnName:'CompetencyId',DisplayName:'Competency', DefaultLoad: true},
  ]
  allColumns : Column[] = [
  {ColumnName:'CompetencyTypeId',DisplayName:'Competency Type', DefaultLoad: true},
  {ColumnName:'CompetencyLevelId',DisplayName:'Competency Level', DefaultLoad: true},
  {ColumnName:'Primary',DisplayName:'Primary', DefaultLoad: false},
  {ColumnName:'CompetencyVersion',DisplayName:'Skill Version', DefaultLoad: false},
  {ColumnName:'ModifiedBy',DisplayName:'Modified By', DefaultLoad: false},
  {ColumnName:'CreatedAt',DisplayName:'Created At', DefaultLoad: false},
  {ColumnName:'ModifiedAt',DisplayName:'Modified At', DefaultLoad: false}
];

  displayedColumns: string[] = [...this.fixedColumns.filter((col: Column) => col.DefaultLoad).map((column: Column) => column.ColumnName), ...this.allColumns.filter((col: Column) => col.DefaultLoad).map((column: Column) => column.ColumnName)];
  Primary = new FormControl('');
  PrimaryList: any;
  EmployeeIdList:any;
  loggedInUserDetails!: JwtToken;
  CompetencyVersion = new FormControl('');
  SkillVersionList: any;
  IsActive = new FormControl('');
  IsActiveList: any;
  ModifiedBy = new FormControl('');
  ModifiedByList: any;
  CreatedAt!:string
  CompetencyTypeId = new FormControl('');
  CompetencyTypeIdList: any;
  CompetencyId = new FormControl('');
  CompetencyIdList: any;
  CompetencyLevelId = new FormControl('');
  CompetencyLevelIdList: any;
  EmployeeId = new FormControl('');
  sortOrder: 'asc' | 'desc' = 'asc';

  skill_list: SkillModel[] = [];
  dataSource!: MatTableDataSource<any>;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  @ViewChild('skilltable', { static: false }) skilltable!: ElementRef;
  skillService = inject(GenericRepositoryService<SkillRes>);
  primaryService = inject(GenericRepositoryService<SkillRes>);
  competencyService = inject(GenericRepositoryService<SkillRes>);
  competencylevelService = inject(GenericRepositoryService<SkillRes>);
  competencyIdService = inject(GenericRepositoryService<SkillRes>);
  allSelected = false;
  allSkillverSelected:boolean=true;
  allAllForComTypeIdSelected:boolean=true;
  allAllForComIdSelected:boolean=true;
  allAllForComLevIdSelected:boolean=true;
  allPrimarySelected:boolean=true;

  JSON: any;
  constructor(private _dialog: MatDialog,
    private gs: GenericRepositoryService<SkillRes>,
    private alertService: AlertService,
    private authService: AuthService,
    private config: ConfigService,private datepipe:DatePipe) {  
       this.loggedInUserDetails = this.authService.getTokenDetails();}
  ngOnInit(): void {
    this.JSON = JSON;
    this.getEmployeeListSkills();
    let controlFilters: any[] = [
    { control: this.Primary, value: 'Primary' },
    { control: this.CompetencyVersion, value: 'CompetencyVersion' },
    { control: this.IsActive, value: 'IsActive' },
    { control: this.ModifiedBy, value: 'ModifiedBy.ResourceName' },
    { control: this.CompetencyTypeId, value: 'Competency.CompetencyType.CompetencyTypeName' },
    { control: this.CompetencyId, value: 'Competency.CompetencyName' },
    { control: this.CompetencyLevelId, value: 'CompetencyLevel.CompetencyLevelName' },
    { control: this.EmployeeId, value: 'Employee.ResourceName' }
    ]

    for (var controlfilter = 0; controlfilter < controlFilters.length; controlfilter++) {
      this.applyDynamicFilter(controlFilters[controlfilter].control, controlFilters[controlfilter].value);
    }
  }
  exportToSkillExcel(): void {
    const worksheet: XLSX.WorkSheet = XLSX.utils.table_to_sheet(this.skilltable.nativeElement);
    worksheet['!autofilter'] = { ref: 'A1:AA1' };
    const hideColumnIndex = this.displayedColumns.length-1;
    const range = XLSX.utils.decode_range('A1:G6');
    range.s.c = hideColumnIndex; 
    range.e.c = hideColumnIndex; 
    for (let R = range.s.r; R <= range.e.r; ++R) {
      const cellAddress = XLSX.utils.encode_cell({ r: R, c: hideColumnIndex });
      worksheet[cellAddress]='';
      const cell = worksheet[cellAddress];
      if (cell) worksheet[cellAddress]='';
    }
    const workbook: XLSX.WorkBook = { Sheets: { data: worksheet }, SheetNames: ['data'] };
    const excelBuffer: any = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
    this.saveAsSkillExcelFile(excelBuffer, 'skills');
  
  }
  private saveAsSkillExcelFile(buffer: any, fileName: string): void {
    const data: Blob = new Blob([buffer], { type: 'application/octet-stream' });
    const url: string = window.URL.createObjectURL(data);
    const link: HTMLAnchorElement = document.createElement('a');
    link.href = url;
    link.download = `${fileName}.xlsx`;
    link.click();
    setTimeout(() => {
      window.URL.revokeObjectURL(url);
      link.remove();
    }, 100);
  }
  toggleDisplayColumns(): void {
    if ((this.displayedColumns.length - this.fixedColumns.length) === this.allColumns.length) {
      // On Select
      this.displayedColumns = [...this.fixedColumns.map(column => column.ColumnName)];
    } else {
      // On Deselect
      this.displayedColumns = [...this.fixedColumns.map(column => column.ColumnName), ...this.allColumns.map(column => column.ColumnName)];
    }
  }
  loadDropdowns(): void {
    this.loadSkills();
    this.loadPrimary();
    this.loadCompetencyType();
    this.loadCompetencyLevel();
    this.loadCompetency();
  }
  applyDynamicFilter(control: FormControl, searchproperty: any) {
    if (control) {
      control.valueChanges.subscribe((res: any) => {
        if (res && res.length > 0) {
          this.dataSource = new MatTableDataSource(this.skill_list.filter((emp: any) => {
            const propertyValue = this.getNestedPropertyValue(emp, searchproperty);
            if (searchproperty === 'Primary') {
              return res.includes(propertyValue ? 'Yes' : 'No');
            }
            return res.findIndex((r: any) => r === propertyValue) >= 0;
          }));
        }
        else {
          this.dataSource = new MatTableDataSource(this.skill_list);
        }
      })
    }
  }
  getNestedPropertyValue(object: any, propertyPath: string): any {
    return propertyPath.split('.').reduce((obj, prop) => obj && obj[prop], object);
  }
  getEmployeeListSkills() {
    this.gs.get(this.config.environment.endpoints.AssociateCompetencies).subscribe((res: SkillRes) => {
      if (res && res.code == 200) {
        res.data.sort((a, b) => {
          return new Date(b.CreatedDateTime).getTime() - new Date(a.CreatedDateTime).getTime();
        });
        this.skill_list = res.data;
        this.dataSource = new MatTableDataSource(this.skill_list);
        const sort = new MatSort();
        sort.active = 'CreatedAt';
        sort.direction = 'desc';
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
        this.selectAllFilter()
      }
    });
  }
  selectAllFilter() {
    this.PrimaryList = [...new Set(this.skill_list.map((res: SkillModel) => res.Primary ?"Yes":"No"))];
    this.SkillVersionList = [... new Set(this.skill_list.map((record:SkillModel) => record.CompetencyVersion))];
    this.ModifiedByList = [... new Set(this.skill_list.map((res: SkillModel) => res.ModifiedBy.AssociateName))];
    this.CompetencyTypeIdList = [... new Set(this.skill_list.map((res: SkillModel) => res.Competency.CompetencyType.CompetencyType))];
    this.CompetencyIdList = [... new Set(this.skill_list.map((res: SkillModel) => res.Competency.Competency))];
    this.CompetencyLevelIdList = [... new Set(this.skill_list.map((res: SkillModel) => res.CompetencyLevel.CompetencyLevel))];
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value.trim().toLowerCase();;
    this.dataSource.filter = filterValue
    this.dataSource.filterPredicate = (data:SkillModel, filter:string)=> {
      return this.filterData(data,filter);
    };
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  filterData(data: any, filter: string): boolean {
    for (const key in data) {
      if (data.hasOwnProperty(key)) {
        let value = data[key]  ?? null;
        if(key == "ModifiedAt" || key == "CreatedAt"){
          value = this.datepipe.transform(data[key], 'dd MMM, yyyy') ?? null;
        }
        if (typeof value === 'object' && value !== null) {
          if (this.filterData(value, filter)) {
            return true;
          }
        } else {
          if (value !== null && value.toString().toLowerCase().includes(filter)) {
            return true;
          }
        }
      }
    }
    return false;
  }
  deleteEmployeeSkill(id: number) {
    this.gs.delete(this.config.environment.endpoints.AssociateCompetencies, id).subscribe({
      next: (res:SkillRes) => {
        if (res && res.code == 200) {
          this.alertService.show('Success','Deleted successfully!');
          this.getEmployeeListSkills();
        }
        else {
          this.alertService.show('Error','Not deleted successfully!');
        }
      },
      error: (err: any)=>{
        this.alertService.show( 'Error','Not deleted successfully!');
       },
    })

  }

  loadSkills(): void {
    this.skillService.get(this.config.environment.endpoints.AssociateCompetencies).subscribe({
      next: (skills: SkillRes) => {
        if (skills) {
          this.SkillVersionList = [... new Set(skills.data.map((skill:SkillModel) => skill.CompetencyVersion))]
        }
        else {
          this.SkillVersionList = [];
        }
      }
    });
  }
  loadPrimary(): void {
    this.primaryService.get(this.config.environment.endpoints.AssociateCompetencies).subscribe({
      next: (skills: SkillRes) => {
        if (skills) {
          this.PrimaryList = [... new Set(skills.data.map((skill: SkillModel) => skill.Primary))]
        }
        else {
          this.PrimaryList = [];

        }
      }
    });
  }
  loadCompetencyType(): void {
    this.competencyService.get(this.config.environment.endpoints.AssociateCompetencies).subscribe({
      next: (skills: SkillRes) => {
        if (skills) {
          this.CompetencyTypeIdList = [... new Set(skills.data.map((skill: SkillModel) => skill.Competency.CompetencyType.CompetencyType))]
        }
        else {
          this.CompetencyTypeIdList = [];

        }
      }
    });
  }
  loadCompetencyLevel(): void {
    this.competencylevelService.get(this.config.environment.endpoints.AssociateCompetencies).subscribe({
      next: (skills: SkillRes) => {
        if (skills) {
          this.CompetencyLevelIdList = [... new Set(skills.data.map((skill: SkillModel) => skill.CompetencyLevel.CompetencyLevel))]

        }
        else {
          this.CompetencyLevelIdList = [];

        }
      }
    });
  }
  loadCompetency(): void {
    this.competencyIdService.get(this.config.environment.endpoints.AssociateCompetencies).subscribe({
      next: (skills: SkillRes) => {
        if (skills) {
          this.CompetencyIdList = [... new Set(skills.data.map((skill: SkillModel) => skill.Competency.Competency))]

        }
        else {
          this.CompetencyIdList = [];

        }
      }
    });
  }
  onColumnSelect(selectedColumns: string[]) {
    this.displayedColumns = [...this.fixedColumns.map(column => column.ColumnName), ...selectedColumns];
    if (selectedColumns.length !== this.allColumns.length) {
      this.displayedColumns = [...this.fixedColumns.map(column => column.ColumnName), ...selectedColumns];
    }
  }
  selectAllForSkillver(e: any) {
    this.allSkillverSelected = !this.allSkillverSelected
    if (e.checked) {
      this.CompetencyVersion.setValue(this.SkillVersionList.slice(0))
    }
    else {
      this.CompetencyVersion.setValue("");
    }
    this.dataSource.paginator = this.paginator;
  }
  selectAllForPrimary(e:any){
    this.allPrimarySelected = !this.allPrimarySelected
    if(e.checked){
      this.Primary.setValue(this.PrimaryList.slice(0))
    }
    else{
      this.Primary.setValue("");
    }
    this.dataSource.paginator = this.paginator;
  }
  selectAllForModified(e: any) {
    this.allSelected = e.checked
    if (e.checked) {
      this.ModifiedBy.setValue(this.ModifiedByList.slice(0))
    }
    else {
      this.ModifiedBy.reset();
    }
    this.dataSource.paginator = this.paginator;
  }
  
  selectAllForComTypeId(e: any) {
    this.allAllForComTypeIdSelected = !this.allAllForComTypeIdSelected
    if (e.checked) {
      this.CompetencyTypeId.setValue(this.CompetencyTypeIdList.slice(0))
    }
    else {
      this.CompetencyTypeId.setValue("");
    }
    this.dataSource.paginator = this.paginator;
  }
  selectAllForComId(e: any) {
    this.allAllForComIdSelected = !this.allAllForComIdSelected
    if (e.checked) {
      this.CompetencyId.setValue(this.CompetencyIdList.slice(0))
    }
    else {
      this.CompetencyId.setValue("");
    }
    this.dataSource.paginator = this.paginator;
  }
  selectAllForCompLevId(e: any) {
    this.allAllForComLevIdSelected = !this.allAllForComLevIdSelected
    if (e.checked) {
      this.CompetencyLevelId.setValue(this.CompetencyLevelIdList.slice(0))
    }
    else {
      this.CompetencyLevelId.setValue("");
    }
    this.dataSource.paginator = this.paginator;
  }
  checkIfAllSelected(formControl: FormControl, arrayList: []): boolean {
    if(formControl.value?.length) {
      return formControl.value.length === arrayList.length
    } else {
      return false;
    }
  }

  applySort(type: any) {
    this.sortOrder = this.sortOrder === 'asc' ? 'desc' : 'asc';
    let valueA: any;
    let valueB: any;
    this.skill_list.sort((a, b) => {
      if (type === 'ModifiedBy') {
        valueA = a?.ModifiedBy?.AssociateName;
        valueB = b?.ModifiedBy?.AssociateName;
      } else if (type === 'CompetencyTypeId') {
        valueA = a?.Competency?.CompetencyType.CompetencyType;
        valueB = b?.Competency?.CompetencyType.CompetencyType;
      } else if ( type === 'CompetencyId'){
        valueA = a?.Competency?.Competency;
        valueB = b?.Competency?.Competency;
      } else if ( type === 'CompetencyLevelId'){
        valueA = a?.CompetencyLevel?.CompetencyLevel;
        valueB = b?.CompetencyLevel?.CompetencyLevel;
      } else if ( type === 'EmployeeId'){
        valueA = a?.Associate.AssociateName;
        valueB = b?.Associate.AssociateName;
      } 

      if (this.sortOrder === 'asc') {
        return valueA < valueB ? -1 : 1;
      } else {
        return valueA > valueB ? -1 : 1;
      }
    });
  }
}
export interface Column {
  ColumnName: string;
  DisplayName: string;
  DefaultLoad: boolean;
}




