import { Component, Inject, OnInit, inject } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
// import { RoleReq, RoleRes, RolesModel } from '@core/models/role';
import { RoleReq, RoleRes, RolesModel } from '@core/models_new/role';
import { ConfigService } from '@core/services/config.service';
import { GenericRepositoryService } from '@core/services/generic-repository.service';
import { AlertService } from '@core/services/alert.service';
@Component({
  selector: 'app-role-edit',
  templateUrl: './role-edit.component.html',
  styleUrls: ['./role-edit.component.scss']
})
export class RoleEditComponent implements OnInit {
  roleForm: FormGroup;
  isSubmitted: boolean = false;
  // HierarchyList:any;
  HierarchyList!: RolesModel[];

  hierarchyService = inject(GenericRepositoryService<RoleRes>)
  constructor(
    private _fb: FormBuilder,
    private gs: GenericRepositoryService<RoleReq>,
    private config: ConfigService,
    private _dialogRef: MatDialogRef<RoleEditComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { roleId: number },
    private alertService: AlertService
  ) {
    this.roleForm = this._fb.group({
      Id: new FormControl(''),
      UserRole: new FormControl('', [Validators.required]),
      IsLeader: new FormControl(true, [Validators.required]),
      HierarchyId: new FormControl('', [Validators.required])
    });
  }
  get UserRole() {
    return this.roleForm.get('UserRole');
  }
  get IsLeader() {
    return this.roleForm.get('IsLeader');
  }
  get HierarchyId() {
    return this.roleForm.get('HierarchyId')
  }
  ngOnInit(): void {
    if (this.data) {
      this.gs.getById(this.config.environment.endpoints.role, this.data.roleId).subscribe({
        next: (res: RoleReq) => {
          if (res && res.data) {
            this.roleForm.get('Id')?.setValue(this.data.roleId);
            this.roleForm.get('HierarchyId')?.setValue(res.data.Hierarchy.Id);
            this.roleForm.get('IsLeader')?.setValue(res.data.IsLeader);
            this.roleForm.patchValue(res.data)
          }
        }
      })
    }
    this.loadDropdowns();
  }
  loadDropdowns(): void {
    this.loadHierarchyId();
  }
  loadHierarchyId() {
    this.hierarchyService.get(this.config.environment.endpoints.role).subscribe({
      next: (res: RoleRes) => {
        if (res.data) {
          this.HierarchyList = res.data;
        }
        else {
          this.HierarchyList = [];
        }
      }
    });
  }

  onFormSubmit() {
    this.isSubmitted = true;
    if (this.roleForm.valid) {
      if (this.data) {
        this.gs.update(this.config.environment.endpoints.role, this.data.roleId, this.roleForm.value)
          .subscribe({
            next: (res: any) => {
              if (res && res.code === 200) {
                this.alertService.show('Success', 'Role details updated successfully!');
                this._dialogRef.close(true);
              } else {
                this.alertService.show('Error', 'Role details not updated !');
              }

            },
            error: (err: any) => {
              this.alertService.show('Error', 'Role details not updated !');
            },
          });
      } else {
        this.gs.create(this.config.environment.endpoints.role, this.roleForm.value).subscribe({
          next: (res: any) => {
            if (res && res.code === 201) {
              this.alertService.show('Success', 'Role added successfully');
              this._dialogRef.close(true);
            } else {
              this.alertService.show('Error', 'Role not added !');
            }

          },
          error: (err: any) => {
            this.alertService.show('Error', 'Role not added !');
          },
        });
      }
    }
  }

}
