import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort, Sort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
// import { Roles,RoleRes, RolesModel} from '@core/models/role';
import { Roles, RoleRes, RolesModel } from '@core/models_new/role';
import { ConfigService } from '@core/services/config.service';
import { GenericRepositoryService } from '@core/services/generic-repository.service';
import { RoleEditComponent } from '../role-edit/role-edit.component';
import { DatePipe } from '@angular/common';
import { AlertService } from '@core/services/alert.service';
@Component({
  selector: 'app-role-details',
  templateUrl: './role-details.component.html',
  styleUrls: ['./role-details.component.scss']
})
export class RoleDetailsComponent implements OnInit {

  displayedColumns: string[] = [
    'SNo',
    'RoleName',
    'IsLeader',
    'Hierarchy',
    'CreatedAt',
    'ModifiedBy',
    'ModifiedAt',
    'action',
  ];
  role_list: RolesModel[] = [];
  sortOrder: 'asc' | 'desc' = 'asc';
  dataSource: MatTableDataSource<RolesModel>;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(
    private _dialog: MatDialog,
    private gs: GenericRepositoryService<RoleRes>,
    private config: ConfigService,
    private alertService: AlertService,
    private datepipe: DatePipe

  ) { this.dataSource = new MatTableDataSource<RolesModel>() }

  ngOnInit(): void {
    this.getRolesList();
  }
  getRolesList() {
    this.gs.get(this.config.environment.endpoints.role).subscribe((res: RoleRes) => {
      if (res && res.code == 200) {
        res.data.sort((a, b) => {
          return new Date(b.CreatedDateTime).getTime() - new Date(a.CreatedDateTime).getTime();
        });
        this.role_list = res.data;
        this.dataSource = new MatTableDataSource(this.role_list);
        const sort = new MatSort();
        sort.active = 'CreatedAt';
        sort.direction = 'desc';
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator
      }
    });
  }
  applySort(type: any) {
    this.sortOrder = this.sortOrder === 'asc' ? 'desc' : 'asc';
    let valueA: any;
    let valueB: any;
    this.role_list.sort((a, b) => {
      if (type === 'Hierarchy') {
        valueA = a?.Hierarchy?.UserRole;
        valueB = b?.Hierarchy?.UserRole;
      } else if (type === 'ModifiedBy') {
        valueA = a?.ModifiedBy?.AssociateName;
        valueB = b?.ModifiedBy?.AssociateName;
      }

      if (this.sortOrder === 'asc') {
        return valueA < valueB ? -1 : 1;
      } else {
        return valueA > valueB ? -1 : 1;
      }
    });
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value.trim().toLowerCase();;
    this.dataSource.filter = filterValue
    this.dataSource.filterPredicate = (data: RolesModel, filter: string) => {
      return this.filterData(data, filter);
    };
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  filterData(data: any, filter: string): boolean {
    for (const key in data) {
      if (data.hasOwnProperty(key)) {
        let value = data[key] ?? null;
        if (key == "ModifiedAt" || key == "CreatedAt") {
          value = this.datepipe.transform(data[key], 'dd MMM, yyyy') ?? null;
        }
        if (typeof value === 'object' && value !== null) {
          if (this.filterData(value, filter)) {
            return true;
          }
        } else {
          if (value !== null && value.toString().toLowerCase().includes(filter)) {
            return true;
          }
        }
      }
    }
    return false;
  }
  openAddEditEmpForm() {
    const dialogRef = this._dialog.open(RoleEditComponent);
    dialogRef.afterClosed().subscribe({
      next: (val) => {
        if (val) {
          this.getRolesList();
        }
      },
    });
  }

  openEditForm(roleId: string) {
    const dialogRef = this._dialog.open(RoleEditComponent, {
      data: { roleId: roleId },
    });
    dialogRef.afterClosed().subscribe({
      next: (val) => {
        if (val) {
          this.getRolesList();
        }
      },
    });
  }
  deleteRole(id: number) {
    this.gs.delete(this.config.environment.endpoints.role, id).subscribe({
      next: (res: RoleRes) => {
        if (res && res.code == 200) {
          this.alertService.show('Deleted successfully!', 'Success');
          this.getRolesList();
        }
        else {
          this.alertService.show('Not deleted!', 'Error');
        }
      },
      error: (err: any) => {
        this.alertService.show('Not deleted !', 'Error');
      },
    });
  }

}
