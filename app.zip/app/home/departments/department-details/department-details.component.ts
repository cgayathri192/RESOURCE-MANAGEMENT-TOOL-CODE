import { Component,OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
// import { DepartmentRes,DepartmentModel } from '@core/models/department';
import { DepartmentRes,DepartmentModel } from '@core/models_new/department';
import { ConfigService } from '@core/services/config.service';
import { GenericRepositoryService } from '@core/services/generic-repository.service';
import { DepartmentEditComponent } from '../department-edit/department-edit.component';
import { DatePipe } from '@angular/common';
import { AlertService } from '@core/services/alert.service';

@Component({
  selector: 'app-department-details',
  templateUrl: './department-details.component.html',
  styleUrls: ['./department-details.component.scss']
})
export class DepartmentDetailsComponent implements OnInit{

  displayedColumns: string[] = [
    'SNo',
    'PracticeId',
    'DepartmentName',
    'IsActive',
    'CreatedAt',
    'ModifiedBy',
    'ModifiedAt',
    'action',
  ];
  dataSource : MatTableDataSource<DepartmentModel>;
  sortOrder: 'asc' | 'desc' = 'asc';
  dep_list:DepartmentModel[]=[];

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(
    private _dialog: MatDialog,
    private gs : GenericRepositoryService<DepartmentRes>,
    private config : ConfigService,
    private alertService: AlertService,
    private datepipe:DatePipe
    
  ) {
    this.dataSource = new MatTableDataSource<DepartmentModel>();
  }

  ngOnInit(): void {
    this.getDepartments();
  }

  getDepartments() {
    this.gs.get(this.config.environment.endpoints.department).subscribe((res: DepartmentRes) => {
      if (res && res.code == 200) {
        res.data.sort((a, b) => {
          return new Date(b.CreatedDateTime).getTime() - new Date(a.CreatedDateTime).getTime();
        });
        this.dep_list = res.data
        this.dataSource = new MatTableDataSource(this.dep_list);
        const sort = new MatSort();
        sort.active = 'CreatedAt';
        sort.direction = 'desc';
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
      }
    });
  }
  
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value.trim().toLowerCase();;
    this.dataSource.filter = filterValue;
    this.dataSource.filterPredicate = (data:DepartmentModel, filter:string)=> {
      return this.filterData(data,filter);
    };
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  filterData(data: any, filter: string): boolean {
    for (const key in data) {
      if (data.hasOwnProperty(key)) {
        let value = data[key]  ?? null;
        if(key == "ModifiedAt" || key == "CreatedAt"){
          value = this.datepipe.transform(data[key], 'dd MMM, yyyy') ?? null;
        }
        if (typeof value === 'object' && value !== null) {
          if (this.filterData(value, filter)) {
            return true;
          }
        } else {
          if (value !== null && value.toString().toLowerCase().includes(filter)) {
            return true;
          }
        }
      }
    }
    return false;
  }
  openAddEditForm() {
    const dialogRef = this._dialog.open(DepartmentEditComponent);
    dialogRef.afterClosed().subscribe({
      next: (val) => {
        if (val) {
          this.getDepartments();
        }
      },
    });
  }

  openEditForm(departmentId: string) {
    const dialogRef = this._dialog.open(DepartmentEditComponent, {
      data:{departmentId:departmentId},
    });
    dialogRef.afterClosed().subscribe({
      next: (val) => {
        if (val) {
          this.getDepartments();
        }
      },
    });
  }

  deleteDepartment(id: number) {
    this.gs.delete(this.config.environment.endpoints.department,id).subscribe({
      next: (res: DepartmentRes) => {
        if (res && res.code == 200) {
          this.alertService.show('Success','Deleted!');
          this.getDepartments();
        }
        else {
          this.alertService.show( 'Error','Not deleted!');
        }
      },
      error: (err: any)=>{
        this.alertService.show('Error','Not deleted!', );
       },
    });
  }
  applySort(type: any) {
    this.sortOrder = this.sortOrder === 'asc' ? 'desc' : 'asc';
    let valueA: any;
    let valueB: any;
    this.dep_list.sort((a, b) => {
      if (type === 'ModifiedBy') {
        valueA = a?.ModifiedBy?.AssociateName;
        valueB = b?.ModifiedBy?.AssociateName;
      } else if (type === 'Practice') {
        valueA = a?.Practice?.Practice;
        valueB = b?.Practice?.Practice;
      } 
      if (this.sortOrder === 'asc') {
        return valueA < valueB ? -1 : 1;
      } else {
        return valueA > valueB ? -1 : 1;
      }
    });
  }

}
