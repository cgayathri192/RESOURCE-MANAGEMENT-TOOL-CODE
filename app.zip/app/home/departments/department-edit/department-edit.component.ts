import { Component,Inject, OnInit, inject } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { CoreService } from '@core/services/core.service';
// import { DepartmentReq } from '@core/models/department';
import { DepartmentReq } from '@core/models_new/department';
import { ConfigService } from '@core/services/config.service';
import { GenericRepositoryService } from '@core/services/generic-repository.service';
// import { PracticeModel, PracticeRes } from '@core/models/practice';
import { PracticeModel, PracticeRes } from '@core/models_new/practice';
import { AlertService } from '@core/services/alert.service';
@Component({
  selector: 'app-department-edit',
  templateUrl: './department-edit.component.html',
  styleUrls: ['./department-edit.component.scss']
})
export class DepartmentEditComponent implements OnInit {
  departmentForm: FormGroup;
  practiceService = inject(GenericRepositoryService<PracticeRes>)

  PracticeList!:PracticeModel[];

  isSubmitted: boolean=false;
  constructor(
    private _fb: FormBuilder,
    private gs : GenericRepositoryService<DepartmentReq>,
    private config : ConfigService,
    private _dialogRef: MatDialogRef<DepartmentEditComponent>,
    @Inject(MAT_DIALOG_DATA) public data: {departmentId: number},
    private alertService: AlertService
  ){
    this.departmentForm = this._fb.group({
      Id:new FormControl(''),
      Department: new FormControl('', [Validators.required]),
      IsActive: new FormControl(true, [Validators.required]),
      PracticeId:new FormControl('', [Validators.required]),
    });
  }
  get Department(){
    return this.departmentForm.get('Department');
  }
  get PracticeId(){
    return this.departmentForm.get('PracticeId');
  }
  get isActive(){
    return this.departmentForm.get('IsActive');
  }
  ngOnInit(): void {
    if(this.data){
      this.gs.getById(this.config.environment.endpoints.department,this.data.departmentId).subscribe({
        next:(res:DepartmentReq)=>{
          if(res && res.data){
            this.departmentForm.get('Id')?.setValue(this.data.departmentId);
            this.departmentForm.get('Department')?.setValue(res.data.Department);
            this.departmentForm.get('PracticeId')?.setValue(res.data.Practice.Id);
            this.departmentForm.get('IsActive')?.setValue(res.data.IsActive);            
          }
        }
      })
    } 
    this.loadDropdowns(); 
  }
  loadDropdowns(): void {
    this.loadPractice();
  }
  loadPractice(){
    this.practiceService.get(this.config.environment.endpoints.practice).subscribe({
      next: (res: PracticeRes) => {
        if (res.data) {
          this.PracticeList = res.data;
        }
        else {
          this.PracticeList = [];
        }
      }
    });
  }

  onFormSubmit() {
    this.isSubmitted= true;
    if (this.departmentForm.valid) {
      if (this.data) {
        this.gs.update(this.config.environment.endpoints.department,this.data.departmentId,this.departmentForm.value)
          .subscribe({
            next: (res: any) => {
              if (res && res.code === 200) {
                this.alertService.show('Success','Department detail updated successfully!');
                this._dialogRef.close(true);
              }else{
                this.alertService.show('Error','Department details not updated !');
              }
            },
            error: (err: any)=>{
              this.alertService.show('Error','Department details not updated !');
             },
          });
      } else {
        this.gs.create(this.config.environment.endpoints.department,this.departmentForm.value).subscribe({
          next: (res: any) => {
            if (res && res.code === 201) {
              this.alertService.show('Success','Department details added successfully!');
              this._dialogRef.close(true);
            }else{
              this.alertService.show('failed','Department details not added !');
            }
            
          },
          error: (err: any) => {
            this.alertService.show('failed','Department details not added !');
          },
        });
      }
    }
  }

}
