import { inject, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { SkillsComponent } from './skills_table/skills/skills.component';
import { RoleDetailsComponent } from './roles/role-details/role-details.component';
import { TitleDetailsComponent } from './title/title-details/title-details.component';
import { LocationDetailsComponent } from './locations/location-details/location-details.component';
import { PracticeDetailsComponent } from './practice/practice-details/practice-details.component';
import { DepartmentDetailsComponent } from './departments/department-details/department-details.component';
import { EmployeeDetailsComponent } from './employee/employee-details/employee-details.component';
import { CompetencyLevelComponent } from './competency_table/competency-level/competency-level.component';
import { CompetencyTypeComponent } from './competency_table/competency-type/competency-type.component';
import { CompetencyComponent } from './competency_table/competency/competency.component';
import { AuthService } from '@core/services/auth.service';
import { VisatypeComponent } from './employee/visatype/visatype.component';
import { ProfileComponent } from './profile/profile.component';
import { PassportComponent } from './employee/passport/passport.component';
import { GradeComponent } from './grade/grade.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { EmployeeViewDetailsComponent } from './employee/employee-view-details/employee-view-details.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { OrganizationChartComponent } from './organization/organization-chart/organization-chart.component';
import { EmployeeExcelImportComponent } from './employee-excel-preview/employee-excel-import/employee-excel-import.component';
import { SkillExcelPreviewComponent } from './employee-excel-preview/skill-excel/skill-excel-preview/skill-excel-preview.component';
import { AddassociateComponent } from './addassociate/addassociate.component';
const routes: Routes = [{
  path: '', component: HomeComponent,
  canActivate: [() => inject(AuthService).isLoggedIn()],
  children:[{
    path: '', component: DashboardComponent
  },
  {
    path: 'employee', component: EmployeeDetailsComponent
  },
  {
    path: 'skill', component: SkillsComponent,
    canActivate: [() => inject(AuthService).isAdmin()]
  },
  {
    path: 'role', component: RoleDetailsComponent,
    canActivate: [() => inject(AuthService).isAdmin()]
  },
  {
    path: 'location', component: LocationDetailsComponent,
    canActivate: [() => inject(AuthService).isAdmin()]
  },
  {
    path :'practice',component:PracticeDetailsComponent,
    canActivate: [() => inject(AuthService).isAdmin()]
  },
  {
    path:'competency',component:CompetencyComponent,
    canActivate: [() => inject(AuthService).isAdmin()]
  },
  {
    path:'competencytype',component:CompetencyTypeComponent,
    canActivate: [() => inject(AuthService).isAdmin()]
  },
  {
    path:'competencylevel',component:CompetencyLevelComponent,
    canActivate: [() => inject(AuthService).isAdmin()]
  },
  {
    path: 'department', component: DepartmentDetailsComponent,
    canActivate: [() => inject(AuthService).isAdmin()]
  },
  {
    path: 'title', component: TitleDetailsComponent,
    canActivate: [() => inject(AuthService).isAdmin()]
  },
  {
    path:'visatype',component:VisatypeComponent,
    canActivate: [() => inject(AuthService).isAdmin()]
  },
  {
    path:'passport',component:PassportComponent,
    canActivate: [() => inject(AuthService).isAdmin()]
  },
  {
    path:'grade',component:GradeComponent,
    canActivate: [() => inject(AuthService).isAdmin()]
  },
  {
    path:'employeeexcel',component:EmployeeExcelImportComponent,
    canActivate: [() => inject(AuthService).isAdmin()]
  },
  {
    path:'skillexcel',component:SkillExcelPreviewComponent,
    canActivate: [() => inject(AuthService).isAdmin()]
  },
 
  {
    path: 'profile',component: ProfileComponent
  },
  {
    path:'changepassword',component:ChangePasswordComponent
  },
  {
    path:'tree',component:OrganizationChartComponent
  },
  {
    path:'addAssociate', component: AddassociateComponent,   
  }
]
},
{
  path: 'login', component: LoginComponent
},
{
  path:'forgot',component:ForgotPasswordComponent
}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HomeRoutingModule { }
