import { Component, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ConfigService } from '@core/services/config.service';
import { GenericRepositoryService } from '@core/services/generic-repository.service';
import { PassportRes, PassportModel } from '@core/models_new/passport';
import { Column } from '../employee-details/employee-details.component';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-passport',
  templateUrl: './passport.component.html',
  styleUrls: ['./passport.component.scss']
})
export class PassportComponent {
  fixedColumns: Column[] = [
    { ColumnName: 'SNo', DisplayName: 'Sno', DefaultLoad: true },
    // { ColumnName: 'EmployeeId', DisplayName: 'Employee', DefaultLoad: true },
    // {ColumnName:'PassportNumber',DisplayName:'Passport Number', DefaultLoad: true},
    { ColumnName: 'PassportStatus', DisplayName: 'Passport Status', DefaultLoad: true },
    { ColumnName: 'PassportExpiry', DisplayName: 'Passport Expiry', DefaultLoad: true },
    { ColumnName: 'CreatedBy', DisplayName: 'Created By', DefaultLoad: true },
    { ColumnName: 'CreatedDateTime', DisplayName: 'CreatedDateTime', DefaultLoad: true },
    { ColumnName: 'ModifiedBy', DisplayName: 'Modified By', DefaultLoad: true },
    { ColumnName: 'ModifiedDateTime', DisplayName: 'ModifiedDateTime', DefaultLoad: true }
  ]
  allColumns: Column[] = [
    { ColumnName: 'VisaTypeId', DisplayName: 'Visa Type', DefaultLoad: false },
    { ColumnName: 'VisaStatus', DisplayName: 'Visa Status', DefaultLoad: false },
    { ColumnName: 'VisaValidity', DisplayName: 'Visa Validity', DefaultLoad: false },
    { ColumnName: 'CreatedDateTime', DisplayName: 'CreatedDateTime', DefaultLoad: false },
    { ColumnName: 'ModifiedBy', DisplayName: 'Modified By', DefaultLoad: false },
    { ColumnName: 'ModifiedDateTime', DisplayName: 'ModifiedDateTime', DefaultLoad: false }
  ];
  passport_list: PassportModel[] = [];
  sortOrder: 'asc' | 'desc' = 'asc';
  displayedColumns: string[] = [...this.fixedColumns.filter((col: Column) => col.DefaultLoad).map((column: Column) => column.ColumnName), ...this.allColumns.filter((col: Column) => col.DefaultLoad).map((column: Column) => column.ColumnName)];
  dataSource: MatTableDataSource<PassportModel>;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  constructor(private _dialog: MatDialog,
    private gs: GenericRepositoryService<PassportRes>,
    private config: ConfigService,
    private datepipe: DatePipe) {
    this.dataSource = new MatTableDataSource<PassportModel>();
  }
  ngOnInit(): void {
    this.getPassportList();
  }
  getPassportList() {
    this.gs.get(this.config.environment.endpoints.passport).subscribe({
      next: (res: PassportRes) => {
        if (res && res.code == 200) {
          res.data.sort((a, b) => {
            return new Date(b?.CreatedDateTime ?? '').getTime() - new Date(a?.CreatedDateTime ?? '').getTime();
          });
          this.passport_list = res.data
          this.dataSource = new MatTableDataSource(this.passport_list);
          const sort = new MatSort();
          sort.active = 'CreatedDateTime';
          sort.direction = 'desc';
          this.dataSource.sort = this.sort;
          this.dataSource.paginator = this.paginator;
        }
      },
    });
    console.log(this.passport_list)
  }
  toggleDisplayColumns(): void {
    if ((this.displayedColumns.length - this.fixedColumns.length) === this.allColumns.length) {
      // On Select
      this.displayedColumns = [...this.fixedColumns.map(column => column.ColumnName)];
    } else {
      // On Deselect
      this.displayedColumns = [...this.fixedColumns.map(column => column.ColumnName), ...this.allColumns.map(column => column.ColumnName)];
    }
  }
  onColumnSelect(selectedColumns: string[]) {
    this.displayedColumns = [...this.fixedColumns.map(column => column.ColumnName), ...selectedColumns];
    if (selectedColumns.length !== this.allColumns.length) {
      this.displayedColumns = [...this.fixedColumns.map(column => column.ColumnName), ...selectedColumns];
    }
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value.trim().toLowerCase();;
    this.dataSource.filter = filterValue;
    this.dataSource.filterPredicate = (data: PassportModel, filter: string) => {
      return this.filterData(data, filter);
    };
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  filterData(data: any, filter: string): boolean {
    for (const key in data) {
      if (data.hasOwnProperty(key)) {
        let value = data[key] ?? null;
        if (key == "ModifiedDateTime" || key == "CreatedDateTime") {
          value = this.datepipe.transform(data[key], 'dd MMM, yyyy') ?? null;
        }
        if (typeof value === 'object' && value !== null) {
          if (this.filterData(value, filter)) {
            return true;
          }
        } else {
          if (value !== null && value.toString().toLowerCase().includes(filter)) {
            return true;
          }
        }
      }
    }
    return false;
  }
  applySort(type: any) {
    this.sortOrder = this.sortOrder === 'asc' ? 'desc' : 'asc';
    let valueA: any;
    let valueB: any;
    this.passport_list.sort((a, b) => {
      if (type === 'EmployeeId') {
        valueA = a?.Associate?.AssociateName;
        valueB = b?.Associate?.AssociateName;
      } else if (type === 'ModifiedBy') {
        valueA = a?.ModifiedBy?.AssociateName;
        valueB = b?.ModifiedBy?.AssociateName;
      }

      if (this.sortOrder === 'asc') {
        return valueA < valueB ? -1 : 1;
      } else {
        return valueA > valueB ? -1 : 1;
      }
    });
  }
}
