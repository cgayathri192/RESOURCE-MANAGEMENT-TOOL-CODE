import { DatePipe } from '@angular/common';
import { Component, inject, Inject } from '@angular/core';
import { AbstractControl, FormArray, FormBuilder, FormControl, FormGroup, ValidatorFn, Validators } from '@angular/forms';
import {  DateAdapter, MAT_DATE_FORMATS } from '@angular/material/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialog } from '@angular/material/dialog';
import { AppDateAdapter, APP_DATE_FORMATS } from '@core/common/dateAdapter';
import { CompetencyModel, CompetencyRes } from '@core/models/competency';
import { CompetencylevelModel, CompetencylevelRes } from '@core/models/competencylevel';
import { CompetencyTypeModel, CompetencyTypeRes } from '@core/models/competencytype';
import { DepartmentModel, DepartmentRes } from '@core/models/department';
import { CompetencyType, Employee, EmployeeModel, EmployeeReq, EmployeeRes, Passport, Skill } from '@core/models/employee';
import { GradeModel } from '@core/models/grade';
import { GradeRes } from '@core/models/grade';
import { LocationRes, LocationModel } from '@core/models/location';
import { MttenurityRes } from '@core/models/mttenurity';
import { MttenurityModel } from '@core/models/mttenurity';
import { PracticeModel, PracticeRes } from '@core/models/practice';
import { RoleRes, RolesModel } from '@core/models/role';
import { TitleModel, TitleRes } from '@core/models/title';
import { VisatypeModel, VisatypeRes } from '@core/models/visatype';
import { AlertService } from '@core/services/alert.service';
import { ConfigService } from '@core/services/config.service';
import { GenericRepositoryService } from '@core/services/generic-repository.service';
import { throwIfEmpty } from 'rxjs';
@Component({
  selector: 'app-employee-edit',
  templateUrl: './employee-edit.component.html',
  styleUrls: ['./employee-edit.component.scss'],
  providers: [
    { provide: DateAdapter, useClass: AppDateAdapter },
    { provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS },
  ],
})
export class EmployeeEditComponent {
  empForm: FormGroup;
  isSubmitted: boolean = false;
  leaderService = inject(GenericRepositoryService<EmployeeRes>)
  reportingService = inject(GenericRepositoryService<EmployeeRes>)
  departmentService = inject(GenericRepositoryService<DepartmentRes>);
  locationService = inject(GenericRepositoryService<LocationRes>);
  rolesService = inject(GenericRepositoryService<RoleRes>);
  practiceService = inject(GenericRepositoryService<PracticeRes>);
  titleService = inject(GenericRepositoryService<TitleRes>);
  competencyTypeService = inject(GenericRepositoryService<CompetencyTypeRes>);
  competencyService = inject(GenericRepositoryService<CompetencyRes>);
  competencyLevelService = inject(
    GenericRepositoryService<CompetencylevelModel>
  );
  visaTypeService = inject(GenericRepositoryService<VisatypeModel>);
  mtTenurityService = inject(GenericRepositoryService<MttenurityModel>);
  gradeService = inject(GenericRepositoryService<GradeModel>);
  DepartmentList!: DepartmentModel[];
  LeadershipTeamList!: EmployeeModel[];
  ReportingList!: EmployeeModel[];
  LocationList!: LocationModel[];
  RolesList!: RolesModel[];
  PracticeList!: PracticeModel[];
  TitleList!: TitleModel[];
  VisaTypeList!: VisatypeModel[];
  CompetencyTypeList!: CompetencyTypeModel[];
  CompetencyList!: CompetencyModel[];
  CompetencyLevelList!: CompetencylevelModel[];
  MtTenurityList!: MttenurityModel[];
  GradeList!: GradeModel[];
  departmentListforDropdown!: DepartmentModel[];
  competencyListforDropdown: CompetencyModel[][]= [];
  reportingListforDropdown:EmployeeModel[]=[];
  genders = [
    { value: 'Male', viewValue: 'Male' },
    { value: 'Female', viewValue: 'Female' },
  ];
  isActives = [
    { values: true, isActiveValue: 'Active' },
    { values: false, isActiveValue: 'Inactive' },
  ];
  isPrimaryList = [
    { values: true, isActiveValue: 'Yes' },
    { values: false, isActiveValue: 'No' },
  ];
  enablePassport: boolean = false;
  skillRemoved: number[] = [];
  maxDate: Date;
  visaVisable: boolean = true;
  visaButtonsOptions: string[] = ['Yes', 'No'];
  defaultOption = 'Yes'
  isTitleChanged:boolean=false;    
  ReportingListOptions!: EmployeeModel[];
  LeadershipTeamOptions!: EmployeeModel[];
  formBuilder: any;
  hide: boolean= true;
  constructor(
    private _fb: FormBuilder,
    private gs: GenericRepositoryService<Employee>,
    private gsreq: GenericRepositoryService<EmployeeReq>,
    private config: ConfigService,
    private _dialogRef: MatDialogRef<EmployeeEditComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { employeeId: number, competencyList: CompetencyModel[] },
    private alertService: AlertService,
    private datepipe: DatePipe,
    private fb: FormBuilder,
    public dialog: MatDialog
  ) {
    this.maxDate = new Date();
    let passportValidator = this.enablePassport ?  [Validators.required]: null;
    let employeeId: number = this.data ? this.data.employeeId : 0;
    this.empForm = this._fb.group({
      ResourceName: new FormControl('', [Validators.required]),
      Email: new FormControl('', [Validators.required, this.customEmailValidator()]),
      DateOfBirth: new FormControl('', [Validators.required]),
      DateOfJoining: new FormControl('', [Validators.required]),
      Gender: new FormControl('', [Validators.required]),
      GradeId: new FormControl('', [Validators.required]),
      IsActive: new FormControl(true, [Validators.required]),
      EmployeeCompanyId: new FormControl('', [Validators.required]),
      RoleId: new FormControl('', [Validators.required]),
      TitleId: new FormControl('', [Validators.required]),
      LocationId: new FormControl('', [Validators.required]),
      PracticeId: new FormControl('', [Validators.required]),
      DepartmentId: new FormControl('', [Validators.required]),
      LeadershipTeam: new FormControl('', { validators: [autocompleteObjectValidator(), Validators.required] }),
      ReportingManager: new FormControl('',{ validators: [this.reportingMangerValidator(), Validators.required] }),
      MouriTechTenurityId: new FormControl('', [Validators.required]),
      Skills: this.fb.array([]),
      Passport: this.fb.group({
        Id: 0,
        EmployeeId: employeeId,
        PassportNumber: new FormControl('',passportValidator),
        PassportExpiry: new FormControl('',passportValidator),
        PassportStatus: new FormControl('',passportValidator),
        VisaValidity: new FormControl('',passportValidator),
        VisaTypeId: new FormControl('',passportValidator),
        VisaStatus: new FormControl('',passportValidator)
      })
    });
  }
  get ResourceName() {
    return this.empForm.get('ResourceName');
  }
  get Email() {
    return this.empForm.get('Email');
  }
  get Password() {
    return this.empForm.get('password');
  }
  get DateOfBirth() {
    return this.empForm.get('DateOfBirth');
  }
  get Gender() {
    return this.empForm.get('Gender');
  }
  get IsActive() {
    return this.empForm.get('IsActive');
  }
  get RoleId() {
    return this.empForm.get('RoleId');
  }
  get PracticeId() {
    return this.empForm.get('PracticeId');
  }
  get DepartmentId() {
    return this.empForm.get('DepartmentId');
  }
  get TitleId() {
    return this.empForm.get('TitleId');
  }
  get LeadershipTeam() {
    return this.empForm.get('LeadershipTeam');
  }
  get ReportingManager() {
    return this.empForm.get('ReportingManager');
  }
  get EmployeeCompanyId() {
    return this.empForm.get('EmployeeCompanyId');
  }
  get LocationId() {
    return this.empForm.get('LocationId');
  }
  get DateOfJoining() {
    return this.empForm.get('DateOfJoining');
  }
  get MouriTechTenurityId() {
    return this.empForm.get('MouriTechTenurityId');
  }
  get GradeId() {
    return this.empForm.get('GradeId');
  }
  get ProjectStatus() {
    return this.empForm.get('ProjectStatus.Projectstatus');
  }
  get MouriTechExperience() {
    return this.empForm.get('MouriTechExperience');
  }
  customEmailValidator() {
    const emailPattern = /\.in@mouritech\.com$/i;
    return (control: any) => {
      const email = control.value;
      if (email && !email.match(emailPattern)) {
        return { invalidEmail: true };
      }
      return null;
    };
  }
  ngOnInit(): void {
    if (this.DepartmentId?.value) {
      this.ondepartmentOptionChange({ value: this.DepartmentId.value });
    }
    if (this.data) {
      this.gsreq
        .getById(
          this.config.environment.endpoints.employee,
          this.data.employeeId
        )
        .subscribe({
          next: (res: EmployeeReq) => {
            if (res && res.data) {
              this.empForm.patchValue(res.data);
              this.empForm.get('GradeId')?.setValue(res.data.Grade.Id);
              this.empForm.get('RoleId')?.setValue(res.data.Role.Id);
              this.empForm.get('LocationId')?.setValue(res.data.Location.Id);
              this.empForm.get('PracticeId')?.setValue(res.data.Practice.Id);
              this.empForm.get('TitleId')?.setValue(res.data.Title.Id);
              this.empForm
                .get('DepartmentId')
                ?.setValue(res.data.Department.Id);
              this.empForm
                .get('MouriTechTenurityId')
                ?.setValue(res.data.MouriTechTenurity.Id);
                this.visaVisable = res.data.Passport?.VisaType ?true : false;
                this.defaultOption= res.data.Passport?.VisaType ?"Yes" : "No";
              if (res.data.Passport) {
                this.enablePassport = true;
                let passport: Passport = {
                  Id: res.data.Passport.Id,
                  EmployeeId: res.data.Passport.EmployeeId,
                  PassportExpiry: res.data.Passport.PassportExpiry,
                  VisaTypeId: res.data.Passport?.VisaType ? res.data.Passport?.VisaType.Id: null,
                  PassportNumber: res.data.Passport.PassportNumber,
                  VisaValidity: res.data.Passport?.VisaValidity,
                  PassportStatus: res.data.Passport.PassportStatus,
                  VisaStatus: res.data.Passport?.VisaStatus,
                };
                this.empForm.get('Passport')?.setValue(passport);
                let visaValidator = this.visaVisable ?  [Validators.required]: null;
                this.empForm.get('Passport.VisaValidity')?.setValidators(visaValidator);
                this.empForm.get('Passport.VisaTypeId')?.setValidators(visaValidator);
                this.empForm.get('Passport.VisaStatus')?.setValidators(visaValidator);
              }
              if (res.data.Skills && res.data.Skills.length > 0) {
                res.data.Skills.forEach((skillRes,index : number) => {
                  if (skillRes) {
                    this.competencyListforDropdown[index]= this.getCompetencylist(skillRes.Competency.CompetencyType, this.data.competencyList)
                    let skillform = this.fb.group({
                      Id: skillRes.Id,
                      EmployeeId: skillRes.EmployeeId,
                      SkillVersion: new FormControl(skillRes.SkillVersion, [Validators.required]),
                      CompetencyTypeId: new FormControl(skillRes.Competency.CompetencyType.Id, [Validators.required]),
                      CompetencyId: new FormControl(skillRes.Competency.Id, [Validators.required]),
                      CompetencyLevelId: new FormControl(
                        skillRes.CompetencyLevel.Id
                      ),
                      Primary: new FormControl(skillRes.Primary),
                    });
                    this.skills.push(skillform);
                  }
                });
              }
            }
          },
        });
    }
    this.empForm
      .get('DateOfJoining')
      ?.valueChanges.subscribe((DateOfJoining: string) => {
        let tenurity: string = '';
        if (DateOfJoining && this.MtTenurityList) {
          this.calculateTenure(DateOfJoining);
        }
      });
    this.loadDropdowns();
    this.ReportingManager?.valueChanges.subscribe((searchValue: string) => {
      
      if(this.RoleId?.value && this.RoleId?.value === 1 || this.RoleId?.value && this.RoleId?.value === 2){
        this.reportingListforDropdown = this.ReportingList.filter(
          (reportingManager) => reportingManager.Role.Id === 1 
        );
      } else if(this.RoleId?.value) {
        if(this.DepartmentId?.value){
          this.reportingListforDropdown=this.ReportingList.filter(
            (reportingManager) => reportingManager.Role.Id < this.RoleId?.value && reportingManager.Department.Id ==this.DepartmentId?.value
          );
        } else {
          this.reportingListforDropdown = this.ReportingList.filter(
            (reportingManager) => reportingManager.Role.Id < this.RoleId?.value
          );
        }
      }
      if (searchValue && searchValue.length > 0) {
        this.ReportingListOptions = this.reportingListforDropdown.filter((reporting: EmployeeModel) =>
          reporting.ResourceName.toLowerCase().includes(searchValue.toLowerCase())
        );
        this.reportingListforDropdown=this.ReportingListOptions;
      }
      else{
        this.ReportingListOptions = this.reportingListforDropdown;
      }
    });
    this.LeadershipTeam?.valueChanges.subscribe((searchValue: string) => {
      if (searchValue && searchValue.length > 0) {
        this.LeadershipTeamOptions = this.ReportingList.filter((reporting: EmployeeModel) =>
          reporting.ResourceName.toLowerCase().includes(searchValue.toLowerCase())  && reporting.Role.IsLeader == true
        );
      }
      else{
        this.LeadershipTeamOptions = this.ReportingList?.filter((reporting: EmployeeModel) =>reporting.Role.IsLeader == true);
      }
    });
    if (this.GradeId && this.DepartmentId) {
      this.GradeId?.valueChanges.subscribe(() => {
        this.loadEmployeeTitles();
      });
      this.DepartmentId?.valueChanges.subscribe(() => {
        this.loadEmployeeTitles();
        this.ReportingManager?.updateValueAndValidity();
      });
    }
    this.RoleId?.valueChanges.subscribe(() => {
      this.ReportingManager?.updateValueAndValidity();
    });
  }
  getCompetencylist(competencyType: CompetencyType, competencyList: CompetencyModel[]): CompetencyModel[] {
    return competencyList.filter((m:CompetencyModel)=> m.CompetencyType.Id== competencyType.Id) || [];
  }
  loadEmployeeTitles(): void {
    if (this.TitleList) {
      let titles: TitleModel[] = this.TitleList.filter((t: TitleModel) => t.Grade.Id == this.GradeId?.value);
      if (titles && titles.length == 1) {
        this.TitleId?.setValue(titles[0].Id)
      }
      else if (titles && titles.length > 1) {
        titles = this.TitleList.filter((t: TitleModel) => t.Grade.Id == this.GradeId?.value && t.Department.Id == this.DepartmentId?.value);
        this.TitleId?.setValue(titles[0]?.Id)
      }
      else {
        this.TitleId?.setValue(null);
      }
    }
  }
  calculateTenure(dateOfJoining: string) {
    if (dateOfJoining) {
      const now = new Date();
      const joinDate = new Date(dateOfJoining);
      const diffInMilliseconds = Math.abs(now.getTime() - joinDate.getTime());

      const years = Math.floor(diffInMilliseconds / (1000 * 60 * 60 * 24 * 365));

      for (const range of this.MtTenurityList) {
        const rangeValues = range.MouriTechTenurityGroup.split('-');
        const lowerBound = parseInt(rangeValues[0], 10);
        const upperBound = parseInt(rangeValues[1], 10);

        if (years >= lowerBound && (years < upperBound || !upperBound)) {
          this.empForm.controls['MouriTechTenurityId'].setValue(range.Id)
          break;
        }
      }
    } else {
      this.empForm.controls['MouriTechTenurityId'].setValue(null);
    }
  }
  loadDropdowns(): void {
    this.loadRoles();
    this.loadPractice();
    this.loadDepartment();
    this.loadTitle();
    this.loadLocation();
    this.loadCompetencyType();
    this.loadCompetency();
    this.loadCompetencyLevel();
    this.loadVisaType();
    this.loadMtTenurity();
    this.loadGrade();
    this.loadLeadership();
    this.loadReporting();
  }
  loadReporting() {
    this.reportingService
      .get(this.config.environment.endpoints.employee)
      .subscribe({
        next: (res: EmployeeRes) => {
          if (res && res.data) {
            this.ReportingList = res.data;
            this.ReportingListOptions = res.data;
            this.LeadershipTeamOptions = res.data.filter((reporting: EmployeeModel) =>reporting.Role.IsLeader == true);
            this.reportingListforDropdown = this.ReportingList;
          } else {
            this.ReportingList = [];
            this.ReportingListOptions = [];
            this.LeadershipTeamOptions = [];
          }
        },
      });
  }
  loadLeadership() {
    this.leaderService
      .get(this.config.environment.endpoints.employee)
      .subscribe({
        next: (res: EmployeeRes) => {
          if (res && res.data) {
            this.LeadershipTeamList = res.data;
          } else {
            this.LeadershipTeamList = [];
          }
        },
      });
  }
  loadPractice() {
    this.practiceService
      .get(this.config.environment.endpoints.practice)
      .subscribe({
        next: (res: PracticeRes) => {
          if (res && res.data) {
            this.PracticeList = res.data;
          } else {
            this.PracticeList = [];
          }
        },
      });
  }
  loadDepartment() {
    this.departmentService
      .get(this.config.environment.endpoints.department)
      .subscribe({
        next: (res: DepartmentRes) => {
          if (res && res.data) {
            this.DepartmentList = res.data.filter(record => record.IsActive)
            this.departmentListforDropdown = this.DepartmentList;
          } else {
            this.DepartmentList = [];
          }
        },
      });
  }
  loadTitle() {
    this.titleService.get(this.config.environment.endpoints.title).subscribe({
      next: (res: TitleRes) => {
        if (res && res.data) {
          this.TitleList = res.data;
        } else {
          this.TitleList = [];
        }
      },
    });
  }
  loadLocation() {
    this.locationService
      .get(this.config.environment.endpoints.location)
      .subscribe({
        next: (res: LocationRes) => {
          if (res && res.data) {
            this.LocationList = res.data;
          } else {
            this.LocationList = [];
          }
        },
      });
  }
  loadRoles() {
    this.rolesService.get(this.config.environment.endpoints.role).subscribe({
      next: (res: RoleRes) => {
        if (res && res.data) {
          this.RolesList = res.data;
        } else {
          this.RolesList = [];
        }
      },
    });
  }
  loadCompetencyType() {
    this.competencyTypeService
      .get(this.config.environment.endpoints.competencytype)
      .subscribe({
        next: (res: CompetencyTypeRes) => {
          if (res && res.data) {
            this.CompetencyTypeList = res.data;
          } else {
            this.CompetencyTypeList = [];
          }
        },
      });
  }
  loadCompetency() {
    this.competencyService
      .get(this.config.environment.endpoints.competency)
      .subscribe({
        next: (res: CompetencyRes) => {
          if (res && res.data) {
            this.CompetencyList = res.data;
          } else {
            this.CompetencyList = [];
          }
        },
      });
  }
  loadCompetencyLevel() {
    this.competencyService
      .get(this.config.environment.endpoints.competencylevel)
      .subscribe({
        next: (res: CompetencylevelRes) => {
          if (res && res.data) {
            this.CompetencyLevelList = res.data;
          } else {
            this.CompetencyLevelList = [];
          }
        },
      });
  }
  loadVisaType() {
    this.visaTypeService
      .get(this.config.environment.endpoints.visatype)
      .subscribe({
        next: (res: VisatypeRes) => {
          if (res && res.data) {
            this.VisaTypeList = res.data;
          } else {
            this.VisaTypeList = [];
          }
        },
      });
  }
  loadMtTenurity() {
    this.mtTenurityService
      .get(this.config.environment.endpoints.mttenurity)
      .subscribe({
        next: (res: MttenurityRes) => {
          if (res && res.data) {
            this.MtTenurityList = res.data;
          } else {
            this.MtTenurityList = [];
          }
        },
      });
  }
  loadGrade() {
    this.gradeService.get(this.config.environment.endpoints.grade).subscribe({
      next: (res: GradeRes) => {
        if (res && res.data) {
          this.GradeList = res.data;
        } else {
          this.GradeList = [];
        }
      },
    });
  }
  onFormSubmit() {
    this.isSubmitted = true;
    if (this.empForm.valid) {
      let employeeObj: Employee = this.empForm.value;
      employeeObj.DateOfBirth =
        this.datepipe
          .transform(this.empForm.value.DateOfBirth, 'yyyy-MM-dd')
          ?.toString() ?? '';
      employeeObj.DateOfJoining =
        this.datepipe
          .transform(this.empForm.value.DateOfJoining, 'yyyy-MM-dd')
          ?.toString() ?? '';
      employeeObj.LeadershipTeamId = this.empForm.value.LeadershipTeam?.Id;
      employeeObj.ReportingManagerId = this.empForm.value.ReportingManager?.Id;
      if (this.enablePassport == false) {
        employeeObj.Passport = null;
      } else {
        employeeObj.Passport = {
          Id: employeeObj.Passport?.Id ?? 0,
          EmployeeId: employeeObj.Passport?.EmployeeId ?? 0,
          PassportNumber: employeeObj.Passport?.PassportNumber ?? '',
          PassportStatus: employeeObj.Passport?.PassportStatus ?? false,
          PassportExpiry:
            this.datepipe
              .transform(employeeObj.Passport?.PassportExpiry, 'yyyy-MM-dd')
              ?.toString() ?? '',
          VisaStatus: employeeObj.Passport?.VisaStatus ?? null,
          VisaValidity:
            this.datepipe
              .transform(employeeObj.Passport?.VisaValidity, 'yyyy-MM-dd')
              ?.toString() ?? null,
          VisaTypeId: employeeObj.Passport?.VisaTypeId ?? null,
        };
      }
      if (this.data) {
        employeeObj.SkillsRemoved = this.skillRemoved;
        this.gs
          .update(
            this.config.environment.endpoints.employee,
            this.data.employeeId,
            employeeObj
          )
          .subscribe({
            next: (res: any) => {
              if (res && res.code === 200) {
                this.alertService.show('Success','Employee detail updated!');
              this._dialogRef.close(true);
              }else{
                this.alertService.show(
                  'Error', 'Employee Not updated !'
                  
                );
              }
              
            },
            error: (err: any) => {
              this.alertService.show(
                'Error','Employee Not updated !'
                
              );
            },
          });
      } else {
        this.gs
          .create(
            this.config.environment.endpoints.employeeRegistration,
            employeeObj
          )
          .subscribe({
            next: (res: any) => {
              if (res && res.code === 201) {
                this.alertService.show('Success','Employee added successfully!');
                this._dialogRef.close(true);
              }else{
                this.alertService.show(
                  'Error','Employee Not added !'
                 
                );
              }
             
            },
            error: (err: any) => {
              this.alertService.show(
                'Error', 'Employee Not added !'
                
              );
            },
          });
      }
    }
  }
  get skills() {
    return this.empForm.get('Skills') as FormArray;
  }

  addSkill() {
    let employeeId: number = this.data ? this.data.employeeId : 0;
    const skill = this.fb.group({
      Id: 0,
      EmployeeId: employeeId,
      SkillVersion: new FormControl('',[Validators.required]),
      CompetencyTypeId: new FormControl('',[Validators.required]),
      CompetencyId: new FormControl('',[Validators.required]),
      CompetencyLevelId: new FormControl('',[Validators.required]),
      Primary: new FormControl('',[Validators.required]),
    });
    this.skills.push(skill);
  }

  removeSkill(index: number) {
    const removedSkill: Skill = this.skills.at(index).value;
    if (removedSkill && removedSkill.Id != 0) {
      this.skillRemoved.push(removedSkill.Id);
    }
    this.skills.removeAt(index);
  }
  togglePassport() {
    this.enablePassport = !this.enablePassport;
    if (this.enablePassport) {
      this.visaVisable=true;
      this.defaultOption= "Yes";
      this.empForm.get("Passport.PassportNumber")?.setValidators([Validators.required]);
      this.empForm.get("Passport.PassportExpiry")?.setValidators([Validators.required]);
      this.empForm.get("Passport.PassportStatus")?.setValidators([Validators.required]);
      this.empForm.get("Passport.VisaValidity")?.setValidators([Validators.required]);
      this.empForm.get("Passport.VisaTypeId")?.setValidators([Validators.required]);
      this.empForm.get("Passport.VisaStatus")?.setValidators([Validators.required]);
    } else {
      this.empForm.get("Passport.PassportNumber")?.clearValidators();
      this.empForm.get("Passport.PassportNumber")?.updateValueAndValidity();
      this.empForm.get("Passport.PassportExpiry")?.clearValidators();
      this.empForm.get("Passport.PassportExpiry")?.updateValueAndValidity();
      this.empForm.get("Passport.PassportStatus")?.clearValidators();
      this.empForm.get("Passport.PassportStatus")?.updateValueAndValidity();
      this.empForm.get("Passport.VisaValidity")?.clearValidators();
      this.empForm.get("Passport.VisaValidity")?.updateValueAndValidity();
      this.empForm.get("Passport.VisaTypeId")?.clearValidators();
      this.empForm.get("Passport.VisaTypeId")?.updateValueAndValidity();
      this.empForm.get("Passport.VisaStatus")?.clearValidators();
      this.empForm.get("Passport.VisaStatus")?.updateValueAndValidity();
    }
  }
  onpractiseOptionChange(event: any) {
    this.departmentListforDropdown = this.DepartmentList.filter(
      (department) => department.Practice.Id == event.value
    );
    this.reportingListforDropdown=this.ReportingList.filter(
      (reportingManager) => reportingManager.Practice.Id == event.value
    );
    throwIfEmpty
    this.ReportingManager?.setValue(null);
  }
  ondepartmentOptionChange(event:any){
      this.reportingListforDropdown = this.ReportingList.filter(
        (reportingManager) => reportingManager.Department.Id == event.value
      );
    this.ReportingManager?.setValue(null);
  }
  oncompetencyTypeOptionChange(event: any, index: number) {
    this.competencyListforDropdown[index] = this.CompetencyList.filter(
      (competency) => competency.CompetencyType.Id == event.value
    );
  }
  getCompetencyOptions(index: number): CompetencyModel[] {
    return this.competencyListforDropdown[index] || [];
    
  }
  visaButton(event: string) {
    if (event == 'Yes') {
      this.visaVisable = true;
      this.empForm.get('Passport.VisaValidity')?.setValidators([Validators.required]);
      this.empForm.get('Passport.VisaTypeId')?.setValidators([Validators.required]);
      this.empForm.get('Passport.VisaStatus')?.setValidators([Validators.required]);
    } else {
      this.visaVisable = false;
      this.empForm.get('Passport.VisaTypeId')?.setValue(null)
      this.empForm.get('Passport.VisaStatus')?.setValue(null)
      this.empForm.get('Passport.VisaValidity')?.setValue(null)
      this.empForm.get('Passport.VisaValidity')?.clearValidators();
      this.empForm.get('Passport.VisaValidity')?.updateValueAndValidity();
      this.empForm.get('Passport.VisaTypeId')?.clearValidators();
      this.empForm.get('Passport.VisaTypeId')?.updateValueAndValidity();
      this.empForm.get('Passport.VisaStatus')?.clearValidators();
      this.empForm.get('Passport.VisaStatus')?.updateValueAndValidity();
    }
  }
  displayFn(emp: EmployeeModel): string {
    return emp && emp.ResourceName ? emp.ResourceName : '';
  }
  closeDialog() {
    this._dialogRef.close();
  }
  reportingMangerValidator(): ValidatorFn {
    return (control: AbstractControl): { [key: string]: any } | null => {
      if (typeof control.value === 'string') {
        return { 'invalidAutocompleteObject': { value: control.value } }
      }
      else if (typeof control.value !== 'string') {
        let isLeader: boolean= this.RoleId?.value ? this.RolesList?.filter((m)=> m.Id== this.RoleId?.value)[0].IsLeader|| false: false;
         if(control.value?.Department?.Id != this.DepartmentId?.value && !isLeader){
            return { 'invalidDepartment': { value: control.value } }
         }
      }
      return null  /* valid option selected */
    }
  }
}

function autocompleteObjectValidator(): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } | null => {
    if (typeof control.value === 'string') {
      return { 'invalidAutocompleteObject': { value: control.value } }
    }
    return null  /* valid option selected */
  }
}