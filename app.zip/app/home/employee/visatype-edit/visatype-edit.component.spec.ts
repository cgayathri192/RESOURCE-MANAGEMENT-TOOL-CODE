import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VisatypeEditComponent } from './visatype-edit.component';

describe('VisatypeEditComponent', () => {
  let component: VisatypeEditComponent;
  let fixture: ComponentFixture<VisatypeEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VisatypeEditComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(VisatypeEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
