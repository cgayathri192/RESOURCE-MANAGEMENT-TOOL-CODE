import { Component, Inject, inject } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ConfigService } from '@core/services/config.service';
import { GenericRepositoryService } from '@core/services/generic-repository.service';
// import { VisatypeReq } from '@core/models/visatype';
import { VisatypeModel, visaTypeReq, visaTypeRes } from '@core/models_new/visatype';
import { AlertService } from '@core/services/alert.service';

@Component({
  selector: 'app-visatype-edit',
  templateUrl: './visatype-edit.component.html',
  styleUrls: ['./visatype-edit.component.scss']
})
export class VisatypeEditComponent {
  visaForm: FormGroup;
  isSubmitted: boolean = false;
  constructor(
    private _fb: FormBuilder,
    private gs: GenericRepositoryService<visaTypeReq>,
    private config: ConfigService,
    private _dialogRef: MatDialogRef<VisatypeEditComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { visatypeId: number },
    private alertService: AlertService
  ) {
    this.visaForm = this._fb.group({
      Id: new FormControl(''),
      VisaType: new FormControl('', [Validators.required]),
      IsActive: new FormControl(true, [Validators.required]),
    });
  }
  get VisaType() {
    return this.visaForm.get('VisaType');
  }
  get isActive() {
    return this.visaForm.get('IsActive');
  }

  ngOnInit(): void {
    if (this.data) {
      this.gs.getById(this.config.environment.endpoints.visatype, this.data.visatypeId).subscribe({
        next: (res: visaTypeReq) => {
          if (res && res.data) {
            this.visaForm.get('Id')?.setValue(this.data.visatypeId);
            this.visaForm.get('VisaType')?.setValue(res.data.VisaType);
            this.visaForm.get('IsActive')?.setValue(res.data.IsActive);
          }
        }
      })
    }
  }
  onFormSubmit() {
    this.isSubmitted = true;
    if (this.visaForm.valid) {
      if (this.data) {
        this.gs.update(this.config.environment.endpoints.visatype, this.data.visatypeId, this.visaForm.value)
          .subscribe({
            next: (res: any) => {
              if (res && res.code === 200) {
                this.alertService.show('Success', 'VisaType detail updated successfully!');
                this._dialogRef.close(true);
              } else {
                this.alertService.show('Error', 'VisaType detail not updated !');
              }

            },
            error: (err: any) => {
              this.alertService.show('Error', 'VisaType detail not updated !');
            },
          });
      } else {
        this.gs.create(this.config.environment.endpoints.visatype, this.visaForm.value).subscribe({
          next: (res: any) => {
            if (res && res.code === 201) {
              this.alertService.show('Success', 'VisaType added successfully!');
              this._dialogRef.close(true);
            } else {
              this.alertService.show('Error', 'VisaType not added !');
            }

          },
          error: (err: any) => {
            this.alertService.show('Error', 'VisaType not added !');
          },
        });
      }
    }
  }

}
