import { Component, ElementRef, inject, TemplateRef, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { MatDialog } from '@angular/material/dialog';
import { EmployeeEditComponent } from '@home-module/employee/employee-edit/employee-edit.component';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import * as XLSX from 'xlsx';
import { GenericRepositoryService } from '@core/services/generic-repository.service';
import { ConfigService } from '@core/services/config.service';
import { EmployeeRes, Grade, EmployeeModel } from '@core/models_new/employee';
import { Roles, RoleRes } from '@core/models_new/role';
import { Practice, PracticeRes } from '@core/models_new/practice';
import { DepartmentModel, DepartmentRes } from '@core/models_new/department';
import { Location, LocationRes } from '@core/models_new/Location';
import { TitleModel, TitleRes } from '@core/models_new/title';
import { DateAdapter, MAT_DATE_FORMATS } from '@angular/material/core';
import { AppDateAdapter, APP_DATE_FORMATS } from '@core/common/dateAdapter';
import { Mttenurity } from '@core/models_new/mttenurity';
import { GradeRes } from '@core/models_new/grade';
import { JwtToken } from '@core/models/tokens';
import { AuthService } from '@core/services/auth.service';
import { EmployeeViewDetailsComponent } from '../employee-view-details/employee-view-details.component';
import { EmployeeRelieveComponent } from '../employee-relieve/employee-relieve.component';
import { CompetencyModel, CompetencyRes } from '@core/models_new/competency';
import { DatePipe } from '@angular/common';
import { Route, Router } from '@angular/router';
@Component({
  selector: 'app-employee-details',
  templateUrl: './employee-details.component.html',
  styleUrls: ['./employee-details.component.scss'],
  providers: [
    { provide: DateAdapter, useClass: AppDateAdapter },
    { provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS },
  ],
})
export class EmployeeDetailsComponent {
  fixedColumns: Column[] = [
    { ColumnName: 'SNo', DisplayName: 'Sno', DefaultLoad: true },
    { ColumnName: 'EmployeeCompanyId', DisplayName: 'EmployeeCompanyId', DefaultLoad: true },
    { ColumnName: 'ResourceName', DisplayName: 'Resource name', DefaultLoad: true},
    { ColumnName: 'Department', DisplayName: 'Department', DefaultLoad: true },
  ];
  allColumns: Column[] = [
    { ColumnName: 'Role', DisplayName: 'Role', DefaultLoad: true },
    { ColumnName: 'Email', DisplayName: 'Email', DefaultLoad: false },
    { ColumnName: 'DateOfBirth', DisplayName: 'Date of birth', DefaultLoad: false},
    { ColumnName: 'Gender', DisplayName: 'Gender', DefaultLoad: false },
    { ColumnName: 'DateOfJoining', DisplayName: 'Date of joining',DefaultLoad: false},
    { ColumnName: 'LeadershipTeam',DisplayName: 'Leadership Team',DefaultLoad: false},
    { ColumnName: 'Practice', DisplayName: 'Practice', DefaultLoad: true },
    { ColumnName: 'Location', DisplayName: 'Location', DefaultLoad: false },
    { ColumnName: 'MouriTechTenurity',DisplayName: 'MOURI Tech Tenurity', DefaultLoad: false},
    { ColumnName: 'Title', DisplayName: 'Title', DefaultLoad: false },
    { ColumnName: 'Grade', DisplayName: 'Grade', DefaultLoad: false },
    { ColumnName: 'ReportingManager',DisplayName: 'Reporting Manager',DefaultLoad: false},
    { ColumnName: 'IsActive', DisplayName: 'Status', DefaultLoad: false },
    { ColumnName: 'ModifiedBy', DisplayName: 'Modified By', DefaultLoad: false},
    { ColumnName: 'ModifiedDate', DisplayName: 'Modified Date',DefaultLoad: false},
    { ColumnName: 'MouriTechExperience',DisplayName: 'MOURI Tech Experience',DefaultLoad: true},
  ];
  actionColumn: Column = { ColumnName: 'action',DisplayName: 'Action',DefaultLoad: true };
  displayedColumns: string[] = [...this.fixedColumns.filter((col: Column) => col.DefaultLoad).map((column: Column) => column.ColumnName),...this.allColumns.filter((col: Column) => col.DefaultLoad).map((column: Column) => column.ColumnName),].concat(this.actionColumn.ColumnName);
  filterSelectObj = [];
  allSelected = false;
  empForm!: FormGroup;
  loggedInUserDetails!: JwtToken;
  employeeDetails!: EmployeeModel;
  MouriTechExperience = new FormControl('');
  MouriTechExperienceList: any;
  MouriTechTenurity = new FormControl('');
  MouriTechTenurityList: any=[];
  Grade = new FormControl('');
  GradeList: any;
  IsActive = new FormControl('');
  Role = new FormControl('');
  Gender = new FormControl('');
  Title = new FormControl('');
  Location = new FormControl('');
  Practice = new FormControl('');
  Department = new FormControl('');
  LeadershipTeam = new FormControl('');
  ReportingManager = new FormControl('');
  ModifiedBy = new FormControl('')
  IsActiveList: any;
  emplist: EmployeeModel[] = [];
  dataSource!: MatTableDataSource<EmployeeModel>;

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  @ViewChild('employeetable', { static: false }) employeetable!: ElementRef;
  RolesList: any;
  ReportingManagerList: any;
  ActiveList: any;
  GenderList: any;
  TitleList: any;
  LocationList: any;
  PracticeList: any;
  DepartmentList: any;
  LeadershipTeamList: any;
  ExpList: any;
  selectedMouriTechExperience: string[] = [];
  rolesService = inject(GenericRepositoryService<RoleRes>);
  gradeService = inject(GenericRepositoryService<GradeRes>);
  mtExperienceService = inject(GenericRepositoryService<EmployeeRes>);
  activeService = inject(GenericRepositoryService<EmployeeRes>);
  practiceService = inject(GenericRepositoryService<PracticeRes>);
  departmentService = inject(GenericRepositoryService<DepartmentRes>);
  locationService = inject(GenericRepositoryService<LocationRes>);
  titleService = inject(GenericRepositoryService<TitleRes>);
  competencyService = inject(GenericRepositoryService<CompetencyRes>);
  sortOrder: 'asc' | 'desc' = 'asc';

  searchInput: any;
  showRelieveForm: boolean = false;
  reason!: string;
  selectedDate!: Date;
  allLeaders: any[] = [];
  allRolesSelected: boolean = true;
  allTitlesSelected: boolean = true;
  allLocationsSelected: boolean = true;
  allPracticesSelected: boolean = true;
  allLeadersSelected: boolean = true;
  allReportingSelected: boolean = true;
  allDepartmentsSelected: boolean = true;
  allActivesSelected: boolean = true;
  allMtTenuritySelected: boolean = true;
  allGenderSelected: boolean = true;
  allExperienceSelected: boolean = true;
  allMtGradeSelected: boolean = true;
  allMtExpSelected: boolean = true;
  dateOfJoiningRange = new FormGroup({
    start: new FormControl(null),
    end: new FormControl(null),
  });
  dateOfBirthRange = new FormGroup({
    start: new FormControl(null),
    end: new FormControl(null),
  });
  ModifiedDateRange = new FormGroup({
    start: new FormControl(null),
    end: new FormControl(null),
  });
  competencyList: CompetencyModel[] = [];
  MtTenurityList: Mttenurity[]=[
    {
      MouriTechTenurityGroup: "0-2"
    },
    {
      MouriTechTenurityGroup: "2-4"
    },
    {
      MouriTechTenurityGroup: "4-6"
    },
    {
      MouriTechTenurityGroup: "6-8"
    },
    {
      MouriTechTenurityGroup: "8-10"
    },
    {
      MouriTechTenurityGroup: "10+"
    }
  
  ];

  constructor(
    private router:Router,
    private _dialog: MatDialog,
    private gs: GenericRepositoryService<EmployeeRes>,
    private config: ConfigService,
    private authService: AuthService,
    private datepipe:DatePipe
  ) {
    this.loggedInUserDetails = this.authService.getTokenDetails();
  }
  calculateMouriTechExperience(date: string): string {
    const dateOfJoining = new Date(date);
    const currentDate = new Date();
    const diffTime = Math.abs(currentDate.getTime() - dateOfJoining.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    const years = Math.floor(diffDays / 365);
    const months = Math.floor((diffDays % 365) / 30);
    let experience;
    if (years && months) {
      if (years === 1 && months === 1) {
        experience = `${years} year ${months} month`;
      } else if (years === 1 && months !== 1) {
        experience = `${years} year ${months} months`;
      } else {
        experience = `${years} years ${months} months`;
      }
    } else {
      if (years) {
        if (years === 1) {
          experience = `${years} year`;
        } else {
          experience = `${years} years`;
        }
      } else {
        if (months) {
          experience = `${months} month`;
        } else if (months === 1) {
          experience = `${months} month`;
        } else {
          experience = `${months}`;
        }
      }
    }
    return experience;
  }

  ngOnInit(): void {
    this.loadDropdowns(); 
    this.getEmployeeList();
    let controlFilters: any[] = [
      { control: this.MouriTechExperience, value: 'MouriTechExperience' },
      { control: this.MouriTechTenurity, value: 'MouriTechTenurity'},
      { control: this.Grade, value: 'Grade.GradeName' },
      { control: this.IsActive, value: 'IsActive' },
      { control: this.Role, value: 'Role.RoleName' },
      { control: this.Gender, value: 'Gender' },
      { control: this.Title, value: 'Title.TitleName' },
      { control: this.Location, value: 'Location.LocationName' },
      { control: this.Practice, value: 'Practice.PracticeName' },
      { control: this.Department, value: 'Department.DepartmentName' },
      { control: this.LeadershipTeam, value: 'ResourceName' },
      { control: this.ReportingManager,value:'ReportingManager.ResourceName'},
      { control: this.ModifiedBy,value: 'ModifiedBy.ResourceName'}
    ];
    for (var controlfilter = 0; controlfilter < controlFilters.length; controlfilter++) {
      this.applyDynamicFilter(controlFilters[controlfilter].control, controlFilters[controlfilter].value);
    }
    this.dateOfJoiningRange.valueChanges.subscribe((formValues: any) => {
      if (formValues.start && formValues.end) {
        this.dataSource = new MatTableDataSource(this.emplist.filter((emp: any) => {
            let employeeDOJ = new Date(emp.DateOfJoining);
            let startDate = new Date(formValues.start);
            let endDate = new Date(formValues.end);
            endDate.setDate(endDate.getDate() + 1);
            return employeeDOJ >= startDate && employeeDOJ < endDate;
          })
        );
      } else {
        this.dataSource = new MatTableDataSource(this.emplist);
        this.dataSource.paginator = this.paginator;
      }
    });
    this.dateOfBirthRange.valueChanges.subscribe((formValues: any) => {
      if (formValues.start && formValues.end) {
        this.dataSource = new MatTableDataSource(this.emplist.filter((emp: any) => {
            let employeeDOB = new Date(emp.DateOfBirth);
            let startDate = new Date(formValues.start);
            let endDate = new Date(formValues.end);
            endDate.setDate(endDate.getDate() + 1);
            return employeeDOB >= startDate && employeeDOB < endDate;
          })
        );
      } else {
        this.dataSource = new MatTableDataSource(this.emplist);
        this.dataSource.paginator = this.paginator;
      }
    });
    this.ModifiedDateRange.valueChanges.subscribe((formValues: any) => {
      if (formValues.start && formValues.end) {
        this.dataSource = new MatTableDataSource(this.emplist.filter((emp: any) => {
            let employeeMDate = new Date(emp.ModifiedAt);
            let startDate = new Date(formValues.start);
            let endDate = new Date(formValues.end);
            endDate.setDate(endDate.getDate() + 1);
            return employeeMDate >= startDate && employeeMDate < endDate;
          })
        );
      } else {
        this.dataSource = new MatTableDataSource(this.emplist);
        this.dataSource.paginator = this.paginator;
      }
    });
    this.filterEmp();
  } 
  toggleDisplayColumns(): void {
    if (this.displayedColumns.length - (this.fixedColumns.length + 1) === this.allColumns.length) {
      this.displayedColumns = [...this.fixedColumns.map((column) => column.ColumnName)].concat(this.actionColumn.ColumnName);
    } else {
      this.displayedColumns = [...this.fixedColumns.map((column) => column.ColumnName), ...this.allColumns.map((column) => column.ColumnName)].concat(this.actionColumn.ColumnName);
    }
  }

  calculateTenure(dateOfJoining: string): string {
    let tenurity=''
    if (dateOfJoining) {
      const now = new Date();
      const joinDate = new Date(dateOfJoining);
      const diffInMilliseconds = Math.abs(now.getTime() - joinDate.getTime());

      const years = Math.floor(diffInMilliseconds / (1000 * 60 * 60 * 24 * 365));

      for (const range of this.MtTenurityList) {
        const rangeValues = range.MouriTechTenurityGroup.split('-');
        const lowerBound = parseInt(rangeValues[0], 10);
        const upperBound = parseInt(rangeValues[1], 10);
        if (years >= lowerBound && (years < upperBound || !upperBound)) {
          tenurity=range.MouriTechTenurityGroup;
        }
      }
    } else {
      tenurity='';
    }
    return tenurity;
  }

  loadDropdowns(): void {
    this.loadRoles();
    this.loadPractices();
    this.loadDepartments();
    this.loadLocations();
    this.loadTitles();
    this.loadGrades();
    this.loadCompetency();
  }
  loadCompetency() {
    this.competencyService
      .get(this.config.environment.endpoints.competency)
      .subscribe({
        next: (res: CompetencyRes) => {
          if (res && res.data) {
            this.competencyList = res.data;
          } else {
            this.competencyList = [];
          }
        },
      });
  }
  loadMouriTechExperience(): void {
    const expArray: string[] = [];
    this.emplist?.map((emp: any, i: number) => {
      const dateOfJoining = new Date(emp.DateOfJoining).toString();
      let presence = this.emplist.findIndex((ele) => new Date(ele.DateOfJoining).toString() === dateOfJoining);
      if (presence === i) {
        expArray.push(this.calculateMouriTechExperience(dateOfJoining));
      }
    });
    if (expArray.length) {
      this.MouriTechExperienceList = [...new Set(expArray)];
    } else {
      this.MouriTechExperienceList = [];
    }
  }
  loadRoles(): void {
    this.rolesService.get(this.config.environment.endpoints.role).subscribe({
      next: (roles: RoleRes) => {
        if (roles && roles.data.length > 0) {
          this.RolesList = roles.data.map((role: Roles) => role.UserRole);
        } else {
          this.RolesList = [];
        }
      },
    });
  }
  loadGrades(): void {
    this.gradeService.get(this.config.environment.endpoints.grade).subscribe({
      next: (grades: GradeRes) => {
        if (grades && grades.data.length > 0) {
          this.GradeList = grades.data.map((grade: Grade) => grade.Grade);
        } else {
          this.GradeList = [];
        }
      },
    });
  }

  loadPractices(): void {
    this.practiceService.get(this.config.environment.endpoints.practice).subscribe({
        next: (practices: PracticeRes) => {
          if (practices && practices.data.length > 0) {
            this.PracticeList = practices.data.map((practice: Practice) => practice.Practice);
          } else {
            this.PracticeList = [];
          }
        },
      });
  }
  loadDepartments(): void {
    this.departmentService.get(this.config.environment.endpoints.department).subscribe({
        next: (departments: DepartmentRes) => {
          if (departments && departments.data.length > 0) {
            this.DepartmentList = departments.data.map((department: DepartmentModel) => department.Department);
          } else {
            this.DepartmentList = [];
          }
        },
      });
  }
  loadTitles(): void {
    this.titleService.get(this.config.environment.endpoints.title).subscribe({
      next: (titles: TitleRes) => {
        if (titles && titles.data.length > 0) {
          this.TitleList = titles.data.map((title: TitleModel) => title.Title);
        } else {
          this.TitleList = [];
        }
      },
    });
  }
  loadLocations(): void {
    this.locationService.get(this.config.environment.endpoints.location).subscribe({
        next: (locations: LocationRes) => {
          if (locations && locations.data.length > 0) {
            this.LocationList = locations.data.map((location: Location) => location.Location);
          } else {
            this.LocationList = [];
          }
        },
      });
  }
  applyDynamicFilter(control: FormControl, searchproperty: any) {
    if (control) {
      control.valueChanges.subscribe((res: any) => {
        if (res && res.length > 0) {
          this.dataSource = new MatTableDataSource(this.emplist.filter((emp: any) => {
              const propertyValue = this.getNestedPropertyValue(emp, searchproperty);
              return res.findIndex((r: any) => r === propertyValue) >= 0;
            })
          );
        } else {
          this.dataSource = new MatTableDataSource(this.emplist);
        }
      });
    }
  }
  getNestedPropertyValue(object: any, propertyPath: string): any {
    return propertyPath.split('.').reduce((obj, prop) => obj && obj[prop], object);
  }
  addEmployeeForm() {
    this.router.navigate(['addAssociate']);
    // const dialogRef = this._dialog.open(EmployeeEditComponent,{
    //     maxWidth: '100vw',
    // });
    // dialogRef.afterClosed().subscribe({
    //   next: (val) => {
    //     if (val) {
    //       this.getEmployeeList();
    //     }
    //   },
    // });
  }
  getEmployeeList() {
    this.gs.get(this.config.environment.endpoints.associate).subscribe({
      next: (res: EmployeeRes) => {
        if (res && res.data.length > 0) {
          this.ActiveList = [...new Set(res.data.map((emloyee: EmployeeModel) => emloyee.IsActive))];
          res.data.sort((a, b) => {
            return new Date(b.ModifiedDateTime).getTime() - new Date(a.ModifiedDateTime).getTime();
          });
          res.data.forEach( (emp) => (emp['MouriTechExperience'] = this.calculateMouriTechExperience(emp.DateOfJoining)));  
          res.data.forEach( (emp) => (emp['MouriTechTenurity'] = this.calculateTenure(emp.DateOfJoining)));  
          
          this.emplist = res.data;
          this.dataSource = new MatTableDataSource(this.emplist);
          const sort = new MatSort();
          sort.active = 'CreatedAt';
          sort.direction = 'desc';
          this.dataSource.sort = this.sort;
          this.dataSource.paginator = this.paginator;
          this.filterEmp();
          this.loadMouriTechExperience();
        }
      },
    });
  }
  filterEmp() {
    this.IsActiveList = [{'key':'Yes','value':true},{'key':'No','value':false}];
    this.LeadershipTeamList = [...new Set(this.emplist.map((res: any) => res.ResourceName)),];
    this.ReportingManagerList = [...new Set(this.emplist.map((res: any) => res.ReportingManager.ResourceName)),];
    this.GenderList = [...new Set(this.emplist.map((res: any) => res.Gender)),];
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue?.trim().toLowerCase();
    this.dataSource.filterPredicate = (data:EmployeeModel, filter:string)=> {
      return this.filterData(data,filter);
    };
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  filterData(data: any, filter: string): boolean {
    for (const key in data) {
      if (data.hasOwnProperty(key)) {
        let value = data[key]  ?? null;
        if(key == "ModifiedAt" || key == "CreatedAt"){
          value = this.datepipe.transform(data[key], 'dd MMM, yyyy') ?? null;
        }
        if (typeof value === 'object' && value !== null) {
          if (this.filterData(value, filter)) {
            return true;
          }
        } else {
          if (value !== null && value.toString().toLowerCase().includes(filter)) {
            return true;
          }
        }
      }
    }
    return false;
  }
  openEditForm(employee:EmployeeModel) {
    if (this.loggedInUserDetails.RoleIdIsLeader===false) {
      const data = this._dialog.open(EmployeeViewDetailsComponent,{  
        width: '65vw',
        data: { employee: employee }
      });
    } else {
      const dialogRef = this._dialog.open(EmployeeEditComponent, {
        width: '65vw',
        data: { employeeId: employee.Id, competencyList : this.competencyList }
      });
      dialogRef.afterClosed().subscribe({
        next: (val) => {
          if (val) {
            this.getEmployeeList();
          }
        },
      });
    }
  }
  
  exportToExcel(): void {
  const worksheet: XLSX.WorkSheet = XLSX.utils.table_to_sheet(this.employeetable.nativeElement);
  worksheet['!autofilter'] = { ref: 'A1:AA1' };
  const hideColumnIndex = this.displayedColumns.length-1;
  const range = XLSX.utils.decode_range('A1:G6');
  range.s.c = hideColumnIndex; 
  range.e.c = hideColumnIndex; 
  for (let R = range.s.r; R <= range.e.r; ++R) {
    const cellAddress = XLSX.utils.encode_cell({ r: R, c: hideColumnIndex });
    worksheet[cellAddress]='';
    const cell = worksheet[cellAddress];
    if (cell) worksheet[cellAddress]='';
  }
  const workbook: XLSX.WorkBook = { Sheets: { data: worksheet }, SheetNames: ['data'] };
  const excelBuffer: any = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
  this.saveAsExcelFile(excelBuffer, 'Associates');
}

  private saveAsExcelFile(buffer: any, fileName: string): void {
    const data: Blob = new Blob([buffer], { type: 'application/octet-stream' });
    const url: string = window.URL.createObjectURL(data);
    const link: HTMLAnchorElement = document.createElement('a');
    link.href = url;
    link.download = `${fileName}.xlsx`;
    link.click();
    setTimeout(() => {
      window.URL.revokeObjectURL(url);
      link.remove();
    }, 100);
  }
  onColumnSelect(selectedColumns: string[]) {
    this.displayedColumns = [...this.fixedColumns.map((column) => column.ColumnName), ...selectedColumns].concat(this.actionColumn.ColumnName);
    if (selectedColumns.length !== this.allColumns.length) {
      this.displayedColumns = [...this.fixedColumns.map((column) => column.ColumnName), ...selectedColumns].concat(this.actionColumn.ColumnName);
    }
  }
  selectAllForMouriTechExperience(e: any) {
    this.allExperienceSelected = !this.allExperienceSelected;
    if (e.checked) {
      this.MouriTechExperience.setValue(this.MouriTechExperienceList.slice(0));
    } else {
      this.MouriTechExperience.setValue('');
    }
    this.dataSource.paginator = this.paginator;
  }
  selectAllForRole(e: any) {
    this.allRolesSelected = !this.allRolesSelected;
    if (e.checked) {
      this.Role.setValue(this.RolesList.slice(0));
    } else {
      this.Role.setValue('');
    }
    this.dataSource.paginator = this.paginator;
  }
  selectAllForTitle(e: any) {
    this.allTitlesSelected = !this.allTitlesSelected;
    if (e.checked) {
      this.Title.setValue(this.TitleList.slice(0));
    } else {
      this.Title.setValue('');
    }
    this.dataSource.paginator = this.paginator;
  }
  selectAllForLocation(e: any) {
    this.allLocationsSelected = !this.allLocationsSelected;
    if (e.checked) {
      this.Location.setValue(this.LocationList.slice(0));
    } else {
      this.Location.setValue('');
    }
    this.dataSource.paginator = this.paginator;
  }
  selectAllForDepartment(e: any) {
    this.allDepartmentsSelected = !this.allDepartmentsSelected;
    if (e.checked) {
      this.Department.setValue(this.DepartmentList.slice(0));
    } else {
      this.Department.setValue('');
    }
    this.dataSource.paginator = this.paginator;
  }
  selectAllForPractice(e: any) {
    this.allPracticesSelected = !this.allPracticesSelected;
    if (e.checked) {
      this.Practice.setValue(this.PracticeList.slice(0));
    } else {
      this.Practice.setValue('');
    }
    this.dataSource.paginator = this.paginator;
  }
  selectAllForGender(e: any) {
    this.allGenderSelected = !this.allGenderSelected;
    if (e.checked) {
      this.Gender.setValue(this.GenderList.slice(0));
    } else {
      this.Gender.setValue('');
    }
    this.dataSource.paginator = this.paginator;
  }
  selectAllForLeadershipTeam(e: any) {
    this.allLeadersSelected = !this.allLeadersSelected;
    if (e.checked) {
      this.LeadershipTeam.setValue(this.LeadershipTeamList.slice(0));
    } else {
      this.LeadershipTeam.setValue('');
    }
    this.dataSource.paginator = this.paginator;
  }
  selectAllForReportingManager(e: any) {
    this.allReportingSelected = !this.allReportingSelected;
    if (e.checked) {
      this.ReportingManager.setValue(this.ReportingManagerList.slice(0));
    } else {
      this.ReportingManager.setValue('');
    }
    this.dataSource.paginator = this.paginator;
  }
  applySort(type: any) {
    this.sortOrder = this.sortOrder === 'asc' ? 'desc' : 'asc';
    let valueA: any;
    let valueB: any;
    this.emplist.sort((a, b) => {
      if (type === 'UserRole') {
        valueA = a?.UserRole?.UserRole;
        valueB = b?.UserRole?.UserRole;
      } else if (type === 'Practice') {
        valueA = a?.Practice?.Practice;
        valueB = b?.Practice?.Practice;
      } else if ( type === 'Department'){
        valueA = a?.Department?.Department;
        valueB = b?.Department?.Department;
      } else if ( type === 'Location'){
        valueA = a?.Location?.Location;
        valueB = b?.Location?.Location;
      } else if ( type === 'Title'){
        valueA = a?.Title?.Title;
        valueB = b?.Title?.Title;
      } else if ( type === 'Grade'){
        valueA = a?.Grade?.Grade;
        valueB = b?.Grade?.Grade;
      } else if( type === 'LeadershipTeam'){
        valueA = a?.LeadershipTeam?.AssociateName
        valueB = b?.LeadershipTeam?.AssociateName
      } else if ( type === 'ReportingManager'){
        valueA = a?.ReportingManager?.AssociateName
        valueB = b?.ReportingManager?.AssociateName
      }
       else if ( type === 'MouriTechTenurity'){
        valueA = a?.MouriTechTenurity
        valueB = b?.MouriTechTenurity
      }
      else if ( type === 'ModifiedBy'){
        valueA = a?.ModifiedBy?.AssociateName
        valueB = b?.ModifiedBy?.AssociateName
      }

      if (this.sortOrder === 'asc') {
        return valueA < valueB ? -1 : 1;
      } else {
        return valueA > valueB ? -1 : 1;
      }
    });
  }
  selectAllForActive(e: any) {
    this.allActivesSelected = !this.allActivesSelected;
    if (e.checked) {
      this.IsActive.setValue(this.ActiveList.slice(0));
    } else {
      this.IsActive.setValue('');
    }
    this.dataSource.paginator = this.paginator;
  }
  selectAllForMtTenurity(event: any) {
    this.allMtTenuritySelected = !this.allMtTenuritySelected;
    if (event.checked) {
      this.MouriTechTenurity.setValue(this.MouriTechTenurityList.slice(0));
    } else {
      this.MouriTechTenurity.setValue('');
    }
    this.dataSource.paginator = this.paginator;
  }

  selectAllForMtGrade(e: any) {
    this.allMtGradeSelected = !this.allMtGradeSelected;
    if (e.checked) {
      this.Grade.setValue(this.GradeList.slice(0));
    } else {
      this.Grade.setValue('');
    }
    this.dataSource.paginator = this.paginator;
  }
  clearDateOfJoiningRange(): void {
    this.dateOfJoiningRange.reset();
  }
  clearDateOfBirthRange(): void {
    this.dateOfBirthRange.reset();
  }
  clearModifiedDateRange(): void {
    this.ModifiedDateRange.reset();
  }
  lookUp(e: any) {}
  openRelieveForm(row: any) {
    const dialogRef = this._dialog.open(EmployeeRelieveComponent, {
      width: '300px',
      data: {row:row}    
    });
    dialogRef.afterClosed().subscribe((res) => {
      this.getEmployeeList();
    });
    
  }

  checkIfAllSelected(formControl: FormControl, arrayList: []): boolean {
    if (formControl.value?.length) {
      return formControl.value.length === arrayList.length;
    } else {
      return false;
    }
  }
}
export interface Column {
  ColumnName: string;
  DisplayName: string;
  DefaultLoad: boolean;
}