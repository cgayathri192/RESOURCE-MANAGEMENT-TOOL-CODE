import { Component, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
// import { VisatypeModel, VisatypeRes } from '@core/models/visatype';
import { VisatypeModel, visaTypeReq, visaTypeRes } from '@core/models_new/visatype';

import { ConfigService } from '@core/services/config.service';
import { GenericRepositoryService } from '@core/services/generic-repository.service';
import { VisatypeEditComponent } from '../visatype-edit/visatype-edit.component';
import { DatePipe } from '@angular/common';
import { AlertService } from '@core/services/alert.service';

@Component({
  selector: 'app-visatype',
  templateUrl: './visatype.component.html',
  styleUrls: ['./visatype.component.scss']
})
export class VisatypeComponent {
  displayedColumns: string[] = [
    'SNo',
    'VisaType',
    'IsActive',
    'CreatedBy',
    'ModifiedBy',
    'ModifiedDateTime',
    'action'
  ];
  ModifiedBy = new FormControl('');
  ModifiedByList: visaTypeRes[] = [];
  CreatedBy!: string
  IsActive = new FormControl('');
  IsActiveList: visaTypeRes[] = [];

  dataSource!: MatTableDataSource<VisatypeModel>;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  ModifiedDateTime!: string;
  VisaType!: string;
  constructor(private _dialog: MatDialog,
    private gs: GenericRepositoryService<visaTypeRes>,
    private alertService: AlertService,
    private datepipe: DatePipe,
    private config: ConfigService) { }
  ngOnInit(): void {
    this.getVisaTypeList();
  }
  getVisaTypeList() {
    this.gs.get(this.config.environment.endpoints.visatype).subscribe((res: visaTypeRes) => {
      if (res && res.code == 200) {
        console.log(res, 'kjhgfd')
        res.data.sort((a, b) => {
          return new Date(b.CreatedBy).getTime() - new Date(a.CreatedBy).getTime();
        });
        this.dataSource = new MatTableDataSource(res.data);
        const sort = new MatSort();
        sort.active = 'CreatedBy';
        sort.direction = 'desc';
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
      }
    });
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value.trim().toLowerCase();;
    this.dataSource.filter = filterValue
    this.dataSource.filterPredicate = (data: VisatypeModel, filter: string) => {
      return this.filterData(data, filter);
    };
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  filterData(data: any, filter: string): boolean {
    for (const key in data) {
      if (data.hasOwnProperty(key)) {
        let value = data[key] ?? null;
        if (key == "ModifiedDateTime" || key == "CreatedBy") {
          value = this.datepipe.transform(data[key], 'dd MMM, yyyy') ?? null;
        }
        if (typeof value === 'object' && value !== null) {
          if (this.filterData(value, filter)) {
            return true;
          }
        } else {
          if (value !== null && value.toString().toLowerCase().includes(filter)) {
            return true;
          }
        }
      }
    }
    return false;
  }
  openVisaForm() {
    const dialogRef = this._dialog.open(VisatypeEditComponent);
    dialogRef.afterClosed().subscribe({
      next: (val) => {
        if (val) {
          this.getVisaTypeList();
        }
      },
    });
  }
  openEditForm(visatypeId: number) {
    const dialogRef = this._dialog.open(VisatypeEditComponent, {
      data: { visatypeId: visatypeId },
    });
    dialogRef.afterClosed().subscribe({
      next: (val) => {
        if (val) {
          this.getVisaTypeList();
        }
      },
    });
  }
  deleteVisatype(id: number) {
    this.gs.delete(this.config.environment.endpoints.visatype, id).subscribe({
      next: (res: visaTypeRes) => {
        if (res && res.code == 200) {
          this.alertService.show('Success', 'Deleted!');
          this.getVisaTypeList();
        }
        else {
          this.alertService.show('Error', 'Not deleted!');
        }
      },
      error: (err: any) => {
        this.alertService.show('Error', 'Not deleted!');
      },
    });
  }
}
