import { Component,Inject, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
import { RelieveRes } from '@core/models/relieve';
import { AlertService } from '@core/services/alert.service';
import { ConfigService } from '@core/services/config.service';
import { GenericRepositoryService } from '@core/services/generic-repository.service';

@Component({
  selector: 'app-employee-relieve',
  templateUrl: './employee-relieve.component.html',
  styleUrls: ['./employee-relieve.component.scss']
})
export class EmployeeRelieveComponent {
  relievingReason!:string;
  relievedAt!:Date;
  relieveForm!:FormGroup;
  constructor(private _dialog:MatDialogRef<EmployeeRelieveComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any, 
  private gs: GenericRepositoryService<RelieveRes>,
  private config: ConfigService,
  private alertService: AlertService,
  private _fb: FormBuilder,){
    this.relieveForm = this._fb.group({
      EmployeeId:this.data.row.Id,
      RelievingReason: new FormControl('', [Validators.required]),
      RelievedAt: new FormControl('', [Validators.required]),
    });
  }
  onFormSubmit(): void {
    this.gs
    .create(
      this.config.environment.endpoints.relieve,this.relieveForm.value).subscribe({
      next: (val: any) => {
        this.alertService.show('Success','Employee Relieved successfully');
        this._dialog.close(true);
      },
      error: (err: any) => {
        this.alertService.show('Error','Employee not Relieved !');
      },
    });
     this._dialog.close();
    } 
  onCancel(): void { 
    
    this._dialog.close(); 
  }
 
}
