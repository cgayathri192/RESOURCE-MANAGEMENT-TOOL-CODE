import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { EmployeeModel } from '@core/models_new/employee';


@Component({
  selector: 'app-employee-view-details',
  templateUrl: './employee-view-details.component.html',
  styleUrls: ['./employee-view-details.component.scss']
})
export class EmployeeViewDetailsComponent implements OnInit{
  employeeDetails!:EmployeeModel
  constructor( 
    @Inject(MAT_DIALOG_DATA) public data: { employee: EmployeeModel },
  ) {}
  ngOnInit(){
    this.employeeDetails=this.data.employee
  }
}
