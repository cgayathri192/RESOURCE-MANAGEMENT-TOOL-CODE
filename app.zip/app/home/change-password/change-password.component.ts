import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators,} from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '@core/services/auth.service';
import { AlertService } from '@core/services/alert.service';
@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.scss'],
})
export class ChangePasswordComponent implements OnInit {
  isSubmitted: boolean = false;
  changePasswordGroup: FormGroup;
  passwordsMatch = true;
  errorMessage: string | undefined;
  hideOldpassword: boolean = true;
  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router,
    private alertService: AlertService
  ) {
    this.changePasswordGroup = this.fb.group({
      oldpassword: new FormControl('', [Validators.required]),
      newpassword: new FormControl('', [Validators.required]),
      confirmpassword: new FormControl('', [Validators.required]),
    });
  }
  ngOnInit(): void {}

  toggleHideoOldPassword() {
    this.hideOldpassword = !this.hideOldpassword;
  }
  onSubmit() {
    this.isSubmitted = true;
    if (this.changePasswordGroup.invalid || !this.passwordsMatch) {
      return;
    }
    const oldpassword = this.changePasswordGroup.value.oldpassword;
    const newpassword = this.changePasswordGroup.value.newpassword;
    this.authService.resetPassword(oldpassword, newpassword).subscribe({
      next: (res: any) => {
        if(res && res.code==200) {
          this.alertService.show( 'Success',' Password changed successfully and Login again!');
          this.authService.logout()
        }
        else if(res && res.code==400){
          this.alertService.show('Error','Not updated successfully!');
        }
      },
      error: (error) => {
        this.alertService.show( 'Error','Invalid old password!');
      },
    });
  }
  checkPasswords() {
    const newPassword = this.changePasswordGroup.value.newpassword;
    const confirmPassword = this.changePasswordGroup.value.confirmpassword;
    this.passwordsMatch = newPassword === confirmPassword;
  }

  get oldpassword() {
    return this.changePasswordGroup.get('oldpassword');
  }
  get newpassword() {
    return this.changePasswordGroup.get('newpassword');
  }
  get confirmpassword() {
    return this.changePasswordGroup.get('confirmpassword');
  }
}
