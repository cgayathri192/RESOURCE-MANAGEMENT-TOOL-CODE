import { Component, Inject, inject } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ConfigService } from '@core/services/config.service';
import { GenericRepositoryService } from '@core/services/generic-repository.service';
import { CompetencyReq } from '@core/models_new/competency';
// import { CompetencyReq } from '@core/models/competency';
import {  CompetencyTypeModel, CompetencyTypeRes } from '@core/models_new/competencytype';
// import {  CompetencyTypeModel, CompetencyTypeRes } from '@core/models/competencytype';
import { AlertService } from '@core/services/alert.service';
@Component({
  selector: 'app-competency-edit',
  templateUrl: './competency-edit.component.html',
  styleUrls: ['./competency-edit.component.scss']
})
export class CompetencyEditComponent {
  competencyForm: FormGroup;
  competencyTypeService = inject(GenericRepositoryService<CompetencyTypeRes>)

  CompetencyTypeList!:CompetencyTypeModel[];

  isSubmitted: boolean=false;
  constructor(
    private _fb: FormBuilder,
    private gs:GenericRepositoryService<CompetencyReq>,
    private config:ConfigService,
    private _dialogRef: MatDialogRef<CompetencyEditComponent>,
    private alertService: AlertService,
    @Inject(MAT_DIALOG_DATA) public data: { competencyId:  number},

  ) {
    this.competencyForm = this._fb.group({
      // Id:new FormControl(''),
      Competency: new FormControl('',[Validators.required]),
      CompetencyTypeId:new FormControl('',[Validators.required])
    });
  }
  ngOnInit(): void {
    if(this.data){
      this.gs.getById(this.config.environment.endpoints.competency,this.data.competencyId).subscribe({
        next:(res:CompetencyReq)=>{
          if(res && res.data){
            this.competencyForm.get('Id')?.setValue(this.data.competencyId);
            this.competencyForm.get('Competency')?.setValue(res.data.Competency);
            this.competencyForm.get('CompetencyTypeId')?.setValue(res.data.CompetencyType.Id);
          }
        }
      })
    } 
    this.loadDropdowns();
  }
  get Competency(){
    return this.competencyForm.get('Competency');
  }
  get CompetencyTypeId(){
    return this.competencyForm.get('CompetencyTypeId');
  }
  loadDropdowns(): void {
    this.loadCompetencyType();
  }
  loadCompetencyType(){
    this.competencyTypeService.get(this.config.environment.endpoints.competencytype).subscribe({
      next: (res: CompetencyTypeRes) => {
        if (res.data) {
          this.CompetencyTypeList = res.data;
        }
        else {
          this.CompetencyTypeList = [];
        }
      }
    });
  }
  onFormSubmit() {
    this.isSubmitted= true;
    if (this.competencyForm.valid) {
      if (this.data) {
        this.gs
          .update(this.config.environment.endpoints.competency,this.data.competencyId, this.competencyForm.value)
          .subscribe({
            next: (res: any) => {
              if (res && res.code === 200) {
                this.alertService.show('Success',' Competency updated successfully!');
                this._dialogRef.close(true);
              }else{
                this.alertService.show('Error','Competency not updated !');
              }
            },
            error: (err: any) => {
              console.log(err)
              this.alertService.show('Error','Competency not Updated !');
            },
          });
      } else {
        this.gs.create(this.config.environment.endpoints.competency,this.competencyForm.value).subscribe({
          next: (res: any) => {
            if (res && res.code === 201) {
              this.alertService.show('Success',' Competency added successfully!');
              this._dialogRef.close(true);
            }else{
              this.alertService.show('Error','Competency not added !');
            }  
          },
          error: (err: any)=>{
            this.alertService.show('Error',' Competency exists !');
           },
        });
      }
    }
  }
}
