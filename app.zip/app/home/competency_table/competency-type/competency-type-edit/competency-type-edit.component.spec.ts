import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CompetencyTypeEditComponent } from './competency-type-edit.component';

describe('CompetencyTypeEditComponent', () => {
  let component: CompetencyTypeEditComponent;
  let fixture: ComponentFixture<CompetencyTypeEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CompetencyTypeEditComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CompetencyTypeEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
