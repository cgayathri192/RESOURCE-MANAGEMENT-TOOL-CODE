import { Component, Inject, inject } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ConfigService } from '@core/services/config.service';
import { GenericRepositoryService } from '@core/services/generic-repository.service';
import { CompetencyTypeReq } from '@core/models/competencytype';
import { PracticeModel, PracticeRes } from '@core/models_new/practice';
// import { PracticeModel, PracticeRes } from '@core/models/practice';
import { AlertService } from '@core/services/alert.service';
@Component({
  selector: 'app-competency-type-edit',
  templateUrl: './competency-type-edit.component.html',
  styleUrls: ['./competency-type-edit.component.scss']
})
export class CompetencyTypeEditComponent {
  comptencyTypeForm: FormGroup;
  PracticeList!:PracticeModel[];
  isSubmitted: boolean=false;
  practiceService = inject(GenericRepositoryService<PracticeRes>)
  constructor(
    private _fb: FormBuilder,
    private gs:GenericRepositoryService<CompetencyTypeReq>,
    private config:ConfigService,
    private _dialogRef: MatDialogRef<CompetencyTypeEditComponent>,
    private alertService: AlertService,
    @Inject(MAT_DIALOG_DATA) public data: {competencytypeId:number},
  ) {
    this.comptencyTypeForm = this._fb.group({
      // Id:new FormControl(''),
      CompetencyType: new FormControl('', [Validators.required]),
      PracticeId:new FormControl('', [Validators.required]),
    });
  }
  get CompetencyType(){
    return this.comptencyTypeForm.get('CompetencyType');
  }
  get PracticeId(){
    return this.comptencyTypeForm.get('PracticeId');
  }
  ngOnInit(): void {
    if(this.data){
      this.gs.getById(this.config.environment.endpoints.competencytype,this.data.competencytypeId).subscribe({
        next:(res:CompetencyTypeReq)=>{
          if(res && res.data){
            this.comptencyTypeForm.patchValue(res.data)
            this.comptencyTypeForm.get('Id')?.setValue(this.data.competencytypeId);
            this.comptencyTypeForm.get('PracticeId')?.setValue(res.data.Practice.Id);
          }
        }
      })
    }
    this.loadDropdowns();   
  }
  loadDropdowns(): void {
    this.loadPractice();
  }
  loadPractice(){
    this.practiceService.get(this.config.environment.endpoints.practice).subscribe({
      next: (res: PracticeRes) => {
        if (res.data) {
          this.PracticeList = res.data;
        }
        else {
          this.PracticeList = [];
        }
      }
    });
  }

  
  onFormSubmit() {
    this.isSubmitted= true;
    if (this.comptencyTypeForm.valid) {
      if (this.data) {
        this.gs
          .update(this.config.environment.endpoints.competencytype,this.data.competencytypeId, this.comptencyTypeForm.value)
          .subscribe({
            next: (res: any) => {
              if (res && res.code === 200) {
                this.alertService.show('Success','Competency Type updated successfully!');
                this._dialogRef.close(true);
              }else{
                this.alertService.show('Error','Competency Type Not updated!');
              }
              
            },
            error: (err: any) => {
              this.alertService.show('Error','Competency Type Not updated!');
            },
          });
      } else {
        this.gs.create(this.config.environment.endpoints.competencytype,this.comptencyTypeForm.value).subscribe({
          next: (res: any) => {
            if (res && res.code === 201) {
              this.alertService.show('Success','Competency added successfully!');
              this._dialogRef.close(true);
            }else{
              this.alertService.show('failed','Competency Type not added!');
            }
          },
          error: (err: any) => {
            this.alertService.show('failed','Competency Type not added!');
          },
        });
      }
    }
  }
}
