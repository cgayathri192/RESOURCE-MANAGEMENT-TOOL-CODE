import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CompetencyTypeComponent } from './competency-type.component';

describe('CompetencyTypeComponent', () => {
  let component: CompetencyTypeComponent;
  let fixture: ComponentFixture<CompetencyTypeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CompetencyTypeComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CompetencyTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
