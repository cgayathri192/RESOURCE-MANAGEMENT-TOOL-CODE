import { Component, ViewChild, inject } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ConfigService } from '@core/services/config.service';
import { CoreService } from '@core/services/core.service';
import { GenericRepositoryService } from '@core/services/generic-repository.service';
import { CompetencyTypeEditComponent } from './competency-type-edit/competency-type-edit.component';
import { CompetencyTypeRes, CompetencyTypeModel } from '@core/models_new/competencytype';
// import { CompetencyTypeRes, CompetencyTypeModel } from '@core/models/competencytype';
import { DatePipe } from '@angular/common';
import { AlertService } from '@core/services/alert.service';
@Component({
  selector: 'app-competency-type',
  templateUrl: './competency-type.component.html',
  styleUrls: ['./competency-type.component.scss']
})
export class CompetencyTypeComponent {
  sortOrder: 'asc' | 'desc' = 'asc';
  competency_type:CompetencyTypeModel[]=[];
  displayedColumns: string[] = ['SNo', 'CompetencyTypeName','Practice', 'CreatedAt','ModifiedBy','ModifiedAt', 'action']
  dataSource: MatTableDataSource<CompetencyTypeModel>;
  constructor(private gs: GenericRepositoryService<CompetencyTypeRes>, private config: ConfigService, private _dialog: MatDialog, private alertService: AlertService, private datepipe: DatePipe) {
    this.dataSource = new MatTableDataSource<CompetencyTypeModel>();
  }
  @ViewChild(MatSort) sort!: MatSort;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  ngOnInit(): void {
    this.getCompetencyType();
  }
  openCompetencyEdit() {
    const dialogRef = this._dialog.open(CompetencyTypeEditComponent)
    dialogRef.afterClosed().subscribe({
      next: (val) => {
        if (val) {
          this.getCompetencyType();
        }
      },
    });
  }
  getCompetencyType() {
    this.gs.get(this.config.environment.endpoints.competencytype).subscribe((res:CompetencyTypeRes) => {
      if (res && res.code == 200) {
        res.data.sort((a, b) => {
          return new Date(b.CreatedDateTime).getTime() - new Date(a.CreatedDateTime).getTime();
        });
        this.competency_type = res.data;
        this.dataSource = new MatTableDataSource(this.competency_type);
        const sort = new MatSort();
        sort.active = 'CreatedAt';
        sort.direction = 'desc';
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
      }
    });
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value.trim().toLowerCase();
    this.dataSource.filter = filterValue;
    this.dataSource.filterPredicate = (data: CompetencyTypeModel, filter: string) => {
      return this.filterData(data, filter);
    };
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  
  filterData(data: any, filter: string): boolean {
    for (const key in data) {
      if (data.hasOwnProperty(key)) {
        let value = data[key]  ?? null;
        if(key == "ModifiedAt" || key == "CreatedAt"){
          value = this.datepipe.transform(data[key], 'dd MMM, yyyy') ?? null;
        }
        if (typeof value === 'object' && value !== null) {
          if (this.filterData(value, filter)) {
            return true;
          }
        } else {
          if (value !== null && value.toString().toLowerCase().includes(filter)) {
            return true;
          }
        }
      }
    }
    return false;
  }
  deleteCompetencyType(id: number) {
    this.gs.delete(this.config.environment.endpoints.competencytype, id).subscribe({
      next: (res: CompetencyTypeRes) => {
        if (res && res.code == 200) {
          this.alertService.show('Success','Deleted !');
          this.getCompetencyType();
        }
        else {
          this.alertService.show( 'Error','Not deleted !');
        }
      },
      error: (err: any)=>{
        this.alertService.show('Error','Not deleted !');
       },
    });
  }
  openEditForm(competencytypeId: number) {
    const dialogRef = this._dialog.open(CompetencyTypeEditComponent, {
      data:{competencytypeId:competencytypeId},
    });
    dialogRef.afterClosed().subscribe({
      next: (val) => {
        if (val) {
          this.getCompetencyType();
        }
      },
    });
  }
  applySort(type: any) {
    this.sortOrder = this.sortOrder === 'asc' ? 'desc' : 'asc';
    let valueA: any;
    let valueB: any;
    this.competency_type.sort((a, b) => {
      if (type === 'ModifiedBy') {
        valueA = a?.ModifiedBy?.AssociateName;
        valueB = b?.ModifiedBy?.AssociateName;
      } else if (type === 'Practice') {
        valueA = a?.Practice?.Practice;
        valueB = b?.Practice?.Practice;
      } 

      if (this.sortOrder === 'asc') {
        return valueA < valueB ? -1 : 1;
      } else {
        return valueA > valueB ? -1 : 1;
      }
    });
  }
}
