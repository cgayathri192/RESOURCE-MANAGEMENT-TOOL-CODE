import { Component, ViewChild } from '@angular/core'
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ConfigService } from '@core/services/config.service';
import { GenericRepositoryService } from '@core/services/generic-repository.service';
import { CompetencyEditComponent } from '../competency-edit/competency-edit.component';
import { CompetencyRes, CompetencyModel } from '@core/models_new/competency';
// import { CompetencyRes, CompetencyModel } from '@core/models/competency';
import { DatePipe } from '@angular/common';
import { AlertService } from '@core/services/alert.service';
@Component({
  selector: 'app-competency',
  templateUrl: './competency.component.html',
  styleUrls: ['./competency.component.scss']
})
export class CompetencyComponent {
  competency_list:CompetencyModel[]=[]
  sortOrder: 'asc' | 'desc' = 'asc';
  dataSource: MatTableDataSource<CompetencyModel>;
  displayedColumns: string[] = ['SNo','CompetencyTypeId', 'CompetencyName', 'CreatedAt','ModifiedBy', 'ModifiedAt', 'action'];
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  allSelected = false;
  constructor(private gs: GenericRepositoryService<CompetencyRes>, private config: ConfigService, private _dialog: MatDialog, private alertService: AlertService, private datepipe: DatePipe) {
    this.dataSource = new MatTableDataSource<CompetencyModel>();
  }
  ngOnInit(): void {
    this.getCompetencyList();
  }
  openEditCompetencyForm() {
    const dialogRef = this._dialog.open(CompetencyEditComponent);
    dialogRef.afterClosed().subscribe({
      next: (val) => {
        if (val) {
          this.getCompetencyList();
        }
      },
    });
  }
  getCompetencyList() {
    this.gs.get(this.config.environment.endpoints.competency).subscribe ({
      next: (res : CompetencyRes) => {
        if (res && res.code == 200) {
          res.data.sort((a, b) => {
            return new Date(b.CreatedDateTime).getTime() - new Date(a.CreatedDateTime).getTime();
          });
          this.competency_list = res.data
          this.dataSource = new MatTableDataSource(this.competency_list);
          const sort = new MatSort();
          sort.active = 'CreatedAt';
          sort.direction = 'desc';
          this.dataSource.sort = this.sort;
          this.dataSource.paginator = this.paginator;
        }
      },
    });
  }
  
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value.trim().toLowerCase();;
    this.dataSource.filter = filterValue;
    this.dataSource.filterPredicate = (data:CompetencyModel, filter:string)=> {
      return this.filterData(data,filter);
    };
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  filterData(data: any, filter: string): boolean {
    for (const key in data) {
      if (data.hasOwnProperty(key)) {
        let value = data[key]  ?? null;
        if(key == "ModifiedAt" || key == "CreatedAt"){
          value = this.datepipe.transform(data[key], 'dd MMM, yyyy') ?? null;
        }
        if (typeof value === 'object' && value !== null) {
          if (this.filterData(value, filter)) {
            return true;
          }
        } else {
          if (value !== null && value.toString().toLowerCase().includes(filter)) {
            return true;
          }
        }
      }
    }
    return false;
  }
  openEditForm(competencyId: number) {
    const dialogRef = this._dialog.open(CompetencyEditComponent, {
      data:{competencyId:competencyId},
    });
    dialogRef.afterClosed().subscribe({
      next: (val) => {
        if (val) {
          this.getCompetencyList();
        }
      },
    });
  }
  deleteCompetency(id: number) {
    this.gs.delete(this.config.environment.endpoints.competency, id).subscribe({
      next: (res: CompetencyRes) => {
        if (res && res.code == 200) {
          this.alertService.show('Success','Deleted!');
          this.getCompetencyList();
        }
        else {
          this.alertService.show('Error','Not deleted!');
        }
      },
      error: (err: any)=>{
         this.alertService.show('Error','Not deleted!');
        },
    });
  }
  applySort(type: any) {
    this.sortOrder = this.sortOrder === 'asc' ? 'desc' : 'asc';
    let valueA: any;
    let valueB: any;
    this.competency_list.sort((a, b) => {
      if (type === 'CompetencyTypeId') {
        valueA = a?.CompetencyType?.CompetencyType;
        valueB = b?.CompetencyType?.CompetencyType;
      } else if (type === 'ModifiedBy') {
        valueA = a?.ModifiedBy?.AssociateName;
        valueB = b?.ModifiedBy?.AssociateName;
      }
    
      if (this.sortOrder === 'asc') {
        return valueA < valueB ? -1 : 1;
      } else {
        return valueA > valueB ? -1 : 1;
      }
    });
  }
  }