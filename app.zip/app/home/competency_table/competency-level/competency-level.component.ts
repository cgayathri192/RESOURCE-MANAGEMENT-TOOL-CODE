import { Component, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ConfigService } from '@core/services/config.service';
import { GenericRepositoryService } from '@core/services/generic-repository.service';
import { CompetencyLevelEditComponent } from './competency-level-edit/competency-level-edit.component';
import { CompetencylevelRes,Competencylevel, CompetencylevelModel } from '@core/models_new/competencylevel';
// import { CompetencylevelRes,Competencylevel, CompetencylevelModel } from '@core/models_new/competencylevel';
import { DatePipe } from '@angular/common';
import { AlertService } from '@core/services/alert.service';
@Component({
  selector: 'app-competency-level',
  templateUrl: './competency-level.component.html',
  styleUrls: ['./competency-level.component.scss']
})
export class CompetencyLevelComponent {
  displayedColumns: string[] = ['SNo', 'CompetencyLevel','CreatedDateTime', 'ModifiedBy', 'ModifiedDateTime', 'action']
  dataSource: MatTableDataSource<CompetencylevelModel>;
  competencylevel: Competencylevel[] = [];
  constructor(private gs: GenericRepositoryService<CompetencylevelRes>, private config: ConfigService, private _dialog: MatDialog, private alertService: AlertService,private datepipe:DatePipe) {
    this.dataSource = new MatTableDataSource<CompetencylevelModel>();
  }
  @ViewChild(MatSort) sort!: MatSort;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  ngOnInit(): void {
    this.getCompetencyLevel();
  }
  openCompetencyLevelEdit() {
    const dialogRef = this._dialog.open(CompetencyLevelEditComponent);
    dialogRef.afterClosed().subscribe({
      next: (val) => {
        if (val) {
          this.getCompetencyLevel();
        }
      },
    });
  }
  getCompetencyLevel() {
    this.gs.get(this.config.environment.endpoints.competencylevel).subscribe((res:CompetencylevelRes) => {
      if (res && res.code == 200) {
        res.data.sort((a, b) => {
          return new Date(b.CreatedDateTime).getTime() - new Date(a.CreatedDateTime).getTime();
        });
        this.dataSource = new MatTableDataSource(res.data);
        const sort = new MatSort();
        sort.active = 'CreatedDateTime';
        sort.direction = 'desc';
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
      }
    });
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value.trim().toLowerCase();;
    this.dataSource.filter = filterValue
    this.dataSource.filterPredicate = (data:CompetencylevelModel, filter:string)=> {
      return this.filterData(data,filter);
    };
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  filterData(data: any, filter: string): boolean {
    for (const key in data) {
      if (data.hasOwnProperty(key)) {
        let value = data[key]  ?? null;
        if(key == "ModifiedDateTime" || key == "CreatedAtDateTime"){
          value = this.datepipe.transform(data[key], 'dd MMM, yyyy') ?? null;
        }
        if (typeof value === 'object' && value !== null) {
          if (this.filterData(value, filter)) {
            return true;
          }
        } else {
          if (value !== null && value.toString().toLowerCase().includes(filter)) {
            return true;
          }
        }
      }
    }
    return false;
  }
  deleteCompetencyLevel(id: number) {
    this.gs.delete(this.config.environment.endpoints.competencylevel, id).subscribe({
      next: (res: CompetencylevelRes) => {
        if (res && res.code == 200) {
          this.alertService.show( 'Success','Deleted !');
          this.getCompetencyLevel();
        }
        else {
          this.alertService.show('Error','Not deleted !');
        }
      },
      error: (err: any)=>{
        this.alertService.show('Error','Not deleted !');
       },
    });
  }
  openEditForm(competencylevelId: number) {
    const dialogRef = this._dialog.open(CompetencyLevelEditComponent, {
      data:{competencylevelId:competencylevelId},
    });
    dialogRef.afterClosed().subscribe({
      next: (val) => {
        if (val) {
          this.getCompetencyLevel();
        }
      },
    });
  }
}
