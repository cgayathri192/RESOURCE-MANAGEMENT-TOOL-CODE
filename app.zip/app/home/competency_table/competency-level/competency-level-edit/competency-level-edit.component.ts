import { Component, Inject } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ConfigService } from '@core/services/config.service';
import { GenericRepositoryService } from '@core/services/generic-repository.service';
import { CompetencylevelReq } from '@core/models_new/competencylevel';
import { CoreService } from '@core/services/core.service';
import { AlertService } from '@core/services/alert.service';
@Component({
  selector: 'app-competency-level-edit',
  templateUrl: './competency-level-edit.component.html',
  styleUrls: ['./competency-level-edit.component.scss']
})
export class CompetencyLevelEditComponent {
  competencyLevelForm: FormGroup;
  isSubmitted: boolean=false;
  constructor(
    private _fb: FormBuilder,
    private gs:GenericRepositoryService<CompetencylevelReq>,
    private config:ConfigService,
    private _dialogRef: MatDialogRef<CompetencyLevelEditComponent>,
    private alertService: AlertService,
    @Inject(MAT_DIALOG_DATA) public data: {competencylevelId: number},
  ) {
    this.competencyLevelForm = this._fb.group({
      Id:new FormControl(''),
      CompetencyLevel:new FormControl('',[Validators.required]),
    });
  }
  ngOnInit(): void {
    if(this.data){
      this.gs.getById(this.config.environment.endpoints.competencylevel,this.data.competencylevelId).subscribe({
        next:(res:CompetencylevelReq)=>{
          if(res.data){
            this.competencyLevelForm.patchValue(res.data)
          }
        }
      })
    } 
  }
  get CompetencyLevel(){
    return this.competencyLevelForm.get('CompetencyLevel');
  }
  get isActive(){
    return this.competencyLevelForm.get('IsActive');
  }
  onFormSubmit() {
    this.isSubmitted= true;
    if (this.competencyLevelForm.valid) {
      if (this.data) {
        this.gs
          .update(this.config.environment.endpoints.competencylevel,this.data.competencylevelId, this.competencyLevelForm.value)
          .subscribe({
            next: (res: any) => {
              if (res && res.code === 200) {
                this.alertService.show('Success','Competency level detail updated successfully!');
                this._dialogRef.close(true);
              }else{
                this.alertService.show('Error','Competency level not updated !');
              }
            },
            error: (err: any) => {
              this.alertService.show('Error','Competency level not updated !');
            },
          });
      } else {
        this.gs.create(this.config.environment.endpoints.competencylevel,this.competencyLevelForm.value).subscribe({
          next: (res: any) => {
            if (res && res.code === 201) {
              this.alertService.show('Success','Competency level added successfully!');
              this._dialogRef.close(true);
            }else{
              this.alertService.show('Error','Competency level not added !');
            }
           
          },
          error: (err: any) => {
            this.alertService.show('Error','Competency level not added !');
          },
        });
      }
    }
  }
}
