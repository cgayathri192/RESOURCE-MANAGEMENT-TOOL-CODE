import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CompetencyLevelEditComponent } from './competency-level-edit.component';

describe('CompetencyLevelEditComponent', () => {
  let component: CompetencyLevelEditComponent;
  let fixture: ComponentFixture<CompetencyLevelEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CompetencyLevelEditComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CompetencyLevelEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
