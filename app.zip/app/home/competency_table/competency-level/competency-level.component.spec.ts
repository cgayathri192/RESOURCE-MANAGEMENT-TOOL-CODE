import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CompetencyLevelComponent } from './competency-level.component';

describe('CompetencyLevelComponent', () => {
  let component: CompetencyLevelComponent;
  let fixture: ComponentFixture<CompetencyLevelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CompetencyLevelComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CompetencyLevelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
