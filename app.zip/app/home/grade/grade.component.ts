import { DatePipe } from '@angular/common';
import { Component, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { GradeModel, GradeRes } from '@core/models_new/grade';
// import { GradeModel, GradeRes } from '@core/models/grade';
import { AlertService } from '@core/services/alert.service';
import { ConfigService } from '@core/services/config.service';
import { GenericRepositoryService } from '@core/services/generic-repository.service';
import { GradeEditComponent } from '@home-module/grade-edit/grade-edit.component';

@Component({
  selector: 'app-grade',
  templateUrl: './grade.component.html',
  styleUrls: ['./grade.component.scss']
})
export class GradeComponent {
  displayedColumns: string[] = ['SNo', 'GradeName','CreatedAt','ModifiedBy', 'ModifiedAt', 'action']
  dataSource: MatTableDataSource<GradeModel>;
  constructor(private gs: GenericRepositoryService<GradeRes>, private config: ConfigService, private _dialog: MatDialog, private alertService: AlertService,private datepipe:DatePipe) {
    this.dataSource = new MatTableDataSource<GradeModel>();
  }
  @ViewChild(MatSort) sort!: MatSort;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  ngOnInit(): void {
    this.getGrade();
  }
  openGrade() {
    const dialogRef = this._dialog.open(GradeEditComponent);
    dialogRef.afterClosed().subscribe({
      next: (val) => {
        if (val) {
          this.getGrade();
        }
      },
    });
  }
  getGrade() {
    this.gs.get(this.config.environment.endpoints.grade).subscribe((res: GradeRes) => {
      if(res && res.code == 200){
        res.data.sort((a, b) => {
          return new Date(b.CreatedDateTime).getTime() - new Date(a.CreatedDateTime).getTime();
        });
      this.dataSource = new MatTableDataSource(res.data);
      const sort = new MatSort();
      sort.active = 'CreatedAt';
      sort.direction = 'desc';
      this.dataSource.sort = this.sort;
      this.dataSource.paginator = this.paginator;
      }
    });
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value.trim().toLowerCase();;
    this.dataSource.filter = filterValue
    this.dataSource.filterPredicate = (data:GradeModel, filter:string)=> {
      return this.filterData(data,filter);
    };
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  filterData(data: any, filter: string): boolean {
    for (const key in data) {
      if (data.hasOwnProperty(key)) {
        let value = data[key]  ?? null;
        if(key == "ModifiedAt" || key == "CreatedAt"){
          value = this.datepipe.transform(data[key], 'dd MMM, yyyy') ?? null;
        }
        if (typeof value === 'object' && value !== null) {
          if (this.filterData(value, filter)) {
            return true;
          }
        } else {
          if (value !== null && value.toString().toLowerCase().includes(filter)) {
            return true;
          }
        }
      }
    }
    return false;
  }
  openEditForm(gradeId: string) {
    const dialogRef = this._dialog.open(GradeEditComponent, {
      data:{gradeId:gradeId},
    });
    dialogRef.afterClosed().subscribe({
      next: (val) => {
        if (val) {
          this.getGrade();
        }
      },
    });
  }
  deleteGrade(id: number) {
    this.gs.delete(this.config.environment.endpoints.grade, id).subscribe({
      next: (res: GradeRes) => {
        this.alertService.show('Success','Grade deleted!');
        this.getGrade();
      },
      error: (err: any) => {
        this.alertService.show('Error','Grade not deleted ');
      },
    });
  }
}
