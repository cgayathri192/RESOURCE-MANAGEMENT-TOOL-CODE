import { Component, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { TitleEditComponent } from '../title-edit/title-edit.component';
import { GenericRepositoryService } from '@core/services/generic-repository.service';
import { ConfigService } from '@core/services/config.service';
// import { Title, TitleModel, TitleRes } from '@core/models/title';
import { Title, TitleModel, TitleRes } from '@core/models_new/title';
import { DatePipe } from '@angular/common';
import { AlertService } from '@core/services/alert.service';

@Component({
  selector: 'app-title-details',
  templateUrl: './title-details.component.html',
  styleUrls: ['./title-details.component.scss'],
})
export class TitleDetailsComponent {
  displayedColumns: string[] = [
    'SNo',
    'TitleName',
    'Grade',
    'Department',
    'CreatedAt',
    'ModifiedBy',
    'ModifiedAt',
    'action',
  ];
  title_list:TitleModel[]=[];
  sortOrder: 'asc' | 'desc' = 'asc';
  dataSource: MatTableDataSource<TitleModel>;
  constructor(
    private gs: GenericRepositoryService<TitleRes>,
    private config: ConfigService,
    private _dialog: MatDialog,
    private alertService: AlertService,
    private datepipe:DatePipe
  ) {
    this.dataSource = new MatTableDataSource<TitleModel>();
  }
  @ViewChild(MatSort) sort!: MatSort;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  ngOnInit(): void {
    this.getTitle();
  }
  openAddEdittitleForm() {
    const dialogRef = this._dialog.open(TitleEditComponent);
    dialogRef.afterClosed().subscribe({
      next: (val) => {
        if (val) {
          this.getTitle();
        }
      },
    });
  }

  getTitle() {
    this.gs
      .get(this.config.environment.endpoints.title)
      .subscribe((res: TitleRes) => {
        if (res && res.code == 200) {
          res.data.sort((a, b) => {
            return (
              new Date(b.CreatedDateTime).getTime() - new Date(a.CreatedDateTime).getTime()
            );
          });
          this.title_list = res.data
          this.dataSource = new MatTableDataSource(this.title_list);
          const sort = new MatSort();
          sort.active = 'CreatedDateTime';
          sort.direction = 'desc';
          this.dataSource.sort = this.sort;
          this.dataSource.paginator = this.paginator;
        }
      });
    
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value.trim().toLowerCase();;
    this.dataSource.filter = filterValue
    this.dataSource.filterPredicate = (data:TitleModel, filter:string)=> {
      return this.filterData(data,filter);
    };
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  filterData(data: any, filter: string): boolean {
    for (const key in data) {
      if (data.hasOwnProperty(key)) {
        let value = data[key]  ?? null;
        if(key == "ModifiedDateTime" || key == "CreatedDateTime"){
          value = this.datepipe.transform(data[key], 'dd MMM, yyyy') ?? null;
        }
        if (typeof value === 'object' && value !== null) {
          if (this.filterData(value, filter)) {
            return true;
          }
        } else {
          if (value !== null && value.toString().toLowerCase().includes(filter)) {
            return true;
          }
        }
      }
    }
    return false;
  }
  deleteTitle(id: number) {
    this.gs.delete(this.config.environment.endpoints.title, id).subscribe({
      next: (res: any) => {
        if (res && res.code == 200) {
          this.alertService.show('Success','Deleted successfully!');
          this.getTitle();
        } else {
          this.alertService.show('Error','Not deleted !');
        }
      },
      error: (err: any) => {
        this.alertService.show('Error','Not deleted !');
      },
    });
  }
  openEditForm(titleId: string) {
    const dialogRef = this._dialog.open(TitleEditComponent, {
      data: { titleId: titleId },
    });
    dialogRef.afterClosed().subscribe({
      next: (val) => {
        if (val) {
          this.getTitle();
        }
      },
    });
  }
  applySort(type: any) {
    this.sortOrder = this.sortOrder === 'asc' ? 'desc' : 'asc';
    let valueA: any;
    let valueB: any;
    this.title_list.sort((a, b) => {
      if (type === 'Grade') {
        valueA = a?.Grade?.GradeName;
        valueB = b?.Grade?.GradeName;
      }else if( type === 'Department'){
        valueA = a?.Department?.DepartmentName;
        valueB = b?.Department?.DepartmentName;
      }else if (type === 'ModifiedBy') {
        valueA = a?.ModifiedBy?.AssociateName;
        valueB = b?.ModifiedBy?.AssociateName;
      }
    
      if (this.sortOrder === 'asc') {
        return valueA < valueB ? -1 : 1;
      } else {
        return valueA > valueB ? -1 : 1;
      }
    });
  }
}
