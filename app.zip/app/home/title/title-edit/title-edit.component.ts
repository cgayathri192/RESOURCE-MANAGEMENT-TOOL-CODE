import { Component, Inject, OnInit, inject } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { DepartmentModel, DepartmentRes } from '@core/models_new/department';
import { GradeModel, GradeRes } from '@core/models_new/grade';
import { TitleReq } from '@core/models_new/title';
import { AlertService } from '@core/services/alert.service';
import { ConfigService } from '@core/services/config.service';
import { GenericRepositoryService } from '@core/services/generic-repository.service';

@Component({
  selector: 'app-title-edit',
  templateUrl: './title-edit.component.html',
  styleUrls: ['./title-edit.component.scss']
})
export class TitleEditComponent implements OnInit {
  titleForm: FormGroup;
  gradeService = inject(GenericRepositoryService<GradeRes>)
  departmentService = inject(GenericRepositoryService<DepartmentRes>)
  GradeList!:GradeModel[];
  DepartmentList!:DepartmentModel[];
  
  isSubmitted: boolean=false;
  constructor(
    private _fb: FormBuilder,
    private gs:GenericRepositoryService<TitleReq>,
    private config:ConfigService,
    private alertService:AlertService,
    private _dialogRef: MatDialogRef<TitleEditComponent>,
    @Inject(MAT_DIALOG_DATA) public data: {titleId:number},
  ) {
    this.titleForm = this._fb.group({
      Id:new FormControl(''),
      Title: new FormControl('', [Validators.required]),
      GradeId:new FormControl('', [Validators.required]),
      DepartmentId:new FormControl('', [Validators.required])
    });
  }
  get Title(){
    return this.titleForm.get('Title');
  }
  get GradeId(){
    return this.titleForm.get('GradeId');
  }
  get DepartmentId(){
    return this.titleForm.get('DepartmentId');
  }
  ngOnInit(): void {
    if(this.data){
      this.gs.getById(this.config.environment.endpoints.title,this.data.titleId).subscribe({
        next:(res:TitleReq)=>{
          if(res.data){
            this.titleForm.get('Id')?.setValue(this.data.titleId);
            this.titleForm.get('TitleName')?.setValue(res.data.Title);
            this.titleForm.get('GradeId')?.setValue(res.data.Grade.Id);
            this.titleForm.get('DepartmentId')?.setValue(res.data.Department.Id);
          }
        }
      })
    } 
    this.loadDropdowns(); 
  }
  loadDropdowns(): void {
    this.loadGrade();
    this.loadDepartment();
  }
  loadGrade(){
    this.gradeService.get(this.config.environment.endpoints.grade).subscribe({
      next: (res: GradeRes) => {
        if (res.data) {
          this.GradeList = res.data;
        }
        else {
          this.GradeList = [];
        }
      }
    });
  }
  loadDepartment(){
    this.departmentService.get(this.config.environment.endpoints.department).subscribe({
      next: (res: DepartmentRes) => {
        if (res.data) {
          this.DepartmentList = res.data;
        }
        else {
          this.DepartmentList = [];
        }
      }
    });
  }
  onFormSubmit() {
    this.isSubmitted= true;
    if (this.titleForm.valid) {
      if (this.data) {
        this.gs
          .update(this.config.environment.endpoints.title,this.data.titleId, this.titleForm.value)
          .subscribe({
            next: (res: any) => {
              if (res && res.code === 200) {
                this.alertService.show('Success','Title updated successfully!');
              this._dialogRef.close(true);
              }else{
                this.alertService.show( 'Error','Title not updated !');
              }
              
            },
            error: (err: any) => {
              this.alertService.show('Error','Title not updated !');
            },
          });
      } else {
        this.gs.create(this.config.environment.endpoints.title,this.titleForm.value).subscribe({
          next: (res: any) => {
            if (res && res.code === 201) {
              this.alertService.show('Success','Title added successfully!');
            this._dialogRef.close(true);

            }else{
              this.alertService.show('Error','Title not added !');
            }
            
          },
          error: (err: any) => {
            this.alertService.show( 'Error','Title not added !');
          },
        });
      }
    }
  }
}
