import { DatePipe } from '@angular/common';
import { AfterViewInit, Component, ElementRef, inject, OnInit, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { EmployeeModel } from '@core/models/employee';
import { OrganizationTree, OrganizationTreeRes } from '@core/models/organization-tree';
import { ProfileInitials } from '@core/models/profileInitials';
import { AuthService } from '@core/services/auth.service';
import { ConfigService } from '@core/services/config.service';
import { GenericRepositoryService } from '@core/services/generic-repository.service';
import { ProfileService } from '@core/services/profile.service';

@Component({
  selector: 'app-organization-chart',
  templateUrl: './organization-chart.component.html',
  styleUrls: ['./organization-chart.component.scss']
})
export class OrganizationChartComponent implements OnInit ,AfterViewInit{
  currentFilter: 'top' | 'department' | 'me' = 'top';
  myDepartment: string | null = null;
  loginedUserId: number;
  dataSource!: MatTableDataSource<EmployeeModel>;
   constructor(private config: ConfigService,private profileService: ProfileService,private datepipe:DatePipe,private authService: AuthService){
     this.loginedUserId =  this.authService.getTokenDetails().user_id;
   }
  tree!: OrganizationTree;
  organizationTreeService = inject(GenericRepositoryService<OrganizationTree>);
  searchQuery: string = ''; 
  ngOnInit(): void {
    this.organizationTreeService.get(this.config.environment.endpoints.organizationTree).subscribe({
      next: (res: OrganizationTreeRes) => {
        if (res && res.data) {
          this.tree =this.hideChildrenById(res.data,this.loginedUserId);
        }
      },
    });
  }
  @ViewChildren('nodeElement') nodeElements!: QueryList<ElementRef>;

  ngAfterViewInit() {
    setTimeout(() => {
      const nodeId = this.loginedUserId.toString(); 
      this.nodeElements.forEach((nodeElement: ElementRef) => {
        const elementId = nodeElement.nativeElement.getAttribute('data-node-id');
        if (elementId === nodeId) {
          nodeElement.nativeElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      });
    }, 500);
  }
  public generateProfileInititals(profileName : string): ProfileInitials {
    return this.profileService.generateProfileInititals(profileName);
  }
  hideChildrenById(data: OrganizationTree, id: number, level: number = 0): OrganizationTree {
    if (level >= 2) {
      if (data.Id === id) {
        data.hideChildren = true;
      }
    }
    level++;
    if (data.children && data.children.length > 0) {
      data.children.forEach(child => this.hideChildrenById(child, id, level));
    }
    return data;
  }
  filterTreeByName(data: OrganizationTree, query: string): void {
    if (!data) {
      return;
    }
    data.children = data.children.filter(child => {
      if (child.ResourceName.toLowerCase().includes(query)) {
        return true;
      } else if (child.children && child.children.length > 0) {
        this.filterTreeByName(child, query);
        return child.children.length > 0;
      } else {
        return false;
      }
    });
  }
performSearch(query: string) {
  this.searchQuery = query;
  if (!this.tree) {
    return;
  }
  if (!query) {
    this.tree = this.hideChildrenById(this.tree, this.loginedUserId);
    return;
  }
  const filteredTree = JSON.parse(JSON.stringify(this.tree));
  this.filterTreeByName(filteredTree, query.toLowerCase());
  this.tree = filteredTree;
}
}
