import { Component, Inject } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { GradeReq, GradeRes} from '@core/models_new/grade';
// import { GradeReq, GradeRes } from '@core/models/grade';
import { AlertService } from '@core/services/alert.service';
import { ConfigService } from '@core/services/config.service';
import { GenericRepositoryService } from '@core/services/generic-repository.service';

@Component({
  selector: 'app-grade-edit',
  templateUrl: './grade-edit.component.html',
  styleUrls: ['./grade-edit.component.scss']
})
export class GradeEditComponent {
  gradeForm: FormGroup;
  isSubmitted: boolean=false;
  constructor(
    private _fb: FormBuilder,
    private gs:GenericRepositoryService<GradeReq>,
    private config:ConfigService,
    private _dialogRef: MatDialogRef<GradeEditComponent>,
    private alertService: AlertService,
    @Inject(MAT_DIALOG_DATA) public data: {gradeId:number},
  ) {
    this.gradeForm = this._fb.group({
      // Id:new FormControl(''),
      Grade: new FormControl('', [Validators.required])
     
    });
  }
  
  get Grade(){
    return this.gradeForm.get('Grade');
  }
 
  ngOnInit(): void {
    if(this.data){
      this.gs.getById(this.config.environment.endpoints.grade,this.data.gradeId).subscribe({
        next:(res:GradeReq)=>{
          if(res.data){
            this.gradeForm.get('Id')?.setValue(this.data.gradeId);
            this.gradeForm.get('Grade')?.setValue(res.data.Grade);
                       
          }
        }
      })
    }  
  }
  onFormSubmit() {
    this.isSubmitted= true;
    if (this.gradeForm.value) {
      if (this.data) {
        this.gs
          .update(this.config.environment.endpoints.grade,this.data.gradeId, this.gradeForm.value)
          .subscribe({
            next: (res: any) => {
              if (res && res.code === 200) {
                this.alertService.show('Success','Grade details updated successfully!');
                this._dialogRef.close(true);
              }else{
                this.alertService.show('Error','Grade details not updated !');
              }
              
            },
            error: (err: any) => {
              this.alertService.show('Error','Grade details not updated !');
            },
          });
      } else {
        this.gs.create(this.config.environment.endpoints.grade,this.gradeForm.value).subscribe({
          next: (res: any) => {
            if (res && res.code === 201) {
              this.alertService.show('Success','Grades added successfully!');
              this._dialogRef.close(true);
            }else{
              this.alertService.show('Error','Grades not added successfully!');
            }
          },
          error: (err: any) => {
            this.alertService.show('Error','Grades not added successfully!');
          },
        });
      }
    }
  }
}
